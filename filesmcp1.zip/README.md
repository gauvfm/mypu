# MCP-SEC-ARCH-001 · v1.1 · Bundle

**Document set:** Enterprise MCP Security Architecture
**Version:** 1.1 · April 2026
**Spec baseline:** MCP 2025-11-25 (Linux Foundation / AAIF)
**Classification:** Internal

---

## Files in this bundle

| File | Format | Purpose |
|------|--------|---------|
| `MCP-Security-Architecture-v1.1.docx` | Word | The paper. Sections 01–09: thesis, 2026 landscape, trust zones, reference architecture, transport controls, host/client internals, build vs buy flows, gateway specification, controls summary, framework coverage, residual risks. |
| `MCP-Security-Controls-v1.1.xlsx` | Excel | Full controls catalog. 7 sheets including all 63 controls with framework cross-references (NIST 800-53, NIST AI RMF, ISO 42001, OWASP LLM, OWASP MCP, OWASP Agentic AI, CoSAI, IETF RFCs), transport mapping, and residual risks. GRC-import ready. |
| `mcp-aws-security-architecture.drawio` | draw.io | Two-page editable diagram. Page 1: AWS deployment architecture with named services, functional component groups, and 20 numbered flow steps. Page 2: numbered flow narrative as a table mapping each step to protocol, authentication, and applied controls. |

---

## Recommended usage by audience

**Security architects.** Start with the DOCX §06 (Gateway specification) and §07 (Controls), then open the .drawio to see the deployment, then go to the XLSX `Gateway-Controls` and `Host-Controls` sheets for the catalog.

**Enterprise architects.** Open the .drawio first (page 1 deployment, page 2 narrative). Then read DOCX §03 (Architecture) and §03.1 (Transport controls). Skip the controls catalog unless you own a specific component.

**GRC / compliance.** Import XLSX `All-Controls` sheet into your tool (ServiceNow IRM, Archer, Vanta). Use the `Framework-Coverage` sheet for audit narratives. The `Residual-Risks` sheet is required reading before sign-off.

**Executives.** Read DOCX §01 (Thesis) and §01.5 (2026 landscape). Skip everything else; ask your security architect for the rest if needed.

---

## Catalog statistics (v1.1)

| Category | Count | Change from v1.0 |
|----------|-------|------------------|
| Gateway + infrastructure controls | 35 | +10 new in 2026 |
| Host + client controls | 28 | +7 new in 2026 |
| **Total mandatory controls** | **63** | **+17 new in 2026** |
| Buy-agent coverage via vendor contract | ~60% | unchanged |

> Note: an earlier draft summary stated "61 total · +8 new". The actual counts after re-tally are 63 total · +17 new. The XLSX and DOCX in this bundle reflect the corrected numbers.

---

## What changed in 2026 (driving v1.1)

1. **MCP donated to Linux Foundation / AAIF** (Dec 2025). Vendor-neutral governance now structural.
2. **RFC 9728 PRM + RFC 9449 DPoP** are now table-stakes for production MCP. New controls IAM-AUTHN-09 and IAM-AUTHN-10 added.
3. **Elicitation (URL mode + Form mode)** introduced in 2025-11-25 spec. URL mode is mandatory for credentials. New controls INP-07, HOST-ELC-01/02/03 added.
4. **Tool annotations** (`readOnlyHint`, `destructiveHint`, `idempotentHint`, `openWorldHint`) and **SEP-1075 security annotations** are stable. New control AUTHZ-08 (annotation-driven policy) added.
5. **OWASP MCP Top 10:2025** formalized (MCP01–MCP10). **OWASP Agentic AI Top 10** (Dec 2025). **CoSAI MCP Security** (OASIS-approved Jan 2026). All mapped in framework coverage.
6. **First malicious MCP servers in the wild.** postmark-mcp; 492 unauthenticated servers found by Trend Micro in early 2026. New residual risk documented; new control SUP-09 (reverse-DNS namespace authentication) added.
7. **TEE for high-risk servers.** Intel TDX, AMD-SEV/SNP, AWS Nitro Enclaves with remote attestation. New control RUN-06 added.

---

## Companion files (not in this bundle)

If you need any of the following, ask Security Architecture:

- **HTML version of the paper** for screen reading (single-file, dark mode)
- **PNG export** of the architecture diagram (for slide decks)
- **Mermaid source** of the architecture (for in-line wiki use)
- **Pre-populated GRC import templates** for ServiceNow IRM or Archer

---

## Document control

- Owner: Security Architecture
- Review cycle: Annual or on MCP spec major version
- Next review: April 2027 or on MCP spec change (whichever is sooner)
- Change log: v1.0 (March 2026) → v1.1 (April 2026, 2025-11-25 spec rebaseline)
