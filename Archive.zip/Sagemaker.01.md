# Security Questions for AWS: SageMaker JumpStart + LLM Gateway Integration

**Purpose:** Security architecture review questions for AWS Solutions Architects, TAMs, and Security Team  
**Scope:** SageMaker JumpStart deployment with private VPC integration and LLM Gateway  
**Date Prepared:** January 2026

---

## 1. SUPPLY CHAIN SECURITY

### 1.1 ECR Image Provenance

**Q1.1.1:** What is AWS's container image build process for Deep Learning Containers in account `763104351884`?
- Who has access to push images to this ECR repository?
- What security controls prevent unauthorized image modifications?
- Is there a cryptographic signing process for container images?
- Can we obtain image build manifests or SBOMs (Software Bill of Materials)?

**Q1.1.2:** How does AWS verify the integrity of base images and dependencies?
- What vulnerability scanning tools does AWS use internally?
- What is the SLA for patching CRITICAL CVEs in DLC images?
- How are we notified when images are updated for security patches?

**Q1.1.3:** Can AWS provide SHA256 digests for all JumpStart container images we intend to use?
- Are these digests published in a verifiable, tamper-proof location?
- Can we pin to specific image digests instead of tags?

**Q1.1.4:** What is AWS's policy on image lifecycle and deprecation?
- How much notice is given before removing/deprecating images?
- What is the support window for older image versions?

---

### 1.2 S3 Model Artifacts Security

**Q1.2.1:** How does AWS ensure integrity of model weights in `jumpstart-cache-prod-*` buckets?
- Are checksums (SHA256/MD5) published for model artifacts?
- Is there an integrity verification process during download?
- Can we obtain provenance information for model training data and weights?

**Q1.2.2:** What access controls exist on JumpStart S3 buckets?
- Who within AWS has write access to these buckets?
- Are S3 Object Lock or versioning enabled to prevent tampering?
- What logging/monitoring exists for modifications to model artifacts?

**Q1.2.3:** Are model artifacts encrypted at rest?
- What encryption keys are used (AWS-managed vs customer-managed)?
- Can we use our own KMS keys to re-encrypt artifacts we download?

**Q1.2.4:** How frequently are model artifacts updated?
- What triggers model updates (bug fixes, performance improvements, security)?
- Are there change logs or release notes for model updates?
- Can we subscribe to notifications for model changes?

---

### 1.3 License Compliance

**Q1.3.1:** What are the exact licenses for each model we plan to use?
- Llama 2, Mistral, Falcon, etc. - specific license terms
- Are there usage restrictions (commercial vs non-commercial)?
- What attribution requirements exist?

**Q1.3.2:** If we mirror AWS images to our ECR, does this violate any licenses?
- Do we need explicit permission from AWS or model creators?
- What are the redistribution terms?

**Q1.3.3:** Are there any export control restrictions on models or container images?
- ITAR, EAR, or other regulatory considerations?
- Geographic restrictions on where we can deploy?

---

## 2. NETWORK SECURITY & ISOLATION

### 2.1 Network Isolation Guarantees

**Q2.1.1:** When `enable_network_isolation=True`, what is the technical implementation?
- Is it iptables, network namespaces, or another mechanism?
- Can you provide documentation on the exact rules applied?
- Has this been third-party audited or penetration tested?

**Q2.1.2:** What network access does the container have during the startup phase?
- Exact timeline when network is open vs closed?
- What happens if container crashes and restarts - does network reopen?
- Can startup network access be further restricted?

**Q2.1.3:** Are there any AWS services that can still communicate with isolated containers?
- CloudWatch agent, SSM agent, other AWS background processes?
- Can these channels be used for data exfiltration?

**Q2.1.4:** What guarantees exist that network isolation cannot be bypassed?
- What if container runs with elevated privileges?
- What if there's a kernel vulnerability?
- Are containers running in separate VPCs or just network namespaces?

---

### 2.2 VPC Endpoint Security

**Q2.2.1:** When using VPC endpoints, is traffic encrypted in transit?
- TLS version and cipher suites used?
- Certificate validation process?
- Can we enforce minimum TLS 1.3?

**Q2.2.2:** For VPC endpoints (`com.amazonaws.region.sagemaker.runtime`), who else can access these?
- Are they account-isolated or could other AWS accounts use the same endpoint?
- Can we apply resource-based policies to VPC endpoints?

**Q2.2.3:** What DNS resolution occurs during container startup?
- Could DNS poisoning redirect S3/ECR traffic?
- Are DNSSEC or other DNS security measures in place?

**Q2.2.4:** If our VPC has internet connectivity via NAT Gateway, can isolated containers still reach internet?
- What prevents a misconfigured security group from allowing outbound internet?
- Can you provide a reference architecture diagram of network boundaries?

---

### 2.3 Cross-Account Access

**Q2.3.1:** When pulling images from account `763104351884`, what authentication occurs?
- Is there a risk of account compromise affecting all customers?
- What would happen if AWS's ECR credentials for this account were leaked?

**Q2.3.2:** Can we audit who in our organization is pulling images from AWS's ECR?
- CloudTrail events, VPC Flow Logs, or other audit trails?
- Can we set up alerts for unusual pull patterns?

**Q2.3.3:** What prevents AWS from changing image content without our knowledge?
- Since we reference by tag (e.g., `:2.3.0-gpu-...`), can AWS update the underlying image?
- Should we use digest-based references instead?

---

## 3. DATA PROTECTION & PRIVACY

### 3.1 Data at Rest

**Q3.1.1:** Where is inference input/output data stored, if at all?
- Does SageMaker log request/response payloads?
- If `DataCaptureConfig` is enabled, what encryption is used?
- Can we use customer-managed KMS keys for all data storage?

**Q3.1.2:** What data persists on the endpoint instance filesystem?
- Are there temporary files created during inference?
- How is data sanitized when instance is terminated?
- Is disk encryption enabled on endpoint instances?

**Q3.1.3:** For models that require fine-tuning or custom training data:
- Where is training data stored during the job?
- What happens to training data after job completes?
- Can we enforce automatic deletion?

---

### 3.2 Data in Transit

**Q3.2.1:** What encryption is used for `InvokeEndpoint` API calls?
- TLS version, cipher suites, certificate validation?
- Can we enforce mutual TLS (mTLS)?
- Is there a way to verify end-to-end encryption?

**Q3.2.2:** When downloading models from S3 during startup:
- Is S3 download encrypted in transit (HTTPS)?
- Can we enforce S3 bucket policies requiring TLS?
- What prevents man-in-the-middle attacks on S3 downloads?

**Q3.2.3:** For CloudWatch Logs and Metrics:
- Is telemetry data encrypted in transit?
- Can we use VPC endpoints for CloudWatch to keep traffic private?

---

### 3.3 Data Residency & Sovereignty

**Q3.3.1:** Where are JumpStart S3 buckets physically located?
- Are they regional or multi-region?
- Can we guarantee data doesn't leave specific AWS regions?

**Q3.3.2:** For CloudWatch Logs/Metrics, where is this data stored?
- Same region as endpoint or potentially cross-region?
- What are data retention policies?

**Q3.3.3:** If we operate in multiple regions:
- Do we need separate JumpStart resources per region?
- Can models be deployed cross-region with data locality guarantees?

---

## 4. ACCESS CONTROL & IDENTITY

### 4.1 IAM Permissions

**Q4.1.1:** What are the minimum IAM permissions required for:
- Deploying JumpStart models?
- Invoking endpoints?
- Monitoring and logging?

**Q4.1.2:** Can we scope IAM permissions to specific JumpStart models?
- E.g., only allow deployment of approved model IDs?
- Can we use resource tags for permission boundaries?

**Q4.1.3:** For the SageMaker execution role:
- What's the least privilege set of permissions?
- Can we remove `AmazonSageMakerFullAccess` and use custom policies?
- What permissions are used during startup vs runtime?

**Q4.1.4:** How can we prevent privilege escalation?
- What if execution role is compromised?
- Can the execution role be used to create other AWS resources?
- Should we use permission boundaries?

---

### 4.2 Service-to-Service Authentication

**Q4.2.1:** When LLM Gateway invokes SageMaker endpoint:
- Is there authentication beyond IAM?
- Can we implement request signing or API keys?
- How do we prevent replay attacks?

**Q4.2.2:** Can we use IAM roles for service accounts (IRSA) if LLM Gateway is on EKS?
- What's the recommended authentication pattern?
- Can we rotate credentials automatically?

**Q4.2.3:** For VPC endpoints:
- Can we restrict which principals can invoke endpoints through VPC endpoints?
- Are there resource-based policies we can apply?

---

### 4.3 Audit & Compliance

**Q4.3.1:** What CloudTrail events are logged for SageMaker operations?
- CreateModel, CreateEndpoint, InvokeEndpoint?
- Are `InvokeEndpoint` calls logged by default or only with opt-in?
- What PII might be in CloudTrail logs (request payloads)?

**Q4.3.2:** Can we enable detailed request/response logging without storing sensitive data?
- Redaction or filtering options?
- Can we log only metadata (timestamp, user, latency) without prompts/completions?

**Q4.3.3:** What compliance certifications does JumpStart hold?
- SOC 2, ISO 27001, FedRAMP, HIPAA?
- Are there compliance inheritance models for customers?

**Q4.3.4:** Can AWS provide audit reports or attestations for:
- Image build security?
- Model artifact integrity?
- Infrastructure security controls?

---

## 5. AVAILABILITY & RESILIENCE

### 5.1 Service Dependencies

**Q5.1.1:** What AWS services does JumpStart depend on?
- S3, ECR, SageMaker Control Plane, others?
- What happens if any dependency fails?
- Are there single points of failure?

**Q5.1.2:** What is the SLA for JumpStart service availability?
- Does it inherit SageMaker's SLA or have its own?
- What happens if `jumpstart-cache-prod-*` S3 bucket is unavailable?
- Can we deploy if AWS's ECR (`763104351884`) is down?

**Q5.1.3:** For existing running endpoints:
- If JumpStart service fails, do running endpoints continue?
- What about autoscaling, monitoring, logging?
- Can we invoke endpoints if SageMaker Control Plane is down?

---

### 5.2 Disaster Recovery

**Q5.2.1:** What is our recovery process if:
- AWS accidentally deletes JumpStart model artifacts?
- ECR images become corrupted?
- S3 bucket has a data loss event?

**Q5.2.2:** Should we maintain backups of:
- Model artifacts in our own S3 buckets?
- Container images in our own ECR?
- Deployment configurations?

**Q5.2.3:** What is AWS's data backup and recovery policy for JumpStart resources?
- Are backups encrypted and tested?
- What is Recovery Time Objective (RTO) and Recovery Point Objective (RPO)?

---

### 5.3 Multi-Region Strategy

**Q5.3.1:** Can JumpStart models be deployed identically across multiple regions?
- Are the same model versions available in all regions?
- Are there regional differences in available models or image versions?

**Q5.3.2:** For multi-region HA:
- Can we use Global Accelerator or Route 53 with SageMaker endpoints?
- What's the recommended multi-region architecture?
- Are there cross-region replication options for models?

**Q5.3.3:** What is failover behavior if primary region fails?
- Can traffic automatically route to secondary region?
- What about sticky sessions or state?

---

## 6. OPERATIONAL SECURITY

### 6.1 Patching & Updates

**Q6.1.1:** How frequently does AWS release security patches for DLC images?
- What is the patch release cadence (weekly, monthly)?
- How are urgent (zero-day) vulnerabilities handled?

**Q6.1.2:** When AWS updates an image tag (e.g., `pytorch-inference:2.3.0-gpu-...`):
- Are we automatically using the new version?
- How do we test updates before production deployment?
- Can we pin to specific image digests for stability?

**Q6.1.3:** What is the notification process for security updates?
- Email, SNS, RSS feed, security bulletins?
- Can we subscribe to only critical/high severity updates?

**Q6.1.4:** For container vulnerabilities (CVEs):
- Does AWS provide a CVE database or vulnerability reports?
- Can we query what CVEs exist in a specific image version?
- What is the process for requesting expedited patches?

---

### 6.2 Monitoring & Alerting

**Q6.2.1:** What security events should we monitor for JumpStart deployments?
- Unusual inference patterns (DDoS, data exfiltration attempts)?
- Failed authentication attempts?
- Resource quota exhaustion?

**Q6.2.2:** Can AWS provide baseline metrics for "normal" endpoint behavior?
- Request rates, latency percentiles, error rates?
- How do we distinguish attacks from legitimate traffic spikes?

**Q6.2.3:** What GuardDuty findings relate to SageMaker?
- Are there specific threat detections for SageMaker endpoints?
- Can GuardDuty detect anomalous inference patterns?

**Q6.2.4:** For VPC Flow Logs:
- What should we look for to detect network isolation bypasses?
- Sample queries or alerts for security events?

---

### 6.3 Incident Response

**Q6.3.1:** If we detect a compromised endpoint, what is the kill-chain?
- Can we immediately terminate endpoints via API?
- What about in-flight requests?
- How quickly can we deploy a patched replacement?

**Q6.3.2:** What forensic data is available after a security incident?
- CloudTrail logs, VPC Flow Logs, container logs?
- How long is this data retained?
- Can we preserve evidence for legal/compliance needs?

**Q6.3.3:** Does AWS have a security incident notification process?
- If AWS detects compromise of JumpStart infrastructure (ECR/S3), will customers be notified?
- What is the notification timeline?

**Q6.3.4:** What is AWS's process for handling security vulnerabilities reported by customers?
- Bug bounty program coverage for SageMaker/JumpStart?
- Coordinated disclosure timeline?

---

## 7. COST & ABUSE PREVENTION

### 7.1 Cost Controls

**Q7.1.1:** What prevents runaway costs from:
- Autoscaling gone wrong (endpoints scaling to 100+ instances)?
- Misconfigured inference requests (infinite loops)?
- DDoS attacks causing cost spikes?

**Q7.1.2:** Can we set hard limits on:
- Maximum number of endpoint instances?
- Maximum request rate per endpoint?
- Total monthly SageMaker spend?

**Q7.1.3:** What billing alerts or anomaly detection exists?
- Can we get real-time cost monitoring?
- Automatic shutdown at budget thresholds?

---

### 7.2 Rate Limiting & Quotas

**Q7.2.1:** What are the service quotas for:
- Number of endpoints per account?
- InvokeEndpoint API rate limits?
- Concurrent endpoint deployments?

**Q7.2.2:** Can we request quota increases for production workloads?
- What is the approval process and timeline?
- Are there hard limits that cannot be increased?

**Q7.2.3:** For LLM Gateway integration:
- Should rate limiting be at Gateway level, SageMaker level, or both?
- What's the recommended architecture for handling 10K+ req/sec?

---

## 8. INTEGRATION & ARCHITECTURE

### 8.1 LLM Gateway Connectivity

**Q8.1.1:** What is the recommended network path for LLM Gateway → SageMaker Endpoint?
- Direct VPC connection vs VPC endpoint vs PrivateLink?
- Should LLM Gateway be in same VPC as endpoint or different VPC?
- Peering vs Transit Gateway for multi-VPC setup?

**Q8.1.2:** For LLM Gateway authentication to SageMaker:
- SigV4 signing, IAM roles, assumed roles?
- What's the recommended credential rotation strategy?
- Can we use short-lived credentials (STS)?

**Q8.1.3:** What is the maximum request/response size for `InvokeEndpoint`?
- Payload size limits?
- Timeout limits?
- How to handle large context windows (100K+ tokens)?

**Q8.1.4:** Can we implement request/response streaming?
- For token-by-token generation in LLMs?
- What's the latency overhead?

---

### 8.2 Multi-Tenancy

**Q8.2.1:** Can a single SageMaker endpoint serve multiple tenants/customers?
- How to ensure data isolation between tenants?
- How to prevent one tenant from affecting another's performance?

**Q8.2.2:** Should we use:
- One endpoint per tenant (expensive)?
- One endpoint with request routing logic (complex)?
- Multi-model endpoints (limited JumpStart support)?

**Q8.2.3:** For multi-tenant deployments:
- How to track usage/costs per tenant?
- How to apply different rate limits per tenant?
- Can we use resource tags for tenant attribution?

---

### 8.3 Model Versioning & A/B Testing

**Q8.3.1:** Can we run multiple versions of the same model simultaneously?
- Blue/green deployments?
- Canary deployments (5% traffic to new version)?
- How to implement traffic splitting?

**Q8.3.2:** For A/B testing:
- Can we tag requests to track which model version handled them?
- How to ensure statistically valid comparisons?
- What's the recommended architecture?

**Q8.3.3:** When updating models:
- Zero-downtime deployment process?
- Rollback strategy if new version has issues?
- How long does blue/green deployment take?

---

## 9. SPECIALIZED SECURITY CONCERNS

### 9.1 Model Security

**Q9.1.1:** Are JumpStart models vulnerable to:
- Prompt injection attacks?
- Jailbreaking attempts?
- Data poisoning (if fine-tuning)?

**Q9.1.2:** What built-in safeguards exist in JumpStart models?
- Content filtering, toxicity detection?
- PII redaction?
- Input validation?

**Q9.1.3:** Can we implement custom input/output filtering?
- Pre-processing hooks before model inference?
- Post-processing for content moderation?
- Integration with AWS services (Comprehend, Rekognition)?

**Q9.1.4:** For fine-tuning JumpStart models:
- What prevents training data leakage into model weights?
- Can fine-tuned models be reverse-engineered to extract training data?
- What's the recommended data sanitization process?

---

### 9.2 Side-Channel Attacks

**Q9.2.1:** What prevents timing attacks to infer information?
- Constant-time inference operations?
- Response padding?

**Q9.2.2:** In multi-tenant scenarios:
- Can one tenant observe another's resource usage (CPU, GPU, memory)?
- Are there noisy neighbor protections?

**Q9.2.3:** Can inference latency leak information about inputs?
- E.g., longer latency for certain sensitive topics?
- How to implement constant-time or randomized latency?

---

### 9.3 Insider Threats

**Q9.3.1:** What prevents malicious AWS employees from:
- Accessing our model inputs/outputs?
- Modifying JumpStart artifacts?
- Exfiltrating customer data?

**Q9.3.2:** What audit controls does AWS have internally?
- Background checks for staff with access to customer environments?
- Logging of AWS employee actions?
- Can we request audit logs of AWS actions in our account?

**Q9.3.3:** For AWS managed keys (KMS, encryption):
- Who at AWS can access these keys?
- Can we use customer-managed keys for everything?
- What's the key rotation policy?

---

## 10. COMPLIANCE & GOVERNANCE

### 10.1 Regulatory Compliance

**Q10.1.1:** Is SageMaker JumpStart compliant with:
- **HIPAA** (healthcare data)?
- **PCI-DSS** (payment card data)?
- **GDPR** (EU personal data)?
- **FedRAMP** (US government workloads)?
- **SOC 2 Type II**?

**Q10.1.2:** For compliance-specific deployments:
- Are there separate JumpStart environments for FedRAMP?
- What additional controls are required?
- Can AWS provide compliance documentation?

**Q10.1.3:** For data processing agreements (DPAs):
- Is JumpStart covered under our existing AWS DPA?
- Are there additional terms for AI/ML services?
- What are data retention and deletion obligations?

---

### 10.2 Policy Enforcement

**Q10.2.1:** Can we enforce organization-wide policies via:
- Service Control Policies (SCPs)?
- Permission boundaries?
- AWS Config rules?

**Q10.2.2:** What built-in AWS Config rules exist for SageMaker security?
- Network isolation enforcement?
- VPC configuration validation?
- Encryption at rest/in transit?

**Q10.2.3:** Can we prevent deployment of:
- Non-approved models (model ID whitelist)?
- Endpoints without network isolation?
- Endpoints without VPC configuration?

---

### 10.3 Data Governance

**Q10.3.1:** For model training data and inference logs:
- What is the data classification (public, internal, confidential)?
- Where is data stored (region, bucket)?
- Who has access (AWS, customer admins, model developers)?

**Q10.3.2:** Can we implement data lineage tracking?
- Track data from source → training → model → inference → output?
- Integration with data catalogs (Glue, Lake Formation)?

**Q10.3.3:** For right to deletion (GDPR, CCPA):
- How do we ensure data is purged from models?
- Can models be "unlearned" after deletion requests?
- What's the data retention policy for logs and metrics?

---

## 11. OPEN-ENDED STRATEGIC QUESTIONS

**Q11.1:** What is AWS's long-term product roadmap for JumpStart?
- Will JumpStart always use shared ECR/S3, or will customer-managed options be available?
- Plans for enhanced security features (e.g., built-in container scanning)?

**Q11.2:** What is AWS's recommended architecture for highly secure LLM deployments?
- Can AWS Solutions Architects provide a reference architecture review?
- Are there Well-Architected Framework guidelines specific to JumpStart?

**Q11.3:** Has AWS conducted penetration testing or red team exercises on JumpStart?
- Can findings (sanitized) be shared with enterprise customers?
- What was the scope and methodology?

**Q11.4:** What is AWS's incident response plan for JumpStart security events?
- How are customers notified?
- What support is available during incidents?
- Post-incident reporting and root cause analysis process?

**Q11.5:** Can AWS provide a shared responsibility model diagram specifically for JumpStart?
- What is AWS responsible for vs what is customer responsibility?
- Where are the demarcation points?

**Q11.6:** For our specific use case (highly regulated industry with strict data controls):
- Has AWS worked with similar customers?
- Can you provide case studies or reference customers we can speak with?
- What lessons learned can be shared?

---

## 12. ACTION ITEMS & NEXT STEPS

**For AWS to Provide:**
1. Written responses to all questions above
2. Reference architectures for secure JumpStart + LLM Gateway
3. Detailed network diagrams showing all data flows
4. Sample IAM policies (least privilege)
5. Compliance documentation (SOC 2, ISO 27001, etc.)
6. Image/model provenance documentation
7. Incident response runbooks
8. Contact information for security escalations

**For Customer Security Team:**
1. Review AWS responses and identify gaps
2. Conduct threat modeling session with AWS
3. Perform security assessment/penetration test
4. Develop internal security policies and procedures
5. Create monitoring and alerting playbooks
6. Train operations team on secure deployment practices

**Timeline:**
- Request responses from AWS within: 2 weeks
- Schedule follow-up deep-dive sessions: Within 1 month
- Complete security review and approval: Within 2 months

---

## APPENDIX: QUESTION PRIORITIZATION

### **P0 - CRITICAL (Must answer before any deployment)**
- Q1.1.2 (Image integrity and patching SLA)
- Q2.1.1 (Network isolation technical implementation)
- Q3.1.1 (Data at rest encryption and logging)
- Q4.1.1 (Minimum IAM permissions)
- Q10.1.1 (Regulatory compliance certifications)

### **P1 - HIGH (Must answer before production deployment)**
- Q1.2.1 (Model artifact integrity)
- Q2.2.1 (VPC endpoint encryption)
- Q5.1.2 (Service SLA and dependencies)
- Q6.1.1 (Security patch cadence)
- Q8.1.1 (Recommended network architecture)

### **P2 - MEDIUM (Should answer during implementation)**
- All other questions not in P0/P1

---

**Document Control:**
- **Author:** Security Architecture Team
- **Review:** CISO, Cloud Security Team, SageMaker Team Lead
- **Approval:** Required before production deployment
- **Next Review:** After AWS response received
