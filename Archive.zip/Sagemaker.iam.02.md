# IAM Roles & Permissions Reference: SageMaker JumpStart + LLM Gateway

**Purpose:** Complete IAM configuration guide for secure SageMaker JumpStart deployment with LLM Gateway  
**Architecture:** Private VPC, Network Isolation Enabled, Multi-Account Optional  
**Security Level:** High (Production-Ready with Least Privilege)

---

## TABLE OF CONTENTS

1. [Role Overview & Architecture](#role-overview--architecture)
2. [Role 1: SageMaker Execution Role](#role-1-sagemaker-execution-role)
3. [Role 2: JumpStart Deployment Role](#role-2-jumpstart-deployment-role)
4. [Role 3: LLM Gateway Service Role](#role-3-llm-gateway-service-role)
5. [Role 4: CI/CD Pipeline Role](#role-4-cicd-pipeline-role)
6. [Role 5: Monitoring & Operations Role](#role-5-monitoring--operations-role)
7. [Optional: Container Mirroring Role](#optional-container-mirroring-role)
8. [Service Control Policies (SCPs)](#service-control-policies-scps)
9. [VPC Endpoint Policies](#vpc-endpoint-policies)
10. [S3 Bucket Policies](#s3-bucket-policies)
11. [Security Groups](#security-groups)
12. [Complete Policy Templates](#complete-policy-templates)

---

## ROLE OVERVIEW & ARCHITECTURE

### **Principle: Separation of Duties**

Each role has a single, well-defined purpose:

| **Role Name** | **Purpose** | **Who/What Uses It** | **Scope** |
|--------------|------------|---------------------|-----------|
| **SageMakerExecutionRole** | Runtime permissions for endpoint | SageMaker service during endpoint operation | ECR pull, S3 read, VPC networking |
| **JumpStartDeploymentRole** | Deploy/manage JumpStart models | Engineers, IaC pipelines | CreateModel, CreateEndpoint, PassRole |
| **LLMGatewayServiceRole** | Invoke endpoints for inference | LLM Gateway application | InvokeEndpoint only |
| **CICDPipelineRole** | Automated deployments | GitHub Actions, GitLab CI, Jenkins | Deployment + validation |
| **MonitoringOpsRole** | View logs, metrics, troubleshoot | Operations team | Read-only monitoring |
| **ContainerMirrorRole** | Copy AWS images to your ECR | Automated scanning pipeline | ECR pull/push, S3 read |

---

### **Architecture Diagram**

```
┌─────────────────────────────────────────────────────────────────────┐
│                         AWS Account: Production                      │
│                                                                       │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │ CI/CD Pipeline (GitHub Actions)                             │    │
│  │ Role: CICDPipelineRole                                      │    │
│  │ Permissions: Deploy + Validate                              │    │
│  └──────────────────────┬─────────────────────────────────────┘    │
│                         │                                            │
│                         │ (1) Deploy JumpStart Model                │
│                         ▼                                            │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │ JumpStart Deployment Process                                │    │
│  │ Role: JumpStartDeploymentRole                               │    │
│  │ Actions:                                                     │    │
│  │  - CreateModel (specifies SageMakerExecutionRole)          │    │
│  │  - CreateEndpointConfig                                     │    │
│  │  - CreateEndpoint                                           │    │
│  │  - PassRole to SageMaker service                            │    │
│  └──────────────────────┬─────────────────────────────────────┘    │
│                         │                                            │
│                         │ (2) Endpoint Starts                        │
│                         ▼                                            │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │ SageMaker Endpoint (ml.g5.xlarge)                           │    │
│  │ Role: SageMakerExecutionRole                                │    │
│  │ Permissions During Startup:                                 │    │
│  │  - Pull image from ECR (763104351884)                      │    │
│  │  - Download model from S3 (jumpstart-cache-prod-*)         │    │
│  │  - Create ENIs in VPC                                       │    │
│  │  - Send logs to CloudWatch                                  │    │
│  │ Permissions During Runtime:                                 │    │
│  │  - CloudWatch logs/metrics ONLY                             │    │
│  │  - Network isolated (no outbound allowed)                   │    │
│  └──────────────────────┬─────────────────────────────────────┘    │
│                         │                                            │
│                         │ (3) Inference Requests                     │
│                         ▼                                            │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │ LLM Gateway (ECS/EKS/Lambda)                                │    │
│  │ Role: LLMGatewayServiceRole                                 │    │
│  │ Permissions:                                                 │    │
│  │  - InvokeEndpoint (specific endpoint ARNs only)            │    │
│  │  - CloudWatch logs for gateway                              │    │
│  └──────────────────────┬─────────────────────────────────────┘    │
│                         │                                            │
│                         │ (4) Monitoring                             │
│                         ▼                                            │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │ Operations Team                                              │    │
│  │ Role: MonitoringOpsRole                                     │    │
│  │ Permissions:                                                 │    │
│  │  - DescribeEndpoint, DescribeModel (read-only)             │    │
│  │  - CloudWatch Logs read                                     │    │
│  │  - CloudWatch Metrics read                                  │    │
│  └────────────────────────────────────────────────────────────┘    │
│                                                                       │
└───────────────────────────────────────────────────────────────────────┘
```

---

## ROLE 1: SAGEMAKER EXECUTION ROLE

### **Purpose**
Attached to SageMaker endpoint - used by SageMaker service to access AWS resources on behalf of the endpoint.

### **When It's Used**
- During endpoint startup (pull ECR image, download S3 model)
- During runtime (send CloudWatch logs/metrics)
- During autoscaling (create new instances)

### **Trust Policy**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowSageMakerServiceToAssumeRole",
      "Effect": "Allow",
      "Principal": {
        "Service": "sagemaker.amazonaws.com"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "aws:SourceAccount": "123456789012"
        },
        "ArnLike": {
          "aws:SourceArn": "arn:aws:sagemaker:us-east-1:123456789012:*"
        }
      }
    }
  ]
}
```

**Security Notes:**
- Condition keys prevent confused deputy attacks
- Scoped to specific account and region

---

### **Permissions Policy - Option A: AWS-Managed ECR (Default JumpStart)**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ECRImagePullFromAWS",
      "Effect": "Allow",
      "Action": [
        "ecr:GetAuthorizationToken"
      ],
      "Resource": "*",
      "Condition": {
        "StringEquals": {
          "aws:RequestedRegion": "us-east-1"
        }
      }
    },
    {
      "Sid": "ECRPullFromAWSAccount",
      "Effect": "Allow",
      "Action": [
        "ecr:BatchCheckLayerAvailability",
        "ecr:GetDownloadUrlForLayer",
        "ecr:BatchGetImage"
      ],
      "Resource": [
        "arn:aws:ecr:us-east-1:763104351884:repository/pytorch-inference",
        "arn:aws:ecr:us-east-1:763104351884:repository/pytorch-training",
        "arn:aws:ecr:us-east-1:763104351884:repository/huggingface-pytorch-tgi-inference",
        "arn:aws:ecr:us-east-1:763104351884:repository/tensorflow-inference"
      ]
    },
    {
      "Sid": "S3ReadJumpStartArtifacts",
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::jumpstart-cache-prod-us-east-1",
        "arn:aws:s3:::jumpstart-cache-prod-us-east-1/*"
      ],
      "Condition": {
        "StringEquals": {
          "aws:PrincipalAccount": "123456789012"
        }
      }
    },
    {
      "Sid": "CloudWatchLogging",
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": [
        "arn:aws:logs:us-east-1:123456789012:log-group:/aws/sagemaker/Endpoints/*",
        "arn:aws:logs:us-east-1:123456789012:log-group:/aws/sagemaker/Endpoints/*:log-stream:*"
      ]
    },
    {
      "Sid": "CloudWatchMetrics",
      "Effect": "Allow",
      "Action": [
        "cloudwatch:PutMetricData"
      ],
      "Resource": "*",
      "Condition": {
        "StringEquals": {
          "cloudwatch:namespace": [
            "/aws/sagemaker/Endpoints",
            "AWS/SageMaker"
          ]
        }
      }
    },
    {
      "Sid": "VPCNetworking",
      "Effect": "Allow",
      "Action": [
        "ec2:CreateNetworkInterface",
        "ec2:CreateNetworkInterfacePermission",
        "ec2:DeleteNetworkInterface",
        "ec2:DeleteNetworkInterfacePermission",
        "ec2:DescribeNetworkInterfaces",
        "ec2:DescribeVpcs",
        "ec2:DescribeDhcpOptions",
        "ec2:DescribeSubnets",
        "ec2:DescribeSecurityGroups"
      ],
      "Resource": "*"
    },
    {
      "Sid": "VPCNetworkInterfaceTagging",
      "Effect": "Allow",
      "Action": [
        "ec2:CreateTags"
      ],
      "Resource": "arn:aws:ec2:us-east-1:123456789012:network-interface/*",
      "Condition": {
        "StringEquals": {
          "ec2:CreateAction": "CreateNetworkInterface"
        }
      }
    }
  ]
}
```

**What's Allowed:**
- ✅ Pull images from AWS's ECR (`763104351884`)
- ✅ Download models from JumpStart S3 buckets
- ✅ Create network interfaces in VPC
- ✅ Send logs and metrics to CloudWatch

**What's Denied:**
- ❌ No S3 write (cannot exfiltrate data to S3)
- ❌ No internet access (enforced by network isolation)
- ❌ No access to other AWS services (Lambda, DynamoDB, etc.)
- ❌ No IAM operations (cannot escalate privileges)

---

### **Permissions Policy - Option B: Customer-Managed ECR (Mirrored Images)**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ECRImagePullFromOurAccount",
      "Effect": "Allow",
      "Action": [
        "ecr:GetAuthorizationToken"
      ],
      "Resource": "*"
    },
    {
      "Sid": "ECRPullFromOurAccountOnly",
      "Effect": "Allow",
      "Action": [
        "ecr:BatchCheckLayerAvailability",
        "ecr:GetDownloadUrlForLayer",
        "ecr:BatchGetImage"
      ],
      "Resource": [
        "arn:aws:ecr:us-east-1:123456789012:repository/pytorch-inference-scanned",
        "arn:aws:ecr:us-east-1:123456789012:repository/huggingface-tgi-scanned"
      ]
    },
    {
      "Sid": "DenyAWSManagedECR",
      "Effect": "Deny",
      "Action": [
        "ecr:*"
      ],
      "Resource": [
        "arn:aws:ecr:*:763104351884:repository/*"
      ]
    },
    {
      "Sid": "S3ReadOurScannedModels",
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::our-scanned-models-bucket",
        "arn:aws:s3:::our-scanned-models-bucket/*"
      ]
    },
    {
      "Sid": "DenyJumpStartS3",
      "Effect": "Deny",
      "Action": [
        "s3:*"
      ],
      "Resource": [
        "arn:aws:s3:::jumpstart-cache-prod-*",
        "arn:aws:s3:::jumpstart-cache-prod-*/*"
      ]
    },
    {
      "Sid": "CloudWatchLogging",
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": [
        "arn:aws:logs:us-east-1:123456789012:log-group:/aws/sagemaker/Endpoints/*"
      ]
    },
    {
      "Sid": "CloudWatchMetrics",
      "Effect": "Allow",
      "Action": [
        "cloudwatch:PutMetricData"
      ],
      "Resource": "*",
      "Condition": {
        "StringEquals": {
          "cloudwatch:namespace": "/aws/sagemaker/Endpoints"
        }
      }
    },
    {
      "Sid": "VPCNetworking",
      "Effect": "Allow",
      "Action": [
        "ec2:CreateNetworkInterface",
        "ec2:CreateNetworkInterfacePermission",
        "ec2:DeleteNetworkInterface",
        "ec2:DeleteNetworkInterfacePermission",
        "ec2:DescribeNetworkInterfaces",
        "ec2:DescribeVpcs",
        "ec2:DescribeDhcpOptions",
        "ec2:DescribeSubnets",
        "ec2:DescribeSecurityGroups"
      ],
      "Resource": "*"
    }
  ]
}
```

**Key Differences from Option A:**
- ✅ Only allows pulling from YOUR ECR (scanned images)
- ✅ Explicitly DENIES access to AWS-managed ECR/S3
- ✅ Forces use of your scanned and approved images
- ✅ Better for high-security environments

---

## ROLE 2: JUMPSTART DEPLOYMENT ROLE

### **Purpose**
Used by engineers or CI/CD pipelines to deploy JumpStart models to SageMaker.

### **Who Uses It**
- ML engineers deploying models
- CI/CD pipelines (GitHub Actions, GitLab CI)
- Infrastructure-as-Code tools (Terraform, CloudFormation)

### **Trust Policy**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowEngineerUsers",
      "Effect": "Allow",
      "Principal": {
        "AWS": [
          "arn:aws:iam::123456789012:user/ml-engineer-1",
          "arn:aws:iam::123456789012:user/ml-engineer-2"
        ]
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "IpAddress": {
          "aws:SourceIp": [
            "203.0.113.0/24"
          ]
        },
        "Bool": {
          "aws:MultiFactorAuthPresent": "true"
        }
      }
    },
    {
      "Sid": "AllowCICDRole",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::123456789012:role/CICDPipelineRole"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

**Security Notes:**
- Requires MFA for human users
- IP restriction for human users (corporate VPN)
- Allows CI/CD role to assume (no MFA needed for automation)

---

### **Permissions Policy**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "SageMakerModelDeployment",
      "Effect": "Allow",
      "Action": [
        "sagemaker:CreateModel",
        "sagemaker:CreateEndpointConfig",
        "sagemaker:CreateEndpoint",
        "sagemaker:UpdateEndpoint",
        "sagemaker:DeleteEndpoint",
        "sagemaker:DeleteEndpointConfig",
        "sagemaker:DeleteModel",
        "sagemaker:DescribeModel",
        "sagemaker:DescribeEndpointConfig",
        "sagemaker:DescribeEndpoint",
        "sagemaker:ListEndpoints",
        "sagemaker:ListEndpointConfigs",
        "sagemaker:ListModels",
        "sagemaker:ListTags",
        "sagemaker:AddTags"
      ],
      "Resource": [
        "arn:aws:sagemaker:us-east-1:123456789012:model/*",
        "arn:aws:sagemaker:us-east-1:123456789012:endpoint-config/*",
        "arn:aws:sagemaker:us-east-1:123456789012:endpoint/*"
      ],
      "Condition": {
        "StringEquals": {
          "aws:RequestedRegion": "us-east-1"
        }
      }
    },
    {
      "Sid": "RequireNetworkIsolation",
      "Effect": "Deny",
      "Action": "sagemaker:CreateModel",
      "Resource": "*",
      "Condition": {
        "Bool": {
          "sagemaker:NetworkIsolation": "false"
        }
      }
    },
    {
      "Sid": "RequireVPCConfiguration",
      "Effect": "Deny",
      "Action": "sagemaker:CreateModel",
      "Resource": "*",
      "Condition": {
        "Null": {
          "sagemaker:VpcSubnets": "true"
        }
      }
    },
    {
      "Sid": "PassRoleToSageMaker",
      "Effect": "Allow",
      "Action": "iam:PassRole",
      "Resource": [
        "arn:aws:iam::123456789012:role/SageMakerExecutionRole"
      ],
      "Condition": {
        "StringEquals": {
          "iam:PassedToService": "sagemaker.amazonaws.com"
        }
      }
    },
    {
      "Sid": "ReadJumpStartMetadata",
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::jumpstart-cache-prod-us-east-1/models_manifest.json",
        "arn:aws:s3:::jumpstart-cache-prod-us-east-1"
      ]
    },
    {
      "Sid": "ValidateVPCConfiguration",
      "Effect": "Allow",
      "Action": [
        "ec2:DescribeVpcs",
        "ec2:DescribeSubnets",
        "ec2:DescribeSecurityGroups",
        "ec2:DescribeVpcEndpoints"
      ],
      "Resource": "*"
    },
    {
      "Sid": "CloudWatchLogsAccess",
      "Effect": "Allow",
      "Action": [
        "logs:DescribeLogGroups",
        "logs:DescribeLogStreams"
      ],
      "Resource": "*"
    }
  ]
}
```

**Key Security Features:**
- ✅ DENIES deployment without network isolation
- ✅ DENIES deployment without VPC configuration
- ✅ Can only pass specific SageMaker execution role (prevents privilege escalation)
- ✅ Scoped to specific region

---

## ROLE 3: LLM GATEWAY SERVICE ROLE

### **Purpose**
Used by LLM Gateway application to invoke SageMaker endpoints for inference.

### **Who Uses It**
- LLM Gateway (ECS task, EKS pod, Lambda function, EC2 instance)

### **Trust Policy - Option A: ECS Task Role**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowECSTasksToAssumeRole",
      "Effect": "Allow",
      "Principal": {
        "Service": "ecs-tasks.amazonaws.com"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "aws:SourceAccount": "123456789012"
        },
        "ArnLike": {
          "aws:SourceArn": "arn:aws:ecs:us-east-1:123456789012:*"
        }
      }
    }
  ]
}
```

---

### **Trust Policy - Option B: EKS IRSA (IAM Roles for Service Accounts)**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowEKSServiceAccountToAssumeRole",
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::123456789012:oidc-provider/oidc.eks.us-east-1.amazonaws.com/id/EXAMPLED539D4633E53DE1B71EXAMPLE"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "oidc.eks.us-east-1.amazonaws.com/id/EXAMPLED539D4633E53DE1B71EXAMPLE:sub": "system:serviceaccount:llm-gateway:llm-gateway-sa",
          "oidc.eks.us-east-1.amazonaws.com/id/EXAMPLED539D4633E53DE1B71EXAMPLE:aud": "sts.amazonaws.com"
        }
      }
    }
  ]
}
```

---

### **Permissions Policy**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "InvokeSpecificEndpoints",
      "Effect": "Allow",
      "Action": [
        "sagemaker:InvokeEndpoint"
      ],
      "Resource": [
        "arn:aws:sagemaker:us-east-1:123456789012:endpoint/llama-2-7b-prod",
        "arn:aws:sagemaker:us-east-1:123456789012:endpoint/mistral-7b-prod",
        "arn:aws:sagemaker:us-east-1:123456789012:endpoint/falcon-7b-prod"
      ]
    },
    {
      "Sid": "DenyInvokeOtherEndpoints",
      "Effect": "Deny",
      "Action": [
        "sagemaker:InvokeEndpoint"
      ],
      "NotResource": [
        "arn:aws:sagemaker:us-east-1:123456789012:endpoint/llama-2-7b-prod",
        "arn:aws:sagemaker:us-east-1:123456789012:endpoint/mistral-7b-prod",
        "arn:aws:sagemaker:us-east-1:123456789012:endpoint/falcon-7b-prod"
      ]
    },
    {
      "Sid": "GatewayLogging",
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": [
        "arn:aws:logs:us-east-1:123456789012:log-group:/aws/llm-gateway/*"
      ]
    },
    {
      "Sid": "GatewayMetrics",
      "Effect": "Allow",
      "Action": [
        "cloudwatch:PutMetricData"
      ],
      "Resource": "*",
      "Condition": {
        "StringEquals": {
          "cloudwatch:namespace": "LLMGateway"
        }
      }
    }
  ]
}
```

**Key Security Features:**
- ✅ Can ONLY invoke specific, whitelisted endpoints
- ✅ Explicit DENY for all other endpoints (defense in depth)
- ✅ No access to CreateEndpoint, DeleteEndpoint, or any management operations
- ✅ Cannot access S3, ECR, or any other AWS services
- ✅ Narrowest possible scope (principle of least privilege)

---

## ROLE 4: CI/CD PIPELINE ROLE

### **Purpose**
Used by automated CI/CD pipelines for deploying and managing SageMaker infrastructure.

### **Who Uses It**
- GitHub Actions workflows
- GitLab CI/CD pipelines
- Jenkins jobs
- AWS CodePipeline

### **Trust Policy - GitHub Actions (OIDC)**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowGitHubActionsOIDC",
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::123456789012:oidc-provider/token.actions.githubusercontent.com"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "token.actions.githubusercontent.com:aud": "sts.amazonaws.com"
        },
        "StringLike": {
          "token.actions.githubusercontent.com:sub": "repo:your-org/your-repo:*"
        }
      }
    }
  ]
}
```

---

### **Permissions Policy**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AssumeDeploymentRole",
      "Effect": "Allow",
      "Action": [
        "sts:AssumeRole"
      ],
      "Resource": [
        "arn:aws:iam::123456789012:role/JumpStartDeploymentRole"
      ]
    },
    {
      "Sid": "ValidateDeployment",
      "Effect": "Allow",
      "Action": [
        "sagemaker:DescribeEndpoint",
        "sagemaker:DescribeModel",
        "sagemaker:DescribeEndpointConfig"
      ],
      "Resource": "*"
    },
    {
      "Sid": "ReadConfiguration",
      "Effect": "Allow",
      "Action": [
        "s3:GetObject"
      ],
      "Resource": [
        "arn:aws:s3:::your-config-bucket/deployments/*"
      ]
    },
    {
      "Sid": "WriteLogs",
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": [
        "arn:aws:logs:us-east-1:123456789012:log-group:/aws/cicd/*"
      ]
    }
  ]
}
```

**Key Pattern:**
- CI/CD role assumes JumpStartDeploymentRole (role chaining)
- Provides audit trail of who deployed what
- Limits direct permissions on CI/CD role

---

## ROLE 5: MONITORING & OPERATIONS ROLE

### **Purpose**
Read-only access for operations team to monitor and troubleshoot SageMaker endpoints.

### **Who Uses It**
- Operations engineers
- SRE team
- On-call staff

### **Trust Policy**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowOpsTeam",
      "Effect": "Allow",
      "Principal": {
        "AWS": [
          "arn:aws:iam::123456789012:role/OpsEngineerRole"
        ]
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "IpAddress": {
          "aws:SourceIp": "203.0.113.0/24"
        }
      }
    }
  ]
}
```

---

### **Permissions Policy**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ReadOnlySageMaker",
      "Effect": "Allow",
      "Action": [
        "sagemaker:Describe*",
        "sagemaker:List*",
        "sagemaker:GetSearchSuggestions",
        "sagemaker:Search"
      ],
      "Resource": "*"
    },
    {
      "Sid": "DenyDestructiveActions",
      "Effect": "Deny",
      "Action": [
        "sagemaker:Create*",
        "sagemaker:Delete*",
        "sagemaker:Update*",
        "sagemaker:Stop*",
        "sagemaker:Start*"
      ],
      "Resource": "*"
    },
    {
      "Sid": "ReadCloudWatchLogs",
      "Effect": "Allow",
      "Action": [
        "logs:DescribeLogGroups",
        "logs:DescribeLogStreams",
        "logs:GetLogEvents",
        "logs:FilterLogEvents"
      ],
      "Resource": [
        "arn:aws:logs:us-east-1:123456789012:log-group:/aws/sagemaker/*",
        "arn:aws:logs:us-east-1:123456789012:log-group:/aws/llm-gateway/*"
      ]
    },
    {
      "Sid": "ReadCloudWatchMetrics",
      "Effect": "Allow",
      "Action": [
        "cloudwatch:GetMetricData",
        "cloudwatch:GetMetricStatistics",
        "cloudwatch:ListMetrics",
        "cloudwatch:DescribeAlarms"
      ],
      "Resource": "*"
    },
    {
      "Sid": "ReadVPCConfiguration",
      "Effect": "Allow",
      "Action": [
        "ec2:DescribeNetworkInterfaces",
        "ec2:DescribeSecurityGroups",
        "ec2:DescribeSubnets",
        "ec2:DescribeVpcs",
        "ec2:DescribeVpcEndpoints"
      ],
      "Resource": "*"
    }
  ]
}
```

**Key Features:**
- ✅ Full read access to SageMaker, CloudWatch, VPC
- ✅ Explicit DENY on all destructive actions
- ✅ Cannot accidentally delete or modify endpoints

---

## OPTIONAL: CONTAINER MIRRORING ROLE

### **Purpose**
Automated pipeline role for copying AWS ECR images to your ECR and scanning them.

### **Trust Policy**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowCodeBuildToAssumeRole",
      "Effect": "Allow",
      "Principal": {
        "Service": "codebuild.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

---

### **Permissions Policy**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PullFromAWSECR",
      "Effect": "Allow",
      "Action": [
        "ecr:GetAuthorizationToken"
      ],
      "Resource": "*"
    },
    {
      "Sid": "PullImagesFromAWS",
      "Effect": "Allow",
      "Action": [
        "ecr:BatchCheckLayerAvailability",
        "ecr:GetDownloadUrlForLayer",
        "ecr:BatchGetImage"
      ],
      "Resource": [
        "arn:aws:ecr:*:763104351884:repository/*"
      ]
    },
    {
      "Sid": "PushToYourECR",
      "Effect": "Allow",
      "Action": [
        "ecr:CompleteLayerUpload",
        "ecr:UploadLayerPart",
        "ecr:InitiateLayerUpload",
        "ecr:BatchCheckLayerAvailability",
        "ecr:PutImage"
      ],
      "Resource": [
        "arn:aws:ecr:us-east-1:123456789012:repository/pytorch-inference-scanned",
        "arn:aws:ecr:us-east-1:123456789012:repository/huggingface-tgi-scanned"
      ]
    },
    {
      "Sid": "ManageYourECRRepositories",
      "Effect": "Allow",
      "Action": [
        "ecr:CreateRepository",
        "ecr:DescribeRepositories",
        "ecr:PutImageTagMutability",
        "ecr:PutImageScanningConfiguration",
        "ecr:StartImageScan",
        "ecr:DescribeImageScanFindings"
      ],
      "Resource": [
        "arn:aws:ecr:us-east-1:123456789012:repository/*"
      ]
    },
    {
      "Sid": "ReadJumpStartModels",
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::jumpstart-cache-prod-us-east-1",
        "arn:aws:s3:::jumpstart-cache-prod-us-east-1/*"
      ]
    },
    {
      "Sid": "WriteScannedModelsToYourS3",
      "Effect": "Allow",
      "Action": [
        "s3:PutObject",
        "s3:PutObjectAcl"
      ],
      "Resource": [
        "arn:aws:s3:::your-scanned-models-bucket/*"
      ]
    },
    {
      "Sid": "WriteScanReports",
      "Effect": "Allow",
      "Action": [
        "s3:PutObject"
      ],
      "Resource": [
        "arn:aws:s3:::your-scan-reports-bucket/*"
      ]
    },
    {
      "Sid": "CodeBuildLogging",
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": [
        "arn:aws:logs:us-east-1:123456789012:log-group:/aws/codebuild/*"
      ]
    }
  ]
}
```

---

## SERVICE CONTROL POLICIES (SCPs)

### **Purpose**
Organization-wide guardrails that cannot be overridden by account administrators.

### **SCP: Enforce Network Isolation**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "RequireSageMakerNetworkIsolation",
      "Effect": "Deny",
      "Action": [
        "sagemaker:CreateModel"
      ],
      "Resource": "*",
      "Condition": {
        "Bool": {
          "sagemaker:NetworkIsolation": "false"
        }
      }
    },
    {
      "Sid": "RequireSageMakerVPC",
      "Effect": "Deny",
      "Action": [
        "sagemaker:CreateModel"
      ],
      "Resource": "*",
      "Condition": {
        "Null": {
          "sagemaker:VpcSubnets": "true"
        }
      }
    }
  ]
}
```

---

### **SCP: Restrict Allowed Regions**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "RestrictSageMakerToApprovedRegions",
      "Effect": "Deny",
      "Action": [
        "sagemaker:*"
      ],
      "Resource": "*",
      "Condition": {
        "StringNotEquals": {
          "aws:RequestedRegion": [
            "us-east-1",
            "us-west-2"
          ]
        }
      }
    }
  ]
}
```

---

## VPC ENDPOINT POLICIES

### **SageMaker Runtime VPC Endpoint Policy**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowInvokeEndpointFromVPC",
      "Effect": "Allow",
      "Principal": "*",
      "Action": [
        "sagemaker:InvokeEndpoint"
      ],
      "Resource": [
        "arn:aws:sagemaker:us-east-1:123456789012:endpoint/*"
      ],
      "Condition": {
        "StringEquals": {
          "aws:PrincipalAccount": "123456789012"
        }
      }
    },
    {
      "Sid": "DenyAllOtherActions",
      "Effect": "Deny",
      "Principal": "*",
      "NotAction": [
        "sagemaker:InvokeEndpoint"
      ],
      "Resource": "*"
    }
  ]
}
```

---

### **S3 VPC Endpoint Policy (Gateway Endpoint)**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowJumpStartS3Access",
      "Effect": "Allow",
      "Principal": "*",
      "Action": [
        "s3:GetObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::jumpstart-cache-prod-us-east-1",
        "arn:aws:s3:::jumpstart-cache-prod-us-east-1/*",
        "arn:aws:s3:::your-scanned-models-bucket",
        "arn:aws:s3:::your-scanned-models-bucket/*"
      ],
      "Condition": {
        "StringEquals": {
          "aws:PrincipalAccount": "123456789012"
        }
      }
    },
    {
      "Sid": "DenyInsecureTransport",
      "Effect": "Deny",
      "Principal": "*",
      "Action": "s3:*",
      "Resource": "*",
      "Condition": {
        "Bool": {
          "aws:SecureTransport": "false"
        }
      }
    }
  ]
}
```

---

## S3 BUCKET POLICIES

### **Your Scanned Models Bucket Policy**

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowSageMakerExecutionRole",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::123456789012:role/SageMakerExecutionRole"
      },
      "Action": [
        "s3:GetObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::your-scanned-models-bucket",
        "arn:aws:s3:::your-scanned-models-bucket/*"
      ]
    },
    {
      "Sid": "AllowMirroringRole",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::123456789012:role/ContainerMirroringRole"
      },
      "Action": [
        "s3:PutObject",
        "s3:PutObjectAcl"
      ],
      "Resource": [
        "arn:aws:s3:::your-scanned-models-bucket/*"
      ]
    },
    {
      "Sid": "DenyUnencryptedObjectUploads",
      "Effect": "Deny",
      "Principal": "*",
      "Action": "s3:PutObject",
      "Resource": "arn:aws:s3:::your-scanned-models-bucket/*",
      "Condition": {
        "StringNotEquals": {
          "s3:x-amz-server-side-encryption": "aws:kms"
        }
      }
    },
    {
      "Sid": "RequireTLS",
      "Effect": "Deny",
      "Principal": "*",
      "Action": "s3:*",
      "Resource": [
        "arn:aws:s3:::your-scanned-models-bucket",
        "arn:aws:s3:::your-scanned-models-bucket/*"
      ],
      "Condition": {
        "Bool": {
          "aws:SecureTransport": "false"
        }
      }
    }
  ]
}
```

---

## SECURITY GROUPS

### **Security Group: SageMaker Endpoint**

```
Name: sg-sagemaker-endpoint
VPC: vpc-abc12345

Inbound Rules:
- Type: HTTPS
  Protocol: TCP
  Port: 443
  Source: sg-llm-gateway
  Description: Allow inference requests from LLM Gateway

Outbound Rules:
- Type: HTTPS
  Protocol: TCP
  Port: 443
  Destination: pl-xxx (S3 prefix list - for VPC endpoint)
  Description: Allow S3 access during startup

- Type: HTTPS
  Protocol: TCP
  Port: 443
  Destination: sg-vpc-endpoint-ecr
  Description: Allow ECR access during startup

- Type: HTTPS
  Protocol: TCP
  Port: 443
  Destination: sg-vpc-endpoint-logs
  Description: Allow CloudWatch Logs

Note: With network isolation enabled, outbound rules only apply during startup
```

---

### **Security Group: LLM Gateway**

```
Name: sg-llm-gateway
VPC: vpc-abc12345

Inbound Rules:
- Type: HTTPS
  Protocol: TCP
  Port: 443
  Source: 0.0.0.0/0 (or specific CIDR)
  Description: Allow user requests

Outbound Rules:
- Type: HTTPS
  Protocol: TCP
  Port: 443
  Destination: sg-sagemaker-endpoint
  Description: Invoke SageMaker endpoints

- Type: HTTPS
  Protocol: TCP
  Port: 443
  Destination: sg-vpc-endpoint-sagemaker-runtime
  Description: SageMaker Runtime VPC endpoint
```

---

### **Security Group: VPC Endpoints**

```
Name: sg-vpc-endpoints
VPC: vpc-abc12345

Inbound Rules:
- Type: HTTPS
  Protocol: TCP
  Port: 443
  Source: sg-sagemaker-endpoint
  Description: Allow SageMaker endpoint to use VPC endpoints

- Type: HTTPS
  Protocol: TCP
  Port: 443
  Source: sg-llm-gateway
  Description: Allow LLM Gateway to use VPC endpoints

Outbound Rules:
- Type: All traffic
  Protocol: All
  Port: All
  Destination: 0.0.0.0/0
  Description: Allow VPC endpoint to reach AWS services
```

---

## COMPLETE POLICY TEMPLATES

### **Template 1: Minimal Production Setup (AWS-Managed ECR)**

**Roles Required:**
1. SageMakerExecutionRole (Option A permissions)
2. JumpStartDeploymentRole
3. LLMGatewayServiceRole

**Total Policies:** 3 roles + 2 security groups

**Use When:** Standard deployment, trust AWS-managed images

---

### **Template 2: High Security Setup (Customer-Managed ECR)**

**Roles Required:**
1. SageMakerExecutionRole (Option B permissions)
2. JumpStartDeploymentRole
3. LLMGatewayServiceRole
4. ContainerMirroringRole

**Additional Components:**
- S3 bucket for scanned models
- S3 bucket for scan reports
- ECR repositories for mirrored images
- CI/CD pipeline for image scanning

**Total Policies:** 4 roles + 3 S3 buckets + 2 security groups

**Use When:** Compliance requirements, container scanning mandatory

---

### **Template 3: Enterprise Setup (Multi-Account)**

**Additional Roles:**
- CrossAccountSageMakerRole (for shared services)
- AuditRole (for centralized logging account)

**Additional Components:**
- Organization SCPs
- Cross-account VPC peering
- Centralized logging (CloudWatch → S3 → Security Account)

**Use When:** Large organization, multiple AWS accounts, centralized governance

---

## DEPLOYMENT CHECKLIST

### **Pre-Deployment**
- [ ] All IAM roles created with correct trust policies
- [ ] Permission policies attached to roles
- [ ] SCPs applied at organization level (if applicable)
- [ ] VPC and subnets configured
- [ ] Security groups created with correct rules
- [ ] VPC endpoints created (ECR, S3, SageMaker Runtime, Logs)
- [ ] VPC endpoint policies applied
- [ ] S3 buckets created (if using customer-managed ECR)
- [ ] S3 bucket policies applied

### **Deployment**
- [ ] Test deployment with JumpStartDeploymentRole
- [ ] Verify network isolation is enforced
- [ ] Verify endpoint can pull images and models
- [ ] Test inference from LLM Gateway
- [ ] Verify CloudWatch logs are flowing
- [ ] Verify CloudWatch metrics are flowing

### **Post-Deployment**
- [ ] Test LLM Gateway → SageMaker connectivity
- [ ] Verify network isolation (check VPC Flow Logs)
- [ ] Test autoscaling
- [ ] Set up CloudWatch alarms
- [ ] Document role ARNs and endpoints
- [ ] Train operations team on monitoring

---

## COMMON MISTAKES & FIXES

### **Mistake 1: Using AmazonSageMakerFullAccess**
**Problem:** Overly permissive, grants unnecessary access  
**Fix:** Use custom policies from this document

### **Mistake 2: Not Enforcing Network Isolation**
**Problem:** Endpoints can make outbound calls  
**Fix:** Add SCP to deny CreateModel without network isolation

### **Mistake 3: Wildcard Endpoint ARNs in LLM Gateway Role**
**Problem:** Gateway can invoke ANY endpoint  
**Fix:** Whitelist specific endpoint ARNs

### **Mistake 4: Missing VPC Endpoint Policies**
**Problem:** VPC endpoints allow unrestricted access  
**Fix:** Apply least-privilege endpoint policies

### **Mistake 5: Not Using Permission Boundaries**
**Problem:** Roles can be escalated  
**Fix:** Apply permission boundaries to deployment roles

---

## TROUBLESHOOTING

### **Issue: "Access Denied" when creating endpoint**
**Cause:** Missing IAM permissions  
**Check:**
1. JumpStartDeploymentRole has `sagemaker:CreateModel` permission
2. Can pass SageMakerExecutionRole (`iam:PassRole`)
3. VPC subnets exist and are accessible

### **Issue: "Unable to pull image from ECR"**
**Cause:** Network or IAM issue  
**Check:**
1. VPC endpoints for ECR exist
2. SageMakerExecutionRole has `ecr:BatchGetImage` permission
3. Security group allows outbound HTTPS to ECR VPC endpoint
4. VPC endpoint policy allows ECR access

### **Issue: "Model download from S3 failed"**
**Cause:** S3 access blocked  
**Check:**
1. VPC endpoint for S3 exists
2. SageMakerExecutionRole has `s3:GetObject` permission
3. S3 bucket policy allows access
4. S3 VPC endpoint policy allows access

### **Issue: "InvokeEndpoint access denied from LLM Gateway"**
**Cause:** Missing permissions  
**Check:**
1. LLMGatewayServiceRole has `sagemaker:InvokeEndpoint`
2. Endpoint ARN is whitelisted in policy
3. VPC endpoint for sagemaker.runtime exists
4. Security group allows outbound to endpoint

---

**Document Version:** 1.0  
**Last Updated:** January 2026  
**Maintained By:** Cloud Security Team  
**Review Frequency:** Quarterly or on architecture changes
