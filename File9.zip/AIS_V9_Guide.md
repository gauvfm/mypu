# GenAI Security Vendor Evaluation V9 - Ultra-Compact Edition

**Evaluation Date**: January 2026  
**Framework**: 29 requirements, 290 max points  
**Vendors**: Aim, Noma, PANW, Boomi, Dataiku, MuleSoft

---

## V9 SIMPLIFICATION

### Column Reduction Journey
- **V7**: 38 columns (too many)
- **V8**: 28 columns (3 files split)
- **V9**: **16 columns** (single file, ultra-compact)

### What Changed V8 → V9

**V8 Per Vendor** (4 columns):
```
[Vendor]_Score
[Vendor]_Control
[Vendor]_Runtime
[Vendor]_Data
```

**V9 Per Vendor** (2 columns):
```
[Vendor]_Score
[Vendor]_Deployment (combined Control | Runtime | Data)
```

**Result**: 12 fewer columns, easier to scan

---

## V9 FILE STRUCTURE

### Single File: AIS_V9_Scorecard.csv

**Total Columns**: 16

**Core Columns** (4):
1. `Requirement_ID` - e.g., AIS-01
2. `Requirement_Name` - e.g., Discovery & Visibility
3. `Type` - Security or Governance
4. `Priority` - Must-Have or Nice-to-Have

**Per Vendor** (2 columns × 6 vendors = 12):
- `[Vendor]_Score` - 0-10 score
- `[Vendor]_Deployment` - Combined: "Control: X | Runtime: Y | Data: Z"

**Vendors**: Aim, Noma, PANW, Boomi, Dataiku, MuleSoft

---

## VENDOR RANKINGS (Same as V8)

| Rank | Vendor | Score | % | Gaps | Tier | Deployment Summary |
|------|--------|-------|---|------|------|-------------------|
| **1** | **Noma** | 248/290 | **85.5%** | **0** | **Tier 1** | SaaS / Agentless / Customer VPC |
| **2** | **PANW** | 231/290 | **79.7%** | **0** | **Tier 2** | SaaS or On-Prem / Inline+API / Hybrid |
| **3** | **Aim** | 225/290 | **77.6%** | **0** | **Tier 2** | SaaS / Inline / Customer |
| 4 | Dataiku | 160/290 | 55.2% | 8 | Fail | SaaS or On-Prem / Gateway / Customer |
| 5 | MuleSoft | 141/290 | 48.6% | 10 | Fail | SaaS / Gateway / Customer |
| 6 | Boomi | 118/290 | 40.7% | 13 | Fail | SaaS / Agent / Hybrid |

---

## HOW TO USE V9 SCORECARD

### Quick Vendor Selection (3 Steps)

**Step 1: Filter by Tier**
- Open `AIS_V9_Scorecard.csv`
- Focus on vendors with 0 Must-Have gaps: **Noma, PANW, Aim**
- Ignore: Boomi (13 gaps), MuleSoft (10 gaps), Dataiku (8 gaps)

**Step 2: Match Deployment Requirements**
- Read `[Vendor]_Deployment` column
- Look for your must-have deployment model

**Examples**:

| Your Requirement | Read Deployment Column For | Result |
|------------------|---------------------------|---------|
| On-prem control plane | `Control: ... On-Prem ...` | **PANW** (Panorama) |
| Agentless runtime | `Runtime: Agentless ...` | **Noma** |
| Customer VPC data only | `Data: Customer VPC ...` | **Noma** |
| Inline firewall | `Runtime: Inline ...` | **PANW, Aim** |

**Step 3: Compare Scores on Critical Requirements**
- Filter to your top 5-10 critical requirements
- Compare `[Vendor]_Score` columns
- Pick vendor with best scores + deployment match

---

## DEPLOYMENT COLUMN FORMAT

Each vendor's deployment column shows:
```
Control: [Where management lives] | Runtime: [How enforcement happens] | Data: [Where AI traffic flows]
```

### Example: Noma
```
Control: SaaS (noma.security) | Runtime: Agentless + API ingestion | Data: Customer VPC (metadata only to SaaS)
```

**Interpretation**:
- **Control**: Managed via SaaS (no on-prem option)
- **Runtime**: Zero deployment needed (agentless)
- **Data**: AI traffic stays in customer VPC (high sovereignty)

### Example: PANW
```
Control: SaaS (Strata) OR On-Prem (Panorama) | Runtime: Inline Firewall + API SDK (dual) | Data: Hybrid (Network=VPC, API=Cloud)
```

**Interpretation**:
- **Control**: Choice of SaaS or on-prem management
- **Runtime**: Can deploy inline firewall and/or API SDK
- **Data**: Network mode keeps data in VPC, API mode sends to cloud

### Example: Aim
```
Control: SaaS (aim.security) | Runtime: Inline enforcement | Data: Customer environment
```

**Interpretation**:
- **Control**: SaaS only
- **Runtime**: Requires inline deployment
- **Data**: Stays in customer environment

---

## QUICK FILTERS FOR COMMON SCENARIOS

### Scenario 1: Air-Gapped Environment
**Filter**: Deployment column contains "On-Prem"
**Result**: PANW (Panorama)
```
PANW_Deployment: Control: SaaS (Strata) OR On-Prem (Panorama) | ...
```

### Scenario 2: Zero Infrastructure Deployment
**Filter**: Deployment column contains "Agentless"
**Result**: Noma
```
Noma_Deployment: ... | Runtime: Agentless + API ingestion | ...
```

### Scenario 3: Data Sovereignty (No Cloud)
**Filter**: Deployment column Data section = "Customer VPC" or "Customer environment"
**Result**: Noma (best), Aim (good)
```
Noma_Deployment: ... | Data: Customer VPC (metadata only to SaaS)
Aim_Deployment: ... | Data: Customer environment
```

### Scenario 4: Existing Palo Alto Networks Customer
**Filter**: Vendor = PANW
**Check**: Deployment shows integration options
```
PANW_Deployment: Control: SaaS (Strata) OR On-Prem (Panorama) | Runtime: Inline Firewall + API SDK (dual) | Data: Hybrid (Network=VPC, API=Cloud)
```

---

## SAMPLE REQUIREMENT COMPARISON

### AIS-01: Discovery & Visibility

| Vendor | Score | Deployment |
|--------|-------|------------|
| **Noma** | 10/10 | Control: SaaS (noma.security) \| Runtime: Agentless + API ingestion \| Data: Customer VPC (metadata only to SaaS) |
| **PANW** | 9/10 | Control: SaaS (Strata) OR On-Prem (Panorama) \| Runtime: Inline Firewall + API SDK (dual) \| Data: Hybrid (Network=VPC, API=Cloud) |
| **Aim** | 9/10 | Control: SaaS (aim.security) \| Runtime: Inline enforcement \| Data: Customer environment |

**Analysis**:
- **Best Score**: Noma (10/10)
- **Most Flexible Deployment**: PANW (SaaS or on-prem, inline or API)
- **Simplest Deployment**: Noma (agentless)

### AIS-04: Inline Enforcement

| Vendor | Score | Deployment |
|--------|-------|------------|
| **PANW** | 10/10 | Control: SaaS (Strata) OR On-Prem (Panorama) \| Runtime: Inline Firewall + API SDK (dual) \| Data: Hybrid (Network=VPC, API=Cloud) |
| **Noma** | 9/10 | Control: SaaS (noma.security) \| Runtime: Agentless + API ingestion \| Data: Customer VPC (metadata only to SaaS) |
| **Aim** | 9/10 | Control: SaaS (aim.security) \| Runtime: Inline enforcement \| Data: Customer environment |

**Analysis**:
- **Best Score**: PANW (10/10) - dedicated AI Runtime Firewall
- **Best Inline**: PANW has purpose-built inline firewall
- **Alternative**: Aim also has inline enforcement

---

## DECISION MATRIX USING V9

### Matrix: Security Score × Deployment Fit

|  | **Agentless Runtime** | **On-Prem Control** | **Inline Firewall** | **Data Sovereignty** |
|--|---------------------|-------------------|-------------------|-------------------|
| **Noma (85.5%)** | ✅ Yes | ❌ No | ⚠️ Optional | ✅ Best |
| **PANW (79.7%)** | ❌ No | ✅ Yes | ✅ Best | ⚠️ Network mode |
| **Aim (77.6%)** | ❌ No | ❌ No | ✅ Yes | ✅ Likely |

### How to Read:
1. **Row**: Vendor with security score
2. **Column**: Your deployment requirement
3. **Cell**: Match quality (✅ Yes / ⚠️ Partial / ❌ No)

**Example**: "I need 80%+ security + agentless"
- Noma: 85.5% + ✅ Agentless = **Perfect match**
- PANW: 79.7% + ❌ No agentless = No match
- **Winner**: Noma

**Example**: "I need 75%+ security + on-prem control"
- PANW: 79.7% + ✅ On-prem = **Perfect match**
- Noma: 85.5% + ❌ No on-prem = No match
- **Winner**: PANW

---

## V9 WORKFLOW

### For Quick Selection (5 minutes):

1. **Open**: `AIS_V9_Scorecard.csv`
2. **Filter Priority**: `Priority = Must-Have` (focus on critical requirements)
3. **Scan Scores**: Compare `[Vendor]_Score` columns across top 3 vendors (Noma, PANW, Aim)
4. **Check Deployment**: Read `[Vendor]_Deployment` for deployment fit
5. **Decide**: Pick vendor with best score + deployment match

### For Thorough Evaluation (30 minutes):

1. **Open**: `AIS_V9_Scorecard.csv`
2. **Calculate averages** by Type:
   - Filter `Type = Security`, average scores per vendor
   - Filter `Type = Governance`, average scores per vendor
3. **Identify gaps**: Find requirements where vendor scores <5
4. **Read deployment details**: Parse `[Vendor]_Deployment` column fully
5. **Cross-reference**: Check `AIS_V8_Evidence_Reference.csv` for documentation proof on critical requirements
6. **Decide**: Create weighted score based on your priorities

---

## DEPLOYMENT COMPARISON AT A GLANCE

### Control Plane

| Vendor | SaaS | On-Prem | Air-Gapped |
|--------|------|---------|------------|
| Noma | ✅ Only option | ❌ | ❌ |
| PANW | ✅ Strata | ✅ Panorama | ✅ |
| Aim | ✅ Only option | ❌ | ❌ |
| Dataiku | ✅ Option | ✅ Option | ✅ |
| MuleSoft | ✅ Only option | ❌ | ❌ |
| Boomi | ✅ Only option | ❌ | ❌ |

**For Air-Gapped**: PANW or Dataiku (but Dataiku fails on security)

---

### Runtime Plane

| Vendor | Agentless | Inline | Gateway | Agent |
|--------|-----------|--------|---------|-------|
| Noma | ✅ Primary | ⚠️ Optional | ❌ | ❌ |
| PANW | ❌ | ✅ Primary | ❌ | ❌ |
| Aim | ❌ | ✅ Primary | ❌ | ❌ |
| Dataiku | ❌ | ❌ | ✅ Primary | ❌ |
| MuleSoft | ❌ | ❌ | ✅ Primary | ❌ |
| Boomi | ❌ | ❌ | ❌ | ✅ Primary |

**For Agentless**: Noma only  
**For Inline Firewall**: PANW (best), Aim (good)

---

### Data Plane

| Vendor | 100% Customer VPC | Hybrid | Vendor Cloud |
|--------|-------------------|--------|--------------|
| Noma | ✅ (metadata only) | ❌ | ❌ |
| PANW | ⚠️ Network mode | ✅ Both modes | ⚠️ API mode |
| Aim | ✅ Likely | ❌ | ❌ |
| Dataiku | ✅ (gateway local) | ❌ | ❌ |
| MuleSoft | ✅ (gateway local) | ❌ | ❌ |
| Boomi | ❌ | ✅ Primary | ⚠️ Possible |

**For Data Sovereignty**: Noma (best), PANW Network mode (good)

---

## VENDOR RECOMMENDATIONS BY USE CASE

### Use Case 1: Financial Services (Strict Compliance)
**Requirements**: Data sovereignty, SOC2/ISO27001, multi-cloud

**Recommendation**: **Noma (85.5%)**
```
Deployment: Control: SaaS (noma.security) | Runtime: Agentless + API ingestion | Data: Customer VPC (metadata only to SaaS)
```

**Why**:
- ✅ Highest security score (85.5%)
- ✅ AI traffic never leaves customer VPC
- ✅ Zero infrastructure deployment
- ✅ Multi-cloud support

**Alternative**: PANW Network Intercept mode (79.7%) if already using Palo Alto

---

### Use Case 2: Defense Contractor (Air-Gapped)
**Requirements**: On-prem control, no cloud connectivity

**Recommendation**: **PANW (79.7%)**
```
Deployment: Control: SaaS (Strata) OR On-Prem (Panorama) | Runtime: Inline Firewall + API SDK (dual) | Data: Hybrid (Network=VPC, API=Cloud)
```

**Why**:
- ✅ Panorama on-prem control plane
- ✅ Network Intercept keeps all data on-prem
- ✅ No cloud dependency required
- ✅ Only security platform with full air-gapped support

---

### Use Case 3: Startup (Limited Ops Team)
**Requirements**: Fast deployment, zero infrastructure, SaaS agents

**Recommendation**: **Noma (85.5%)**
```
Deployment: Control: SaaS (noma.security) | Runtime: Agentless + API ingestion | Data: Customer VPC (metadata only to SaaS)
```

**Why**:
- ✅ Agentless = zero deployment
- ✅ Highest security score
- ✅ No infrastructure to manage
- ✅ Native SaaS agent monitoring

---

### Use Case 4: Existing Palo Alto Customer
**Requirements**: Consolidation, existing Prisma Cloud investment

**Recommendation**: **PANW (79.7%)**
```
Deployment: Control: SaaS (Strata) OR On-Prem (Panorama) | Runtime: Inline Firewall + API SDK (dual) | Data: Hybrid (Network=VPC, API=Cloud)
```

**Why**:
- ✅ Unified Strata Cloud Manager
- ✅ VM-Series integration
- ✅ Consolidated licensing
- ✅ Single pane of glass

---

### Use Case 5: Healthcare (Kubernetes Workloads)
**Requirements**: K8s-native, HIPAA, namespace control

**Recommendation**: **PANW (79.7%)**
```
Deployment: Control: SaaS (Strata) OR On-Prem (Panorama) | Runtime: Inline Firewall + API SDK (dual) | Data: Hybrid (Network=VPC, API=Cloud)
```

**Why**:
- ✅ Namespace-level traffic steering
- ✅ Pod-to-pod inspection
- ✅ Kubernetes-native deployment
- ✅ Best K8s documentation

**Alternative**: Noma (85.5%) if you prioritize higher security score over K8s-specific features

---

## FINAL V9 RECOMMENDATIONS

### Overall Best Choice
**Noma Security (85.5%, Tier 1)**
- Highest security coverage
- Zero deployment burden
- Best data sovereignty
- **Use when**: You can accept SaaS control plane

### Best for Enterprise Complexity
**Palo Alto AIRS (79.7%, Tier 2)**
- On-prem control option (Panorama)
- Inline firewall enforcement
- Kubernetes-native
- **Use when**: You need on-prem control or already use Palo Alto

### Best for Budget-Conscious
**Aim Security (77.6%, Tier 2)**
- Lower cost than Noma/PANW
- Production-ready (0 gaps)
- Proven in finance/healthcare
- **Use when**: Cost is a constraint but need production-ready security

---

## V9 FILE REFERENCE

**Primary File**: `AIS_V9_Scorecard.csv`
- **Columns**: 16 (ultra-compact)
- **Use for**: All decision-making
- **Structure**: Requirement + Type + Priority + (Score + Deployment) per vendor

**Supporting Files** (from V8, optional):
- `AIS_V8_Evidence_Reference.csv` - Verification only
- `AIS_V8_Vendor_Summary.csv` - Executive summary

**Previous Versions**:
- V6: Security scores only (no deployment)
- V7: Added deployment (38 columns - too many)
- V8: Split into 3 files (28 + 20 + 8 columns)
- V9: Combined into single ultra-compact file (16 columns)

---

**Document Version**: V9 Ultra-Compact  
**Optimized For**: Fastest decision-making with minimum column overhead  
**Column Count**: 16 (down from 38 in V7)
