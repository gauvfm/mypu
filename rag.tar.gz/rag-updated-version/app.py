"""
RAG Document Assistant — S3-inbound edition.

Upload paths
------------
  Local (UI)  →  ./inbound/temp/          (saved locally, then vectorized)
  Local (UI)  →  s3://{bucket}/inbound/temp/  (uploaded for storage)
  System (S3) →  s3://{bucket}/inbound/files/  (auto-polled, downloaded & vectorized)

Both local and system paths feed the same chunking → embedding → FAISS pipeline.
"""
import os
import uuid
import logging
from pathlib import Path

from dotenv import load_dotenv
load_dotenv(override=True)

# Normalize S3 bucket name from any URL/URI format on startup
if os.environ.get("S3_BUCKET_NAME"):
    from utils.config_loader import extract_bucket_name as _clean
    os.environ["S3_BUCKET_NAME"] = _clean(os.environ["S3_BUCKET_NAME"])

from flask import Flask, request, jsonify, render_template, session
from flask_cors import CORS
from werkzeug.utils import secure_filename

from utils.config_loader import load_config, get_active_model_name
from utils.document_processor import load_document, chunk_documents, SUPPORTED_EXTENSIONS
from utils.embeddings_manager import get_embeddings
from utils.vector_store import add_documents, delete_index, get_indexed_files
from utils.rag_chain import query, clear_history, get_history
from utils.s3_watcher import start_watcher, stop_watcher, sync_s3_inbound, get_watcher_status, upload_to_s3, ensure_s3_synced, rebuild_from_s3

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "rag-updated-secret-2024")
CORS(app, supports_credentials=True)

config = load_config()

# Local upload directory: ./inbound/temp/
upload_folder = Path(config["app"]["upload_folder"])
upload_folder.mkdir(parents=True, exist_ok=True)
app.config["UPLOAD_FOLDER"] = str(upload_folder)
app.config["MAX_CONTENT_LENGTH"] = config["app"]["max_file_size_mb"] * 1024 * 1024

# Start background S3 watcher (no-op when bucket is not configured)
poll_interval = config.get("s3", {}).get("poll_interval_seconds", 60)
start_watcher(config, poll_interval=poll_interval)

# Ensure vector DB is synced with S3 on startup (rebuilds if empty)
logger.info("Checking S3 sync status on startup...")
sync_result = ensure_s3_synced(config)
if sync_result.get("success") and sync_result.get("indexed"):
    logger.info("Synced %d file(s) from S3 on startup", len(sync_result["indexed"]))


# ── Error handlers ────────────────────────────────────────────────────────────

@app.errorhandler(Exception)
def handle_error(e):
    logger.error("Unhandled error: %s", e, exc_info=True)
    return jsonify({"success": False, "error": str(e)}), 500


@app.errorhandler(404)
def not_found(e):
    return jsonify({"success": False, "error": "Not found"}), 404


# ── Pages ─────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    if "session_id" not in session:
        session["session_id"] = str(uuid.uuid4())
    return render_template("index.html")


@app.route("/vector-db")
def vector_db_viewer():
    """Vector database viewer page."""
    if "session_id" not in session:
        session["session_id"] = str(uuid.uuid4())
    return render_template("vector_db.html")


@app.route("/vector-db-test")
def vector_db_test():
    """Vector database test page."""
    return render_template("vector_db_test.html")


# ── Config / status ───────────────────────────────────────────────────────────

@app.route("/api/config")
def get_config():
    cfg = load_config()
    s3_cfg = cfg.get("s3", {})
    return jsonify({
        "provider":          cfg["llm"]["provider"],
        "model":             get_active_model_name(cfg),
        "chunk_size":        cfg["chunking"]["chunk_size"],
        "top_k":             cfg["retrieval"]["top_k"],
        "indexed_files":     get_indexed_files(),
        "s3_bucket":         s3_cfg.get("bucket_name", ""),
        "s3_inbound_prefix": s3_cfg.get("inbound_prefix", "inbound/files/"),
        "s3_upload_prefix":  s3_cfg.get("upload_prefix", "inbound/temp/"),
    })


@app.route("/api/health")
def health():
    cfg = load_config()
    watcher = get_watcher_status()
    return jsonify({
        "status":        "ok",
        "model":         get_active_model_name(cfg),
        "indexed_files": len(get_indexed_files()),
        "s3_watcher":    watcher.get("running", False),
    })


# ── Document upload (local UI) ────────────────────────────────────────────────

@app.route("/api/upload", methods=["POST"])
def upload_document():
    """
    Accepts a file from the browser.
    Saves it to ./inbound/temp/, uploads to s3://bucket/upload_prefix/, then chunks + embeds + indexes it.
    """
    if "file" not in request.files:
        return jsonify({"success": False, "error": "No file provided"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"success": False, "error": "No filename"}), 400

    ext = Path(file.filename).suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        return jsonify({
            "success": False,
            "error": f"Unsupported type '{ext}'. Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}",
        }), 400

    filename  = secure_filename(file.filename)
    save_path = upload_folder / filename
    file.save(str(save_path))
    logger.info("Local upload saved to %s", save_path)

    # Upload to S3 inbound/temp/
    cfg = load_config()
    upload_prefix = cfg.get("s3", {}).get("upload_prefix", "inbound/temp/")
    s3_key = f"{upload_prefix.rstrip('/')}/{filename}"
    s3_uploaded = upload_to_s3(cfg, str(save_path), s3_key)
    if s3_uploaded:
        logger.info("Uploaded to S3: %s", s3_key)
    else:
        logger.warning("Failed to upload to S3, but continuing with local processing")

    docs, error = load_document(str(save_path))
    if error:
        return jsonify({"success": False, "error": error}), 400
    if not docs:
        return jsonify({"success": False, "error": "No text could be extracted"}), 400

    chunks    = chunk_documents(docs, cfg)
    embeddings = get_embeddings(cfg)
    success, msg = add_documents(chunks, embeddings, cfg)

    return jsonify({
        "success":  success,
        "message":  msg,
        "filename": filename,
        "source":   "local",
        "pages":    len(docs),
        "chunks":   len(chunks),
        "s3_uploaded": s3_uploaded,
    })


# ── Chat ──────────────────────────────────────────────────────────────────────

@app.route("/api/chat", methods=["POST"])
def chat():
    data     = request.get_json()
    question = (data.get("question") or "").strip()
    if not question:
        return jsonify({"success": False, "error": "Question is required"}), 400

    session_id = session.get("session_id", str(uuid.uuid4()))
    cfg        = load_config()
    result     = query(question, session_id, cfg)
    return jsonify({"success": True, **result})


# ── History / index management ────────────────────────────────────────────────

@app.route("/api/history/clear", methods=["POST"])
def clear_chat():
    clear_history(session.get("session_id", ""))
    return jsonify({"success": True})


@app.route("/api/index/clear", methods=["POST"])
def clear_idx():
    """Clear local index and rebuild from S3 (S3 is source of truth)."""
    cfg = load_config()
    delete_index(cfg)
    logger.info("Local index cleared, rebuilding from S3...")

    # Rebuild from S3 immediately (S3 is persistent storage)
    sync_result = rebuild_from_s3(cfg)

    if sync_result.get("success"):
        indexed_count = len(sync_result.get("indexed", []))
        return jsonify({
            "success": True,
            "message": f"Index cleared and rebuilt from S3 ({indexed_count} files)",
            "rebuilt": indexed_count,
        })
    else:
        return jsonify({
            "success": True,
            "message": "Index cleared (no S3 files to rebuild)",
            "rebuilt": 0,
        })


# ── S3 integration endpoints ──────────────────────────────────────────────────

@app.route("/api/s3/sync", methods=["POST"])
def s3_sync():
    """
    Manually trigger an immediate S3 inbound sync
    (same logic the background watcher runs automatically).
    """
    cfg    = load_config()
    result = sync_s3_inbound(cfg)
    return jsonify({"success": result.get("success", False), **result})


@app.route("/api/s3/status")
def s3_status():
    """Return current S3 watcher state and configuration."""
    cfg = load_config()
    s3_cfg = cfg.get("s3", {})
    return jsonify({
        "watcher":        get_watcher_status(),
        "bucket":         s3_cfg.get("bucket_name", ""),
        "inbound_prefix": s3_cfg.get("inbound_prefix", "inbound/files/"),
        "poll_interval":  s3_cfg.get("poll_interval_seconds", 60),
    })


@app.route("/api/s3/rebuild", methods=["POST"])
def s3_rebuild():
    """
    Force rebuild vector database from all S3 files.
    This re-indexes everything from S3 (source of truth).
    """
    cfg = load_config()
    result = rebuild_from_s3(cfg)
    return jsonify({"success": result.get("success", False), **result})


@app.route("/api/vector-db/test")
def test_vector_db():
    """Simple test endpoint."""
    return jsonify({"success": True, "message": "Test endpoint works"})


@app.route("/api/vector-db/browse")
def browse_vector_db():
    """Browse vector database contents. Auto-syncs from S3 if empty."""
    try:
        from utils.vector_store import get_vector_store
        from pathlib import Path
        import pickle

        cfg = load_config()
        index_path = Path(cfg["vector_store"]["index_path"])

        # Get basic stats
        faiss_file = index_path / "index.faiss"
        pkl_file = index_path / "index.pkl"

        if not faiss_file.exists():
            # Try to rebuild from S3 if configured
            bucket = cfg.get("s3", {}).get("bucket_name", "").strip()
            if bucket:
                logger.info("Vector DB empty, attempting to rebuild from S3...")
                sync_result = rebuild_from_s3(cfg)

                # Check again if we successfully rebuilt
                if faiss_file.exists():
                    logger.info("Successfully rebuilt from S3, continuing to browse...")
                    # Fall through to the normal browse logic
                else:
                    # S3 sync completed but no files found
                    return jsonify({
                        "success": True,
                        "empty": True,
                        "synced": True,
                        "message": "No documents in S3 to sync",
                        "stats": {
                            "index_size_kb": 0,
                            "pkl_size_kb": 0,
                            "indexed_files": [],
                            "total_vectors": 0,
                            "vector_dimension": 0,
                            "total_documents": 0,
                        },
                        "documents": [],
                    })
            else:
                # No S3 configured, return empty state
                return jsonify({
                    "success": True,
                    "empty": True,
                    "message": "No documents indexed. Upload files or configure S3.",
                    "stats": {
                        "index_size_kb": 0,
                        "pkl_size_kb": 0,
                        "indexed_files": [],
                        "total_vectors": 0,
                        "vector_dimension": 0,
                        "total_documents": 0,
                    },
                    "documents": [],
                })

        # Index exists, proceed with normal browse

        stats = {
            "index_size_kb": faiss_file.stat().st_size / 1024,
            "pkl_size_kb": pkl_file.stat().st_size / 1024,
            "indexed_files": get_indexed_files(),
        }

        # Get vector store
        vector_store = get_vector_store()
        if vector_store is None:
            embeddings = get_embeddings(cfg)
            from langchain_community.vectorstores import FAISS
            vector_store = FAISS.load_local(
                str(index_path),
                embeddings,
                allow_dangerous_deserialization=True
            )

        stats["total_vectors"] = vector_store.index.ntotal
        stats["vector_dimension"] = vector_store.index.d

        # Get sample documents
        documents = []
        if hasattr(vector_store, 'docstore') and hasattr(vector_store.docstore, '_dict'):
            docs = vector_store.docstore._dict
            stats["total_documents"] = len(docs)

            # Get first 50 documents for display
            for doc_id, doc in list(docs.items())[:50]:
                documents.append({
                    "id": doc_id[:12],
                    "filename": doc.metadata.get("filename", "unknown"),
                    "page": doc.metadata.get("page", "N/A"),
                    "chunk": doc.metadata.get("chunk", "N/A"),
                    "content": doc.page_content[:300],
                    "content_length": len(doc.page_content),
                })

        return jsonify({
            "success": True,
            "empty": False,
            "stats": stats,
            "documents": documents,
        })

    except Exception as e:
        logger.error(f"Error browsing vector database: {e}", exc_info=True)
        return jsonify({"success": False, "error": str(e)})


@app.route("/api/vector-db/search", methods=["POST"])
def search_vector_db():
    """Search vector database."""
    try:
        data = request.get_json()
        query = (data.get("query") or "").strip()
        k = int(data.get("k", 5))

        if not query:
            return jsonify({"success": False, "error": "Query is required"})

        cfg = load_config()
        from utils.vector_store import get_vector_store
        from pathlib import Path

        # Check if index exists
        index_path = Path(cfg["vector_store"]["index_path"])
        faiss_file = index_path / "index.faiss"

        if not faiss_file.exists():
            return jsonify({
                "success": False,
                "error": "Vector database is empty. Please upload documents first."
            })

        embeddings = get_embeddings(cfg)
        vector_store = get_vector_store()
        if vector_store is None:
            from langchain_community.vectorstores import FAISS
            vector_store = FAISS.load_local(
                str(index_path),
                embeddings,
                allow_dangerous_deserialization=True
            )

        results = vector_store.similarity_search_with_score(query, k=k)

        documents = []
        for doc, score in results:
            documents.append({
                "filename": doc.metadata.get("filename", "unknown"),
                "page": doc.metadata.get("page", "N/A"),
                "chunk": doc.metadata.get("chunk", "N/A"),
                "content": doc.page_content,
                "score": float(score),
            })

        return jsonify({
            "success": True,
            "query": query,
            "results": documents,
        })

    except Exception as e:
        logger.error(f"Error searching vector database: {e}", exc_info=True)
        return jsonify({"success": False, "error": str(e)})


# ── Entry point ───────────────────────────────────────────────────────────────

def get_sagemaker_studio_url(port):
    """
    Detect if running in SageMaker Studio and construct the proper URL.
    Returns the SageMaker Studio URL or None if not in SageMaker.
    """
    try:
        # First, try reading the SageMaker metadata file
        metadata_path = "/opt/ml/metadata/resource-metadata.json"
        if os.path.exists(metadata_path):
            import json
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
                domain_id = metadata.get("DomainId")

                # Get region from environment or metadata
                region = os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION", "us-east-1")

                if domain_id:
                    # Standard SageMaker Studio URL format
                    studio_url = f"https://{domain_id}.studio.{region}.sagemaker.aws/jupyterlab/default/proxy/{port}/"
                    return studio_url

        # Fallback: Check for environment variables
        domain_id = os.environ.get("SAGEMAKER_DOMAIN_ID")
        region = os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION")

        if domain_id and region:
            studio_url = f"https://{domain_id}.studio.{region}.sagemaker.aws/jupyterlab/default/proxy/{port}/"
            return studio_url

    except Exception as e:
        logger.debug(f"Could not determine SageMaker Studio URL: {e}")

    return None


if __name__ == "__main__":
    port = int(os.environ.get("PORT", config["app"]["port"]))
    host = config["app"]["host"]

    logger.info("RAG Document Assistant (S3-inbound edition) starting on port %d", port)

    # Print URL/endpoint information
    print("\n" + "="*70)
    print("🚀 RAG Document Assistant - S3-inbound Edition")
    print("="*70)
    print(f"✓ Server starting on host: {host}")
    print(f"✓ Port: {port}")
    print(f"\n📍 Access the application at:")

    # Check for SageMaker Studio URL
    sagemaker_url = get_sagemaker_studio_url(port)
    if sagemaker_url:
        print(f"\n   🔗 SageMaker Studio URL:")
        print(f"   → {sagemaker_url}")
        print(f"\n   🔗 Local URLs:")

    print(f"   → http://localhost:{port}")
    print(f"   → http://127.0.0.1:{port}")
    if host == "0.0.0.0":
        print(f"   → http://0.0.0.0:{port} (all network interfaces)")

    print("\n💡 Press Ctrl+C to stop the server")
    print("="*70 + "\n")

    try:
        app.run(
            host=host,
            port=port,
            debug=config["app"]["debug"],
        )
    finally:
        stop_watcher()
