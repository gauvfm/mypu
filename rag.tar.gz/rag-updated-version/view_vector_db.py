"""
Utility script to view FAISS vector database contents.
"""
import pickle
import json
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(override=True)

# Normalize S3 bucket name from any URL/URI format on startup
import os
if os.environ.get("S3_BUCKET_NAME"):
    from utils.config_loader import extract_bucket_name as _clean
    os.environ["S3_BUCKET_NAME"] = _clean(os.environ["S3_BUCKET_NAME"])

from utils.config_loader import load_config
from utils.embeddings_manager import get_embeddings
from langchain_community.vectorstores import FAISS


def view_vector_database():
    """View the contents of the FAISS vector database."""

    config = load_config()
    index_path = Path(config["vector_store"]["index_path"])

    print("\n" + "="*80)
    print("📊 FAISS Vector Database Viewer")
    print("="*80)

    # Check if index exists
    faiss_file = index_path / "index.faiss"
    pkl_file = index_path / "index.pkl"
    meta_file = index_path / "indexed_files.json"

    if not faiss_file.exists():
        print("❌ No FAISS index found at:", index_path)
        return

    print(f"\n📁 Database Location: {index_path}")
    print(f"   - index.faiss: {faiss_file.stat().st_size / 1024:.2f} KB")
    print(f"   - index.pkl: {pkl_file.stat().st_size / 1024:.2f} KB")

    # Load indexed files metadata
    if meta_file.exists():
        with open(meta_file) as f:
            indexed_files = json.load(f)
        print(f"\n📄 Indexed Files ({len(indexed_files)}):")
        for file_info in indexed_files:
            print(f"   - {file_info['filename']}: {file_info['chunks']} chunks")

    # Load FAISS index
    print("\n⏳ Loading FAISS index...")
    try:
        embeddings = get_embeddings(config)
        vector_store = FAISS.load_local(
            str(index_path),
            embeddings,
            allow_dangerous_deserialization=True
        )

        # Get index statistics
        print("\n📈 Vector Store Statistics:")
        print(f"   - Total vectors: {vector_store.index.ntotal}")
        print(f"   - Vector dimension: {vector_store.index.d}")

        # Load and display document metadata from pickle file
        with open(pkl_file, 'rb') as f:
            pkl_data = pickle.load(f)

        # The pickle contains docstore and index_to_docstore_id
        if hasattr(pkl_data, '__len__'):
            print(f"   - Documents in docstore: {len(pkl_data)}")

        # Try to access documents
        if hasattr(vector_store, 'docstore'):
            docstore = vector_store.docstore
            if hasattr(docstore, '_dict'):
                docs = docstore._dict
                print(f"   - Stored documents: {len(docs)}")

                print("\n📝 Sample Documents (first 3):")
                for i, (doc_id, doc) in enumerate(list(docs.items())[:3]):
                    print(f"\n   Document {i+1} (ID: {doc_id[:8]}...):")
                    print(f"   - Source: {doc.metadata.get('filename', 'unknown')}")
                    print(f"   - Page: {doc.metadata.get('page', 'N/A')}")
                    print(f"   - Chunk: {doc.metadata.get('chunk', 'N/A')}")
                    content_preview = doc.page_content[:200].replace('\n', ' ')
                    print(f"   - Content: {content_preview}...")

                # Statistics by file
                print("\n📊 Documents by Source File:")
                file_counts = {}
                for doc in docs.values():
                    filename = doc.metadata.get('filename', 'unknown')
                    file_counts[filename] = file_counts.get(filename, 0) + 1

                for filename, count in sorted(file_counts.items()):
                    print(f"   - {filename}: {count} chunks")

        print("\n" + "="*80)

        # Interactive query option
        print("\n💡 You can query the database interactively:")
        print("   Example: vector_store.similarity_search('your query', k=5)")
        print("\nWould you like to run a test query? (yes/no)")

        response = input("> ").strip().lower()
        if response in ['yes', 'y']:
            query = input("\nEnter your query: ").strip()
            if query:
                print(f"\n🔍 Searching for: '{query}'")
                results = vector_store.similarity_search(query, k=3)
                print(f"\n📋 Top {len(results)} Results:")
                for i, doc in enumerate(results, 1):
                    print(f"\n   Result {i}:")
                    print(f"   - Source: {doc.metadata.get('filename', 'unknown')}")
                    print(f"   - Page: {doc.metadata.get('page', 'N/A')}")
                    content = doc.page_content[:300].replace('\n', ' ')
                    print(f"   - Content: {content}...")

        print("\n✅ Database inspection complete!")

    except Exception as e:
        print(f"\n❌ Error loading database: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    view_vector_database()
