"""
Document Processor — handles local uploads and S3 sources.
Supports PDF, DOCX, PPTX, XLSX, TXT, MD.
"""
import os
import io
import logging
import tempfile
from pathlib import Path
from typing import List, Tuple

from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter

logger = logging.getLogger(__name__)

SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".pptx", ".txt", ".md", ".xlsx", ".csv"}


def load_document(file_path: str) -> Tuple[List[Document], str]:
    """Load a document from a local file path. Returns (docs, error_message)."""
    ext = Path(file_path).suffix.lower()
    filename = Path(file_path).name

    try:
        if ext == ".pdf":
            docs = _load_pdf(file_path, filename)
        elif ext == ".docx":
            docs = _load_docx(file_path, filename)
        elif ext == ".pptx":
            docs = _load_pptx(file_path, filename)
        elif ext in (".txt", ".md"):
            docs = _load_text(file_path, filename)
        elif ext in (".xlsx", ".csv"):
            docs = _load_tabular(file_path, filename)
        else:
            return [], f"Unsupported file type: {ext}"

        logger.info(f"Loaded {len(docs)} pages/sections from {filename}")
        return docs, ""
    except Exception as e:
        logger.error(f"Error loading {filename}: {e}")
        return [], str(e)


def load_from_s3(bucket: str, key: str, s3_client) -> Tuple[List[Document], str]:
    """Download a document from S3 and load it."""
    ext = Path(key).suffix.lower()
    filename = Path(key).name

    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        content = response["Body"].read()

        with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp:
            tmp.write(content)
            tmp_path = tmp.name

        docs, error = load_document(tmp_path)
        os.unlink(tmp_path)

        # Update metadata to reflect S3 source
        for doc in docs:
            doc.metadata["source"] = f"s3://{bucket}/{key}"
            doc.metadata["filename"] = filename

        return docs, error
    except Exception as e:
        logger.error(f"Error loading from S3 s3://{bucket}/{key}: {e}")
        return [], str(e)


def list_s3_documents(bucket: str, prefix: str, s3_client) -> List[dict]:
    """List documents available in S3 bucket under prefix."""
    try:
        paginator = s3_client.get_paginator("list_objects_v2")
        pages = paginator.paginate(Bucket=bucket, Prefix=prefix)

        files = []
        for page in pages:
            for obj in page.get("Contents", []):
                key = obj["Key"]
                ext = Path(key).suffix.lower()
                if ext in SUPPORTED_EXTENSIONS:
                    files.append({
                        "key": key,
                        "filename": Path(key).name,
                        "size": obj["Size"],
                        "last_modified": obj["LastModified"].isoformat(),
                    })
        return files
    except Exception as e:
        logger.error(f"Error listing S3 documents: {e}")
        return []


def chunk_documents(docs: List[Document], config: dict) -> List[Document]:
    """Split documents into chunks for embedding."""
    chunk_cfg = config.get("chunking", {})
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_cfg.get("chunk_size", 1000),
        chunk_overlap=chunk_cfg.get("chunk_overlap", 200),
        separators=chunk_cfg.get("separators", ["\n\n", "\n", " ", ""]),
    )
    chunks = splitter.split_documents(docs)
    logger.info(f"Split {len(docs)} documents into {len(chunks)} chunks")
    return chunks


# ── Private loaders ──────────────────────────────────────────────────────────

def _load_pdf(path: str, filename: str) -> List[Document]:
    from pypdf import PdfReader
    reader = PdfReader(path)
    docs = []
    for i, page in enumerate(reader.pages):
        text = page.extract_text() or ""
        if text.strip():
            docs.append(Document(
                page_content=text,
                metadata={"source": filename, "filename": filename, "page": i + 1, "type": "pdf"},
            ))
    return docs


def _load_docx(path: str, filename: str) -> List[Document]:
    from docx import Document as DocxDocument
    doc = DocxDocument(path)
    text = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
    return [Document(
        page_content=text,
        metadata={"source": filename, "filename": filename, "type": "docx"},
    )]


def _load_pptx(path: str, filename: str) -> List[Document]:
    from pptx import Presentation
    prs = Presentation(path)
    docs = []
    for i, slide in enumerate(prs.slides):
        texts = []
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text.strip():
                texts.append(shape.text)
        if texts:
            docs.append(Document(
                page_content="\n".join(texts),
                metadata={"source": filename, "filename": filename, "slide": i + 1, "type": "pptx"},
            ))
    return docs


def _load_text(path: str, filename: str) -> List[Document]:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()
    return [Document(
        page_content=text,
        metadata={"source": filename, "filename": filename, "type": "text"},
    )]


def _load_tabular(path: str, filename: str) -> List[Document]:
    ext = Path(path).suffix.lower()
    if ext == ".csv":
        import csv
        rows = []
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            reader = csv.reader(f)
            for row in reader:
                rows.append(", ".join(row))
        text = "\n".join(rows)
    else:
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        rows = []
        for sheet in wb.worksheets:
            for row in sheet.iter_rows(values_only=True):
                row_text = ", ".join(str(c) for c in row if c is not None)
                if row_text.strip():
                    rows.append(row_text)
        text = "\n".join(rows)

    return [Document(
        page_content=text,
        metadata={"source": filename, "filename": filename, "type": ext[1:]},
    )]
