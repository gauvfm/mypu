"""
RAG Query Engine — single RAG-only response with citations.
"""
import logging
import time
from typing import List, Dict, Any, Tuple

from langchain.schema import Document, HumanMessage, SystemMessage, AIMessage

from utils.llm_manager import count_tokens, calculate_cost, get_llm
from utils.embeddings_manager import get_embeddings
from utils.vector_store import search_with_scores
from utils.config_loader import get_active_model_name

logger = logging.getLogger(__name__)

_conversation_history: Dict[str, List[dict]] = {}

RAG_SYSTEM_PROMPT = """You are a helpful assistant that answers questions based on the provided context documents.
Use the context to answer the question accurately and cite the sources naturally in your response.
If the context doesn't contain enough information, say so and provide what you can from general knowledge.
Be concise, clear, and helpful."""


def query(question: str, session_id: str, config: dict) -> Dict[str, Any]:
    start_time = time.time()
    model_name = get_active_model_name(config)

    if session_id not in _conversation_history:
        _conversation_history[session_id] = []
    history = _conversation_history[session_id]

    # Retrieve relevant chunks
    embeddings = get_embeddings(config)
    retrieved = search_with_scores(question, embeddings, config)
    citations = _build_citations(retrieved)

    # RAG answer
    answer, tokens = _get_rag_answer(question, history, retrieved, config, model_name)

    # Update history
    history.append({"role": "user", "content": question})
    history.append({"role": "assistant", "content": answer})
    if len(history) > 40:
        _conversation_history[session_id] = history[-40:]

    cost = calculate_cost(tokens["input"], tokens["output"], config, model_name)
    elapsed = round(time.time() - start_time, 2)

    return {
        "question": question,
        "answer": answer,
        "citations": citations,
        "context_used": len(retrieved) > 0,
        "metrics": {**cost, "response_time_sec": elapsed},
        "model": model_name,
        "session_id": session_id,
    }


def clear_history(session_id: str):
    _conversation_history.pop(session_id, None)


def get_history(session_id: str) -> List[dict]:
    return _conversation_history.get(session_id, [])


def _get_rag_answer(question, history, retrieved, config, model_name):
    try:
        llm = get_llm(config)
        if retrieved:
            parts = []
            for i, (doc, score) in enumerate(retrieved):
                fname = doc.metadata.get("filename", "unknown")
                page = doc.metadata.get("page", "")
                page_info = f" (page {page})" if page else ""
                parts.append(f"[Source {i+1}: {fname}{page_info}]\n{doc.page_content}")
            context = "\n\n---\n\n".join(parts)
            user_msg = f"Context:\n{context}\n\nQuestion: {question}"
        else:
            user_msg = f"(No relevant documents found)\n\nQuestion: {question}"

        messages = [SystemMessage(content=RAG_SYSTEM_PROMPT)]
        messages += _history_to_messages(history[-10:])
        messages.append(HumanMessage(content=user_msg))

        input_tokens = count_tokens(RAG_SYSTEM_PROMPT + user_msg, model_name)
        response = llm.invoke(messages)
        answer = response.content if hasattr(response, "content") else str(response)
        output_tokens = count_tokens(answer, model_name)
        return answer, {"input": input_tokens, "output": output_tokens}
    except Exception as e:
        logger.error(f"RAG error: {e}")
        return f"Error: {str(e)}", {"input": 0, "output": 0}


def _build_citations(retrieved):
    return [
        {
            "index": i + 1,
            "source": doc.metadata.get("filename", "unknown"),
            "page": doc.metadata.get("page", ""),
            "slide": doc.metadata.get("slide", ""),
            "similarity_score": round(float(score), 4),
            "excerpt": doc.page_content[:300] + ("..." if len(doc.page_content) > 300 else ""),
        }
        for i, (doc, score) in enumerate(retrieved)
    ]


def _history_to_messages(history):
    msgs = []
    for m in history:
        if m["role"] == "user":
            msgs.append(HumanMessage(content=m["content"]))
        elif m["role"] == "assistant":
            msgs.append(AIMessage(content=m["content"]))
    return msgs
