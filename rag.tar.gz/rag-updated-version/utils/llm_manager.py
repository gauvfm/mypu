"""
LLM Manager — supports AWS Bedrock, OpenAI, and Anthropic providers.
Returns a LangChain-compatible chat model plus token/cost helpers.
"""
import os
import logging
from typing import Tuple

logger = logging.getLogger(__name__)


def get_llm(config: dict):
    """Return a LangChain LLM instance based on config provider."""
    provider = config["llm"]["provider"]

    if provider == "bedrock":
        return _get_bedrock_llm(config)
    elif provider == "openai":
        return _get_openai_llm(config)
    elif provider == "anthropic":
        return _get_anthropic_llm(config)
    else:
        raise ValueError(f"Unsupported LLM provider: {provider}")


def _get_bedrock_llm(config: dict):
    from langchain_aws import ChatBedrock
    import boto3

    bedrock_cfg = config["llm"]["bedrock"]
    session_kwargs = {"region_name": bedrock_cfg["region"]}

    if bedrock_cfg.get("aws_access_key_id"):
        session_kwargs["aws_access_key_id"] = bedrock_cfg["aws_access_key_id"]
        session_kwargs["aws_secret_access_key"] = bedrock_cfg["aws_secret_access_key"]
        if bedrock_cfg.get("aws_session_token"):
            session_kwargs["aws_session_token"] = bedrock_cfg["aws_session_token"]

    session = boto3.Session(**session_kwargs)
    client = session.client("bedrock-runtime")

    return ChatBedrock(
        client=client,
        model_id=bedrock_cfg["model_id"],
        model_kwargs={
            "max_tokens": bedrock_cfg.get("max_tokens", 1024),
            "temperature": bedrock_cfg.get("temperature", 0.7),
        },
    )


def _get_openai_llm(config: dict):
    from langchain_openai import ChatOpenAI

    openai_cfg = config["llm"]["openai"]
    api_key = openai_cfg.get("api_key") or os.environ.get("OPENAI_API_KEY")

    return ChatOpenAI(
        api_key=api_key,
        model=openai_cfg["model"],
        max_tokens=openai_cfg.get("max_tokens", 1024),
        temperature=openai_cfg.get("temperature", 0.7),
    )


def _get_anthropic_llm(config: dict):
    from langchain_anthropic import ChatAnthropic

    anthropic_cfg = config["llm"]["anthropic"]
    api_key = anthropic_cfg.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")

    return ChatAnthropic(
        api_key=api_key,
        model=anthropic_cfg["model"],
        max_tokens=anthropic_cfg.get("max_tokens", 1024),
        temperature=anthropic_cfg.get("temperature", 0.7),
    )


def count_tokens(text: str, model: str = "gpt-3.5-turbo") -> int:
    """Approximate token count using tiktoken or simple heuristic."""
    try:
        import tiktoken
        try:
            enc = tiktoken.encoding_for_model(model)
        except KeyError:
            enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(text))
    except Exception:
        # Fallback: ~4 chars per token
        return max(1, len(text) // 4)


def calculate_cost(input_tokens: int, output_tokens: int, config: dict, model_name: str) -> dict:
    """Calculate approximate cost for a request."""
    from utils.config_loader import get_cost_rates
    rates = get_cost_rates(config, model_name)

    input_cost = (input_tokens / 1000) * rates["input"]
    output_cost = (output_tokens / 1000) * rates["output"]
    total_cost = input_cost + output_cost

    return {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": input_tokens + output_tokens,
        "input_cost_usd": round(input_cost, 6),
        "output_cost_usd": round(output_cost, 6),
        "total_cost_usd": round(total_cost, 6),
        "model": model_name,
    }
