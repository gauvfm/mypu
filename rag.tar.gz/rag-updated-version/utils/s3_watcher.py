"""
S3 Watcher — polls s3://{bucket}/inbound/files/ for new documents
and automatically indexes them into the FAISS vector store.

Files uploaded via UI land in ./inbound/temp/ (local) and s3://{bucket}/inbound/temp/ (storage).
Files placed by the system land in s3://{bucket}/inbound/files/.
Both local and system paths feed the same vectorization pipeline.
"""
import json
import logging
import threading
import time
from pathlib import Path
from typing import Callable, Optional

import boto3

from utils.document_processor import SUPPORTED_EXTENSIONS, chunk_documents, load_from_s3

logger = logging.getLogger(__name__)

# ── Module-level watcher state ────────────────────────────────────────────────

_watcher_thread: Optional[threading.Thread] = None
_watcher_stop = threading.Event()

_watcher_status = {
    "running": False,
    "last_sync": None,
    "files_processed": 0,
    "last_error": None,
}

_PROCESSED_KEYS_FILE = Path("./faiss_index/s3_processed_keys.json")
_processed_keys: set = set()


# ── Processed-key persistence ─────────────────────────────────────────────────

def _load_processed_keys():
    global _processed_keys
    if _PROCESSED_KEYS_FILE.exists():
        try:
            with open(_PROCESSED_KEYS_FILE) as f:
                _processed_keys = set(json.load(f))
        except Exception:
            _processed_keys = set()


def _save_processed_keys():
    _PROCESSED_KEYS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(_PROCESSED_KEYS_FILE, "w") as f:
        json.dump(list(_processed_keys), f)


# ── S3 client factory ─────────────────────────────────────────────────────────

def get_s3_client(config: dict):
    """Build a boto3 S3 client using the same AWS credentials as Bedrock."""
    bedrock_cfg = config["llm"]["bedrock"]
    s3_cfg = config.get("s3", {})
    region = s3_cfg.get("region", bedrock_cfg.get("region", "us-east-1"))

    kwargs = {"region_name": region}
    if bedrock_cfg.get("aws_access_key_id"):
        kwargs["aws_access_key_id"] = bedrock_cfg["aws_access_key_id"]
        kwargs["aws_secret_access_key"] = bedrock_cfg["aws_secret_access_key"]
        if bedrock_cfg.get("aws_session_token"):
            kwargs["aws_session_token"] = bedrock_cfg["aws_session_token"]

    return boto3.Session(**kwargs).client("s3")


def upload_to_s3(config: dict, local_path: str, s3_key: str) -> bool:
    """Upload a local file to S3."""
    bucket = config.get("s3", {}).get("bucket_name", "").strip()
    if not bucket:
        return False

    try:
        s3 = get_s3_client(config)
        s3.upload_file(local_path, bucket, s3_key)
        logger.info("Uploaded %s to s3://%s/%s", local_path, bucket, s3_key)
        return True
    except Exception as exc:
        logger.error("Failed to upload %s to S3: %s", local_path, exc)
        return False


# ── Core sync logic ───────────────────────────────────────────────────────────

def sync_s3_inbound(config: dict, on_indexed: Optional[Callable] = None, force_rebuild: bool = False) -> dict:
    """
    Scan S3 inbound/files/ prefix, download and index any new documents.

    Args:
        config:       Loaded app config dict.
        on_indexed:   Optional callback(filename, chunks) called per indexed file.
        force_rebuild: If True, re-index all files from S3 (ignore processed keys).

    Returns:
        {
            "success": bool,
            "new_files": int,
            "indexed": [{"key", "filename", "chunks"}, ...],
            "errors":  [{"key", "error"}, ...],
        }
    """
    from utils.embeddings_manager import get_embeddings
    from utils.vector_store import add_documents

    bucket = config.get("s3", {}).get("bucket_name", "").strip()
    inbound_prefix = config.get("s3", {}).get("inbound_prefix", "inbound/files/")

    if not bucket:
        return {"success": False, "error": "S3 bucket not configured", "new_files": 0}

    _load_processed_keys()

    try:
        s3 = get_s3_client(config)

        # List all supported files under inbound_prefix
        paginator = s3.get_paginator("list_objects_v2")
        new_keys = []
        for page in paginator.paginate(Bucket=bucket, Prefix=inbound_prefix):
            for obj in page.get("Contents", []):
                key = obj["Key"]
                if key == inbound_prefix:          # skip the "folder" placeholder
                    continue
                if Path(key).suffix.lower() in SUPPORTED_EXTENSIONS:
                    # If force_rebuild, index all files; otherwise only new ones
                    if force_rebuild or key not in _processed_keys:
                        new_keys.append(key)

        if not new_keys:
            logger.info("S3 sync: no new files under s3://%s/%s", bucket, inbound_prefix)
            return {"success": True, "new_files": 0, "indexed": [], "errors": []}

        logger.info("S3 sync: %d new file(s) found: %s", len(new_keys), new_keys)

        embeddings = get_embeddings(config)
        indexed, errors = [], []

        for key in new_keys:
            filename = Path(key).name
            logger.info("S3 sync: indexing %s", key)
            try:
                docs, error = load_from_s3(bucket, key, s3)
                if error or not docs:
                    errors.append({"key": key, "error": error or "No text extracted"})
                    continue

                chunks = chunk_documents(docs, config)
                success, msg = add_documents(chunks, embeddings, config)

                if success:
                    _processed_keys.add(key)
                    _save_processed_keys()
                    indexed.append({"key": key, "filename": filename, "chunks": len(chunks)})
                    logger.info("S3 sync: indexed %s (%d chunks)", filename, len(chunks))
                    if on_indexed:
                        on_indexed(filename, len(chunks))
                else:
                    errors.append({"key": key, "error": msg})

            except Exception as exc:
                logger.error("S3 sync error for %s: %s", key, exc)
                errors.append({"key": key, "error": str(exc)})

        return {
            "success": True,
            "new_files": len(new_keys),
            "indexed": indexed,
            "errors": errors,
        }

    except Exception as exc:
        logger.error("S3 sync failed: %s", exc)
        return {"success": False, "error": str(exc), "new_files": 0, "indexed": [], "errors": []}


# ── Background watcher thread ─────────────────────────────────────────────────

def get_watcher_status() -> dict:
    return dict(_watcher_status)


def start_watcher(config: dict, poll_interval: int = 60):
    """
    Start a background daemon thread that polls S3 inbound/files/ every
    poll_interval seconds.  No-ops if the bucket is not configured or if
    a watcher thread is already running.
    """
    global _watcher_thread

    bucket = config.get("s3", {}).get("bucket_name", "").strip()
    if not bucket:
        logger.info("S3 watcher: bucket not configured — skipping auto-sync")
        return

    if _watcher_thread and _watcher_thread.is_alive():
        logger.info("S3 watcher: already running")
        return

    _watcher_stop.clear()
    _watcher_status["running"] = True

    def _run():
        logger.info("S3 watcher started (poll every %ds)", poll_interval)
        while not _watcher_stop.is_set():
            try:
                result = sync_s3_inbound(config)
                _watcher_status["last_sync"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                if result.get("indexed"):
                    _watcher_status["files_processed"] += len(result["indexed"])
                _watcher_status["last_error"] = None if result.get("success") else result.get("error")
            except Exception as exc:
                _watcher_status["last_error"] = str(exc)
                logger.error("S3 watcher loop error: %s", exc)
            _watcher_stop.wait(poll_interval)

        _watcher_status["running"] = False
        logger.info("S3 watcher stopped")

    _watcher_thread = threading.Thread(target=_run, daemon=True, name="s3-watcher")
    _watcher_thread.start()


def stop_watcher():
    """Signal the watcher thread to stop."""
    _watcher_stop.set()


def rebuild_from_s3(config: dict) -> dict:
    """
    Force rebuild the vector database from all S3 files.
    This clears the processed keys tracking and re-indexes everything.

    Use this when:
    - The local index is cleared but S3 has files
    - You want to ensure S3 is the source of truth

    Returns:
        Same format as sync_s3_inbound()
    """
    global _processed_keys

    logger.info("Rebuilding vector database from S3...")

    # Clear processed keys to force re-indexing
    _processed_keys.clear()
    _save_processed_keys()

    # Sync with force_rebuild=True
    result = sync_s3_inbound(config, force_rebuild=True)

    if result.get("success"):
        logger.info("Rebuild from S3 complete: %d files indexed", len(result.get("indexed", [])))
    else:
        logger.error("Rebuild from S3 failed: %s", result.get("error"))

    return result


def ensure_s3_synced(config: dict) -> dict:
    """
    Ensure vector database is synced with S3.
    If the local index is empty but S3 has files, rebuild from S3.

    Call this on app startup or when detecting empty index.

    Returns:
        Sync result dict
    """
    from pathlib import Path

    index_path = Path(config["vector_store"]["index_path"])
    faiss_file = index_path / "index.faiss"

    # Check if bucket is configured
    bucket = config.get("s3", {}).get("bucket_name", "").strip()
    if not bucket:
        logger.info("S3 not configured, skipping sync check")
        return {"success": False, "error": "S3 not configured", "new_files": 0}

    # If index exists, just sync new files
    if faiss_file.exists():
        logger.info("Index exists, syncing new files from S3...")
        return sync_s3_inbound(config)

    # Index is empty, rebuild from S3
    logger.info("Index is empty, rebuilding from S3...")
    return rebuild_from_s3(config)
