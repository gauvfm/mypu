import os
import re
import yaml
from pathlib import Path


CONFIG_PATH = Path(__file__).parent.parent / "config" / "config.yaml"


def extract_bucket_name(value: str) -> str:
    """
    Extract just the bucket name from any S3 URL format or plain name.
    Handles:
      - Plain name:        my-bucket
      - S3 URI:            s3://my-bucket/prefix/
      - AWS Console URL:   https://us-east-1.console.aws.amazon.com/s3/buckets/my-bucket?region=...
      - Virtual-hosted:    https://my-bucket.s3.amazonaws.com/...
      - Path-style:        https://s3.amazonaws.com/my-bucket/...
      - Regional:          https://s3.us-east-1.amazonaws.com/my-bucket/...
    """
    value = value.strip()

    # s3://bucket-name/...
    m = re.match(r"s3://([a-zA-Z0-9.\-_]+)", value)
    if m:
        return m.group(1)

    # AWS Console URL: .../s3/buckets/BUCKET_NAME?...
    m = re.search(r"/s3/buckets/([a-zA-Z0-9.\-_]+)", value)
    if m:
        return m.group(1)

    # Virtual-hosted: https://BUCKET_NAME.s3[.region].amazonaws.com/...
    m = re.match(r"https?://([a-zA-Z0-9.\-_]+?)\.s3[a-z0-9.\-]*\.amazonaws\.com", value)
    if m:
        return m.group(1)

    # Path-style: https://s3[.region].amazonaws.com/BUCKET_NAME/...
    m = re.match(r"https?://s3[a-z0-9.\-]*\.amazonaws\.com/([a-zA-Z0-9.\-_]+)", value)
    if m:
        return m.group(1)

    # ARN format: arn:aws:s3:::bucket-name  or  arn:aws:s3:::bucket-name/key
    m = re.match(r"arn:aws[^:]*:s3[^:]*:[^:]*:[^:]*:([a-zA-Z0-9.\-_]+)", value)
    if m:
        return m.group(1)

    # Already a plain bucket name — return as-is
    return value


def load_config() -> dict:
    """Load configuration from YAML file, with env variable overrides."""
    with open(CONFIG_PATH, "r") as f:
        config = yaml.safe_load(f)
    _apply_env_overrides(config)
    return config


def _apply_env_overrides(config: dict):
    """Apply environment variable overrides to config."""
    if os.environ.get("LLM_PROVIDER"):
        config["llm"]["provider"] = os.environ["LLM_PROVIDER"]

    if os.environ.get("OPENAI_API_KEY"):
        config["llm"]["openai"]["api_key"] = os.environ["OPENAI_API_KEY"]
        config["embeddings"]["openai"]["api_key"] = os.environ["OPENAI_API_KEY"]

    if os.environ.get("ANTHROPIC_API_KEY"):
        config["llm"]["anthropic"]["api_key"] = os.environ["ANTHROPIC_API_KEY"]

    if os.environ.get("AWS_ACCESS_KEY_ID"):
        config["llm"]["bedrock"]["aws_access_key_id"] = os.environ["AWS_ACCESS_KEY_ID"]
    if os.environ.get("AWS_SECRET_ACCESS_KEY"):
        config["llm"]["bedrock"]["aws_secret_access_key"] = os.environ["AWS_SECRET_ACCESS_KEY"]
    if os.environ.get("AWS_SESSION_TOKEN"):
        config["llm"]["bedrock"]["aws_session_token"] = os.environ["AWS_SESSION_TOKEN"]
    if os.environ.get("AWS_DEFAULT_REGION"):
        config["llm"]["bedrock"]["region"] = os.environ["AWS_DEFAULT_REGION"]

    # S3 bucket — clean from env OR config.yaml (handles URLs, URIs, ARNs)
    # Priority: env var > config.yaml value
    # In both cases, extract the plain bucket name from whatever format is provided
    raw_env = os.environ.get("S3_BUCKET_NAME", "").strip()
    raw_cfg = config["s3"].get("bucket_name", "").strip()

    if raw_env:
        bucket = extract_bucket_name(raw_env)
        if bucket != raw_env:
            import logging
            logging.getLogger(__name__).info(f"S3 bucket (env) cleaned: '{raw_env}' → '{bucket}'")
    elif raw_cfg:
        bucket = extract_bucket_name(raw_cfg)
        if bucket != raw_cfg:
            import logging
            logging.getLogger(__name__).info(f"S3 bucket (config) cleaned: '{raw_cfg}' → '{bucket}'")
    else:
        bucket = ""

    if bucket:
        config["s3"]["bucket_name"] = bucket
        os.environ["S3_BUCKET_NAME"] = bucket


def get_active_model_name(config: dict) -> str:
    provider = config["llm"]["provider"]
    if provider == "bedrock":
        return config["llm"]["bedrock"]["model_id"]
    elif provider == "openai":
        return config["llm"]["openai"]["model"]
    elif provider == "anthropic":
        return config["llm"]["anthropic"]["model"]
    return "unknown"


def get_cost_rates(config: dict, model_name: str) -> dict:
    costs = config.get("cost_per_1k_tokens", {})
    return costs.get(model_name, {"input": 0.001, "output": 0.002})
