"""
Embedding Manager — supports AWS Bedrock Titan and OpenAI embeddings.
"""
import os
import logging

logger = logging.getLogger(__name__)


def get_embeddings(config: dict):
    """Return a LangChain embeddings instance based on config."""
    provider = config["embeddings"]["provider"]

    if provider == "bedrock":
        return _get_bedrock_embeddings(config)
    elif provider == "openai":
        return _get_openai_embeddings(config)
    else:
        raise ValueError(f"Unsupported embeddings provider: {provider}")


def _get_bedrock_embeddings(config: dict):
    from langchain_aws import BedrockEmbeddings
    import boto3

    bedrock_cfg = config["llm"]["bedrock"]
    embed_cfg = config["embeddings"]["bedrock"]

    session_kwargs = {"region_name": embed_cfg.get("region", bedrock_cfg["region"])}
    if bedrock_cfg.get("aws_access_key_id"):
        session_kwargs["aws_access_key_id"] = bedrock_cfg["aws_access_key_id"]
        session_kwargs["aws_secret_access_key"] = bedrock_cfg["aws_secret_access_key"]
        if bedrock_cfg.get("aws_session_token"):
            session_kwargs["aws_session_token"] = bedrock_cfg["aws_session_token"]

    session = boto3.Session(**session_kwargs)
    client = session.client("bedrock-runtime")

    return BedrockEmbeddings(
        client=client,
        model_id=embed_cfg["model_id"],
    )


def _get_openai_embeddings(config: dict):
    from langchain_openai import OpenAIEmbeddings

    embed_cfg = config["embeddings"]["openai"]
    api_key = embed_cfg.get("api_key") or os.environ.get("OPENAI_API_KEY")

    return OpenAIEmbeddings(
        api_key=api_key,
        model=embed_cfg["model"],
    )
