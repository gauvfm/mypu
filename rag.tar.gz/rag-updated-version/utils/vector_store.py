"""
Vector Store Manager — FAISS-based with persistence and S3 sync.
"""
import os
import json
import pickle
import logging
from typing import List, Optional, Tuple
from pathlib import Path

from langchain.schema import Document

logger = logging.getLogger(__name__)

_vector_store = None
_indexed_files: List[dict] = []


def get_vector_store():
    return _vector_store


def get_indexed_files() -> List[dict]:
    return _indexed_files


def add_documents(docs: List[Document], embeddings, config: dict) -> Tuple[bool, str]:
    """Add documents to FAISS vector store (creates if not exists)."""
    global _vector_store, _indexed_files

    try:
        from langchain_community.vectorstores import FAISS

        if not docs:
            return False, "No documents to index"

        if _vector_store is None:
            _vector_store = FAISS.from_documents(docs, embeddings)
            logger.info(f"Created new FAISS index with {len(docs)} chunks")
        else:
            _vector_store.add_documents(docs)
            logger.info(f"Added {len(docs)} chunks to existing FAISS index")

        # Track indexed file metadata
        filenames = list({d.metadata.get("filename", "unknown") for d in docs})
        for fname in filenames:
            if not any(f["filename"] == fname for f in _indexed_files):
                _indexed_files.append({
                    "filename": fname,
                    "chunks": sum(1 for d in docs if d.metadata.get("filename") == fname),
                })

        _save_index(config)
        return True, f"Successfully indexed {len(docs)} chunks from {len(filenames)} file(s)"
    except Exception as e:
        logger.error(f"Error adding documents to vector store: {e}")
        return False, str(e)


def search(query: str, embeddings, config: dict, k: int = None) -> List[Document]:
    """Search the vector store for relevant documents."""
    global _vector_store

    if _vector_store is None:
        _vector_store = _load_index(config, embeddings)

    if _vector_store is None:
        return []

    top_k = k or config["retrieval"].get("top_k", 5)
    try:
        results = _vector_store.similarity_search(query, k=top_k)
        return results
    except Exception as e:
        logger.error(f"Search error: {e}")
        return []


def search_with_scores(query: str, embeddings, config: dict) -> List[Tuple[Document, float]]:
    """Search with similarity scores."""
    global _vector_store

    if _vector_store is None:
        _vector_store = _load_index(config, embeddings)

    if _vector_store is None:
        return []

    top_k = config["retrieval"].get("top_k", 5)
    try:
        results = _vector_store.similarity_search_with_score(query, k=top_k)
        return results
    except Exception as e:
        logger.error(f"Search error: {e}")
        return []


def delete_index(config: dict):
    """Clear the vector store."""
    global _vector_store, _indexed_files
    _vector_store = None
    _indexed_files = []

    index_path = Path(config["vector_store"]["index_path"])
    for f in index_path.glob("*"):
        f.unlink()
    logger.info("Vector store cleared")


def _save_index(config: dict):
    """Save FAISS index to disk."""
    global _vector_store, _indexed_files
    if _vector_store is None:
        return

    index_path = Path(config["vector_store"]["index_path"])
    index_path.mkdir(parents=True, exist_ok=True)
    _vector_store.save_local(str(index_path))

    # Save metadata
    meta_file = index_path / "indexed_files.json"
    with open(meta_file, "w") as f:
        json.dump(_indexed_files, f)
    logger.info(f"FAISS index saved to {index_path}")


def _load_index(config: dict, embeddings):
    """Load FAISS index from disk if it exists."""
    global _indexed_files
    from langchain_community.vectorstores import FAISS

    index_path = Path(config["vector_store"]["index_path"])
    faiss_file = index_path / "index.faiss"

    if not faiss_file.exists():
        return None

    try:
        store = FAISS.load_local(str(index_path), embeddings, allow_dangerous_deserialization=True)
        logger.info(f"Loaded FAISS index from {index_path}")

        meta_file = index_path / "indexed_files.json"
        if meta_file.exists():
            with open(meta_file) as f:
                _indexed_files = json.load(f)

        return store
    except Exception as e:
        logger.error(f"Error loading FAISS index: {e}")
        return None
