"""
RAG Document Assistant — S3-inbound edition.

Upload paths
------------
  Local (UI)  →  ./inbound/temp/          (saved locally, then vectorized)
  Local (UI)  →  s3://{bucket}/inbound/temp/  (uploaded for storage)
  System (S3) →  s3://{bucket}/inbound/files/  (auto-polled, downloaded & vectorized)

Both local and system paths feed the same chunking → embedding → FAISS pipeline.
"""
import os
import uuid
import logging
from pathlib import Path

from dotenv import load_dotenv
load_dotenv(override=True)

# Normalize S3 bucket name from any URL/URI format on startup
if os.environ.get("S3_BUCKET_NAME"):
    from utils.config_loader import extract_bucket_name as _clean
    os.environ["S3_BUCKET_NAME"] = _clean(os.environ["S3_BUCKET_NAME"])

from flask import Flask, request, jsonify, render_template, session
from flask_cors import CORS
from werkzeug.utils import secure_filename

from utils.config_loader import load_config, get_active_model_name
from utils.document_processor import load_document, chunk_documents, SUPPORTED_EXTENSIONS
from utils.embeddings_manager import get_embeddings
from utils.vector_store import add_documents, delete_index, get_indexed_files
from utils.rag_chain import query, clear_history, get_history
from utils.s3_watcher import start_watcher, stop_watcher, sync_s3_inbound, get_watcher_status, upload_to_s3

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "rag-updated-secret-2024")
CORS(app, supports_credentials=True)

config = load_config()

# Local upload directory: ./inbound/temp/
upload_folder = Path(config["app"]["upload_folder"])
upload_folder.mkdir(parents=True, exist_ok=True)
app.config["UPLOAD_FOLDER"] = str(upload_folder)
app.config["MAX_CONTENT_LENGTH"] = config["app"]["max_file_size_mb"] * 1024 * 1024

# Start background S3 watcher (no-op when bucket is not configured)
poll_interval = config.get("s3", {}).get("poll_interval_seconds", 60)
start_watcher(config, poll_interval=poll_interval)


# ── Error handlers ────────────────────────────────────────────────────────────

@app.errorhandler(Exception)
def handle_error(e):
    logger.error("Unhandled error: %s", e, exc_info=True)
    return jsonify({"success": False, "error": str(e)}), 500


@app.errorhandler(404)
def not_found(e):
    return jsonify({"success": False, "error": "Not found"}), 404


# ── Pages ─────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    if "session_id" not in session:
        session["session_id"] = str(uuid.uuid4())
    return render_template("index.html")


# ── Config / status ───────────────────────────────────────────────────────────

@app.route("/api/config")
def get_config():
    cfg = load_config()
    s3_cfg = cfg.get("s3", {})
    return jsonify({
        "provider":          cfg["llm"]["provider"],
        "model":             get_active_model_name(cfg),
        "chunk_size":        cfg["chunking"]["chunk_size"],
        "top_k":             cfg["retrieval"]["top_k"],
        "indexed_files":     get_indexed_files(),
        "s3_bucket":         s3_cfg.get("bucket_name", ""),
        "s3_inbound_prefix": s3_cfg.get("inbound_prefix", "inbound/files/"),
        "s3_upload_prefix":  s3_cfg.get("upload_prefix", "inbound/temp/"),
    })


@app.route("/api/health")
def health():
    cfg = load_config()
    watcher = get_watcher_status()
    return jsonify({
        "status":        "ok",
        "model":         get_active_model_name(cfg),
        "indexed_files": len(get_indexed_files()),
        "s3_watcher":    watcher.get("running", False),
    })


# ── Document upload (local UI) ────────────────────────────────────────────────

@app.route("/api/upload", methods=["POST"])
def upload_document():
    """
    Accepts a file from the browser.
    Saves it to ./inbound/temp/, uploads to s3://bucket/upload_prefix/, then chunks + embeds + indexes it.
    """
    if "file" not in request.files:
        return jsonify({"success": False, "error": "No file provided"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"success": False, "error": "No filename"}), 400

    ext = Path(file.filename).suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        return jsonify({
            "success": False,
            "error": f"Unsupported type '{ext}'. Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}",
        }), 400

    filename  = secure_filename(file.filename)
    save_path = upload_folder / filename
    file.save(str(save_path))
    logger.info("Local upload saved to %s", save_path)

    # Upload to S3 inbound/temp/
    cfg = load_config()
    upload_prefix = cfg.get("s3", {}).get("upload_prefix", "inbound/temp/")
    s3_key = f"{upload_prefix.rstrip('/')}/{filename}"
    s3_uploaded = upload_to_s3(cfg, str(save_path), s3_key)
    if s3_uploaded:
        logger.info("Uploaded to S3: %s", s3_key)
    else:
        logger.warning("Failed to upload to S3, but continuing with local processing")

    docs, error = load_document(str(save_path))
    if error:
        return jsonify({"success": False, "error": error}), 400
    if not docs:
        return jsonify({"success": False, "error": "No text could be extracted"}), 400

    chunks    = chunk_documents(docs, cfg)
    embeddings = get_embeddings(cfg)
    success, msg = add_documents(chunks, embeddings, cfg)

    return jsonify({
        "success":  success,
        "message":  msg,
        "filename": filename,
        "source":   "local",
        "pages":    len(docs),
        "chunks":   len(chunks),
        "s3_uploaded": s3_uploaded,
    })


# ── Chat ──────────────────────────────────────────────────────────────────────

@app.route("/api/chat", methods=["POST"])
def chat():
    data     = request.get_json()
    question = (data.get("question") or "").strip()
    if not question:
        return jsonify({"success": False, "error": "Question is required"}), 400

    session_id = session.get("session_id", str(uuid.uuid4()))
    cfg        = load_config()
    result     = query(question, session_id, cfg)
    return jsonify({"success": True, **result})


# ── History / index management ────────────────────────────────────────────────

@app.route("/api/history/clear", methods=["POST"])
def clear_chat():
    clear_history(session.get("session_id", ""))
    return jsonify({"success": True})


@app.route("/api/index/clear", methods=["POST"])
def clear_idx():
    delete_index(load_config())
    return jsonify({"success": True})


# ── S3 integration endpoints ──────────────────────────────────────────────────

@app.route("/api/s3/sync", methods=["POST"])
def s3_sync():
    """
    Manually trigger an immediate S3 inbound sync
    (same logic the background watcher runs automatically).
    """
    cfg    = load_config()
    result = sync_s3_inbound(cfg)
    return jsonify({"success": result.get("success", False), **result})


@app.route("/api/s3/status")
def s3_status():
    """Return current S3 watcher state and configuration."""
    cfg = load_config()
    s3_cfg = cfg.get("s3", {})
    return jsonify({
        "watcher":        get_watcher_status(),
        "bucket":         s3_cfg.get("bucket_name", ""),
        "inbound_prefix": s3_cfg.get("inbound_prefix", "inbound/files/"),
        "poll_interval":  s3_cfg.get("poll_interval_seconds", 60),
    })


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.environ.get("PORT", config["app"]["port"]))
    logger.info("RAG Document Assistant (S3-inbound edition) starting on port %d", port)
    try:
        app.run(
            host=config["app"]["host"],
            port=port,
            debug=config["app"]["debug"],
        )
    finally:
        stop_watcher()
