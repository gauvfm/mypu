# Enterprise MCP Architecture for Codebase Context
## Secure Model Context Protocol Implementation

**Version:** 1.0  
**Date:** November 16, 2025  
**Classification:** Internal - Architecture Document

---

## Executive Summary

This architecture enables secure exposure of codebase context via Model Context Protocol (MCP) to internal AI agents and IDEs (GitHub Copilot) while maintaining SOC2, HIPAA, and PCI-DSS compliance with user-context authentication and fine-grained access control.

### Key Design Principles
- **Zero Trust Architecture**: All requests authenticated and authorized
- **User Context Preservation**: Pass-through authentication from IDE to datastore
- **Defense in Depth**: Multiple security layers (Ping → APIGEE → MCP → Datastore)
- **Compliance-First**: Built-in DLP, audit logging, encryption at rest/transit
- **High Availability**: Multi-AZ deployment with automated failover

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                         USER LAYER                                   │
├─────────────────────────────────────────────────────────────────────┤
│  IDE (VS Code/IntelliJ)     │    AI Agents/Workflows                │
│  with MCP Client            │    (GHCP, Custom Agents)              │
└──────────────┬──────────────┴────────────────┬──────────────────────┘
               │                               │
               │ HTTPS + OAuth2                │
               │                               │
┌──────────────▼───────────────────────────────▼──────────────────────┐
│                    PING IDENTITY (IdP)                               │
│  ┌────────────────────────────────────────────────────────┐         │
│  │ OAuth2/OIDC Authorization Server                       │         │
│  │ - User Authentication                                  │         │
│  │ - Token Issuance (JWT)                                │         │
│  │ - MFA Enforcement                                      │         │
│  └────────────────────────────────────────────────────────┘         │
└──────────────┬───────────────────────────────────────────────────────┘
               │ JWT Bearer Token
               │
┌──────────────▼───────────────────────────────────────────────────────┐
│                         AWS VPC (us-east-1)                          │
│  ┌─────────────────────────────────────────────────────────┐        │
│  │              APIGEE API GATEWAY (DMZ Subnet)            │        │
│  │  ┌────────────────────────────────────────────────┐     │        │
│  │  │ • JWT Validation (Ping public key)             │     │        │
│  │  │ • Rate Limiting (per user/org)                 │     │        │
│  │  │ • Request/Response Logging                     │     │        │
│  │  │ • DLP Scanning (outbound)                      │     │        │
│  │  │ • Threat Detection (OWASP Top 10)              │     │        │
│  │  │ • mTLS to MCP Server                           │     │        │
│  │  └────────────────────────────────────────────────┘     │        │
│  └────────────────┬────────────────────────────────────────┘        │
│                   │ Internal Network (mTLS)                          │
│  ┌────────────────▼────────────────────────────────────────┐        │
│  │           APPLICATION LOAD BALANCER (ALB)               │        │
│  │  • Multi-AZ Distribution                                │        │
│  │  • SSL/TLS Termination                                  │        │
│  │  • Health Checks                                        │        │
│  │  • Access Logs to S3                                    │        │
│  └────────────────┬────────────────────────────────────────┘        │
│                   │                                                  │
│  ┌────────────────▼────────────────────────────────────────┐        │
│  │         MCP SERVER CLUSTER (ECS Fargate)                │        │
│  │                                                          │        │
│  │  ┌─────────────────────────┐  ┌─────────────────────┐  │        │
│  │  │   Private Subnet AZ-1   │  │ Private Subnet AZ-2 │  │        │
│  │  │  ┌─────────────────┐    │  │  ┌─────────────┐    │  │        │
│  │  │  │ MCP Server      │    │  │  │ MCP Server  │    │  │        │
│  │  │  │ Container       │    │  │  │ Container   │    │  │        │
│  │  │  │ • Auth Handler  │    │  │  │             │    │  │        │
│  │  │  │ • ABAC Engine   │    │  │  │             │    │  │        │
│  │  │  │ • Code Context  │    │  │  │             │    │  │        │
│  │  │  │ • Cache Layer   │    │  │  │             │    │  │        │
│  │  │  └─────────────────┘    │  │  └─────────────┘    │  │        │
│  │  └─────────────────────────┘  └─────────────────────┘  │        │
│  └────────────────┬────────────────────────────────────────┘        │
│                   │                                                  │
│  ┌────────────────▼────────────────────────────────────────┐        │
│  │         DATA & INTEGRATION LAYER                        │        │
│  │                                                          │        │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │        │
│  │  │ CodeCommit   │  │  S3 Bucket   │  │ AI Gateway   │  │        │
│  │  │ Repositories │  │ (Codebase)   │  │ (Portkey)    │  │        │
│  │  │              │  │              │  │ LLM Access   │  │        │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  │        │
│  │                                                          │        │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │        │
│  │  │ ElastiCache  │  │ Secrets Mgr  │  │ CloudWatch   │  │        │
│  │  │ Redis        │  │ (API Keys)   │  │ Logs/Metrics │  │        │
│  │  │ (Cache)      │  │              │  │              │  │        │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  │        │
│  └──────────────────────────────────────────────────────────┘        │
│                                                                       │
└───────────────────────────────────────────────────────────────────────┘
```

---

## Component Architecture

### 1. Authentication & Authorization Flow

#### 1.1 User Authentication Flow (IDE/Agent)

```
┌─────────┐                                              ┌──────────┐
│  IDE    │                                              │   Ping   │
│ Client  │                                              │   IdP    │
└────┬────┘                                              └────┬─────┘
     │                                                        │
     │  1. Initiate Auth (PKCE OAuth2 Flow)                  │
     │ ───────────────────────────────────────────────────>  │
     │                                                        │
     │  2. User Login (SSO/MFA)                              │
     │ <─────────────────────────────────────────────────── │
     │                                                        │
     │  3. Authorization Code                                │
     │ <─────────────────────────────────────────────────── │
     │                                                        │
     │  4. Exchange Code for Tokens                          │
     │ ───────────────────────────────────────────────────>  │
     │                                                        │
     │  5. Access Token (JWT) + Refresh Token                │
     │ <─────────────────────────────────────────────────── │
     │                                                        │
     │                                                        │
┌────▼────┐                                              ┌────▼─────┐
│  IDE    │          6. MCP Request + JWT                │  APIGEE  │
│ Client  │ ──────────────────────────────────────────>  │          │
└─────────┘                                              └──────────┘
```

**JWT Token Claims (Example):**
```json
{
  "iss": "https://ping.yourcompany.com",
  "sub": "user123@yourcompany.com",
  "aud": "mcp-codebase-api",
  "exp": 1700000000,
  "iat": 1699996400,
  "email": "john.doe@yourcompany.com",
  "groups": ["engineering", "team-platform", "mcp-users"],
  "org_id": "org-engineering-platform",
  "scope": "mcp:read mcp:query",
  "repo_access": ["repo1", "repo2", "repo3"]
}
```

#### 1.2 APIGEE Gateway Processing

**Policy Chain:**

1. **JWT Validation Policy**
   ```xml
   <VerifyJWT name="Verify-Ping-JWT">
     <Algorithm>RS256</Algorithm>
     <PublicKey>
       <JWKS ref="ping-jwks-url"/>
     </PublicKey>
     <Subject>user@yourcompany.com</Subject>
     <Audience>mcp-codebase-api</Audience>
     <Issuer>https://ping.yourcompany.com</Issuer>
   </VerifyJWT>
   ```

2. **Extract User Context**
   ```javascript
   // Extract claims for downstream services
   context.setVariable("user.email", jwt.claims.email);
   context.setVariable("user.groups", jwt.claims.groups);
   context.setVariable("user.org_id", jwt.claims.org_id);
   context.setVariable("user.repo_access", jwt.claims.repo_access);
   ```

3. **Rate Limiting Policy**
   ```xml
   <Quota name="User-Rate-Limit">
     <Identifier ref="user.email"/>
     <Allow count="1000" countRef="verifyapikey.VerifyAPIKey.apiproduct.developer.quota.limit"/>
     <Interval ref="1"/>
     <TimeUnit ref="hour"/>
   </Quota>
   ```

4. **Request Logging**
   ```xml
   <MessageLogging name="Log-Request">
     <Syslog>
       <Message>
         {
           "timestamp": "{system.timestamp}",
           "user": "{user.email}",
           "method": "{request.verb}",
           "path": "{request.uri}",
           "ip": "{client.ip}",
           "user_agent": "{request.header.user-agent}"
         }
       </Message>
     </Syslog>
   </MessageLogging>
   ```

5. **DLP Scanning (Response)**
   ```javascript
   // Check response for sensitive data patterns
   var response = context.getVariable("response.content");
   var patterns = {
     ssn: /\b\d{3}-\d{2}-\d{4}\b/g,
     credit_card: /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g,
     api_key: /\b[A-Za-z0-9]{32,}\b/g
   };
   
   if (hasSensitiveData(response, patterns)) {
     context.setVariable("dlp.violation", true);
     // Redact or block
   }
   ```

6. **mTLS to MCP Server**
   ```xml
   <TargetEndpoint name="MCP-Server">
     <SSLInfo>
       <Enabled>true</Enabled>
       <ClientAuthEnabled>true</ClientAuthEnabled>
       <KeyStore>apigee-client-keystore</KeyStore>
       <TrustStore>mcp-server-truststore</TrustStore>
     </SSLInfo>
   </TargetEndpoint>
   ```

---

### 2. MCP Server Implementation

#### 2.1 Technology Stack

**Recommended: Python FastAPI + MCP SDK**

```
Language: Python 3.11+
Framework: FastAPI (async support)
MCP SDK: @modelcontextprotocol/sdk-python
Container: Docker (Fargate)
Runtime: ECS Fargate (serverless container)
```

#### 2.2 MCP Server Architecture

```python
# mcp_server/main.py
from fastapi import FastAPI, Header, HTTPException, Depends
from mcp.server import Server
from mcp.server.stdio import stdio_server
import asyncio
import jwt
from typing import Optional

app = FastAPI()
mcp_server = Server("codebase-context-server")

# Authorization Middleware
async def verify_token(authorization: str = Header(...)) -> dict:
    """Verify JWT from APIGEE and extract user context"""
    try:
        token = authorization.replace("Bearer ", "")
        
        # APIGEE already validated, but we verify again for defense in depth
        # In production, fetch JWKS from Ping
        payload = jwt.decode(
            token,
            options={"verify_signature": False},  # Already verified by APIGEE
            audience="mcp-codebase-api"
        )
        
        return {
            "email": payload.get("email"),
            "groups": payload.get("groups", []),
            "org_id": payload.get("org_id"),
            "repo_access": payload.get("repo_access", [])
        }
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

# ABAC Authorization Engine
class ABACEngine:
    """Attribute-Based Access Control Engine"""
    
    def __init__(self):
        # Load policies from DynamoDB or S3
        self.policies = self._load_policies()
    
    def authorize(self, user_context: dict, resource: str, action: str) -> bool:
        """
        Evaluate ABAC policies
        
        Policy Example:
        {
          "effect": "allow",
          "principal": {"groups": ["engineering"]},
          "action": ["read", "query"],
          "resource": "repo:*",
          "condition": {
            "repo_in_user_access": true
          }
        }
        """
        for policy in self.policies:
            if self._evaluate_policy(policy, user_context, resource, action):
                return policy["effect"] == "allow"
        
        return False  # Deny by default
    
    def _evaluate_policy(self, policy, user_context, resource, action):
        # Check principal (user attributes)
        if not self._match_principal(policy["principal"], user_context):
            return False
        
        # Check action
        if action not in policy["action"]:
            return False
        
        # Check resource pattern
        if not self._match_resource(policy["resource"], resource):
            return False
        
        # Check conditions
        if "condition" in policy:
            if not self._evaluate_conditions(policy["condition"], user_context, resource):
                return False
        
        return True
    
    def _match_principal(self, principal, user_context):
        if "groups" in principal:
            required_groups = set(principal["groups"])
            user_groups = set(user_context.get("groups", []))
            if not required_groups.intersection(user_groups):
                return False
        
        if "email" in principal:
            if user_context.get("email") not in principal["email"]:
                return False
        
        return True
    
    def _match_resource(self, pattern, resource):
        # Simple wildcard matching
        if pattern == "*":
            return True
        if pattern.endswith("*"):
            return resource.startswith(pattern[:-1])
        return pattern == resource
    
    def _evaluate_conditions(self, conditions, user_context, resource):
        if "repo_in_user_access" in conditions:
            repo_name = self._extract_repo_from_resource(resource)
            return repo_name in user_context.get("repo_access", [])
        
        return True
    
    def _extract_repo_from_resource(self, resource):
        # Extract repo name from resource identifier
        # e.g., "repo:my-service" -> "my-service"
        if resource.startswith("repo:"):
            return resource.split(":")[1]
        return resource
    
    def _load_policies(self):
        # In production, load from DynamoDB or S3
        return [
            {
                "effect": "allow",
                "principal": {"groups": ["engineering"]},
                "action": ["read", "query"],
                "resource": "repo:*",
                "condition": {"repo_in_user_access": True}
            },
            {
                "effect": "deny",
                "principal": {"groups": ["contractors"]},
                "action": ["write"],
                "resource": "*"
            }
        ]

abac_engine = ABACEngine()

# MCP Tools
@mcp_server.list_tools()
async def list_tools():
    return [
        {
            "name": "search_codebase",
            "description": "Search across codebase repositories",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "repo": {"type": "string"},
                    "file_type": {"type": "string"}
                },
                "required": ["query"]
            }
        },
        {
            "name": "get_file_context",
            "description": "Get full context of a specific file",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "repo": {"type": "string"},
                    "file_path": {"type": "string"}
                },
                "required": ["repo", "file_path"]
            }
        },
        {
            "name": "get_function_definition",
            "description": "Get function/class definition and usage",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "repo": {"type": "string"},
                    "symbol": {"type": "string"}
                },
                "required": ["symbol"]
            }
        }
    ]

@mcp_server.call_tool()
async def call_tool(name: str, arguments: dict, user_context: dict):
    """Execute tool with ABAC authorization"""
    
    # Extract resource from arguments
    repo = arguments.get("repo", "default")
    resource = f"repo:{repo}"
    
    # Authorize request
    if not abac_engine.authorize(user_context, resource, "read"):
        raise HTTPException(
            status_code=403,
            detail=f"Access denied to repository: {repo}"
        )
    
    # Execute tool based on name
    if name == "search_codebase":
        return await search_codebase(arguments, user_context)
    elif name == "get_file_context":
        return await get_file_context(arguments, user_context)
    elif name == "get_function_definition":
        return await get_function_definition(arguments, user_context)
    else:
        raise ValueError(f"Unknown tool: {name}")

# Tool Implementations
async def search_codebase(args: dict, user_context: dict):
    """Search codebase with user-scoped access"""
    query = args["query"]
    repo = args.get("repo")
    file_type = args.get("file_type")
    
    # Filter repos based on user access
    accessible_repos = user_context.get("repo_access", [])
    if repo and repo not in accessible_repos:
        raise HTTPException(403, f"No access to repo: {repo}")
    
    # Search implementation
    results = await CodebaseSearcher.search(
        query=query,
        repos=accessible_repos if not repo else [repo],
        file_type=file_type
    )
    
    # Audit log
    await AuditLogger.log({
        "action": "search_codebase",
        "user": user_context["email"],
        "query": query,
        "repos_searched": accessible_repos if not repo else [repo],
        "results_count": len(results)
    })
    
    return results

async def get_file_context(args: dict, user_context: dict):
    """Get file content with authorization"""
    repo = args["repo"]
    file_path = args["file_path"]
    
    # Check authorization
    if repo not in user_context.get("repo_access", []):
        raise HTTPException(403, f"No access to repo: {repo}")
    
    # Fetch from S3 or CodeCommit
    content = await CodebaseStore.get_file(repo, file_path)
    
    # Audit log
    await AuditLogger.log({
        "action": "get_file_context",
        "user": user_context["email"],
        "repo": repo,
        "file_path": file_path
    })
    
    return {
        "content": content,
        "repo": repo,
        "path": file_path
    }

# FastAPI Endpoints
@app.post("/mcp/v1/messages")
async def mcp_endpoint(
    request: dict,
    user_context: dict = Depends(verify_token)
):
    """MCP SSE Endpoint with user context"""
    # Process MCP request with user context
    response = await mcp_server.handle_request(request, user_context)
    return response

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "mcp-codebase-server"}
```

#### 2.3 Codebase Indexing & Storage

```python
# indexing/codebase_indexer.py
import boto3
from opensearchpy import OpenSearch
import git
import hashlib

class CodebaseIndexer:
    """Index codebase for fast searching"""
    
    def __init__(self):
        self.s3 = boto3.client('s3')
        self.opensearch = OpenSearch(
            hosts=[{'host': 'vpc-endpoint.us-east-1.es.amazonaws.com', 'port': 443}],
            use_ssl=True,
            verify_certs=True
        )
        self.bucket = "codebase-context-bucket"
    
    async def index_repository(self, repo_url: str, repo_name: str):
        """Clone and index a repository"""
        
        # Clone to temp directory
        temp_dir = f"/tmp/{repo_name}"
        git.Repo.clone_from(repo_url, temp_dir)
        
        # Process all files
        for root, dirs, files in os.walk(temp_dir):
            for file in files:
                if self._should_index(file):
                    await self._index_file(root, file, repo_name)
    
    async def _index_file(self, root: str, filename: str, repo_name: str):
        """Index individual file"""
        file_path = os.path.join(root, filename)
        
        with open(file_path, 'r') as f:
            content = f.read()
        
        # Create document
        doc = {
            'repo': repo_name,
            'path': file_path,
            'filename': filename,
            'content': content,
            'file_type': self._get_file_type(filename),
            'size': len(content),
            'hash': hashlib.sha256(content.encode()).hexdigest(),
            'indexed_at': datetime.utcnow().isoformat()
        }
        
        # Store in S3
        s3_key = f"{repo_name}/{file_path}"
        self.s3.put_object(
            Bucket=self.bucket,
            Key=s3_key,
            Body=content,
            ServerSideEncryption='aws:kms',
            SSEKMSKeyId='alias/codebase-kms-key'
        )
        
        # Index in OpenSearch
        self.opensearch.index(
            index='codebase',
            body=doc,
            id=s3_key
        )
    
    def _should_index(self, filename: str) -> bool:
        """Determine if file should be indexed"""
        excluded_extensions = ['.pyc', '.class', '.o', '.so', '.dll']
        excluded_dirs = ['node_modules', '.git', 'build', 'dist']
        
        return not any(filename.endswith(ext) for ext in excluded_extensions)
```

---

### 3. Network Architecture

#### 3.1 VPC Design

```
VPC: 10.0.0.0/16 (us-east-1)

┌─────────────────────────────────────────────────────────────────────┐
│                          Availability Zone 1                         │
├─────────────────────────────────────────────────────────────────────┤
│  Public Subnet (10.0.1.0/24)                                        │
│    - NAT Gateway                                                     │
│    - VPN Gateway (for remote users)                                 │
├─────────────────────────────────────────────────────────────────────┤
│  DMZ Subnet (10.0.10.0/24)                                          │
│    - APIGEE Gateway (EC2/Container)                                 │
│    - NLB for APIGEE                                                 │
├─────────────────────────────────────────────────────────────────────┤
│  Private Subnet - App (10.0.20.0/24)                                │
│    - MCP Server (ECS Fargate)                                       │
│    - ALB (internal)                                                  │
├─────────────────────────────────────────────────────────────────────┤
│  Private Subnet - Data (10.0.30.0/24)                               │
│    - ElastiCache Redis                                               │
│    - OpenSearch (VPC Endpoint)                                       │
│    - S3 Gateway Endpoint                                             │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                          Availability Zone 2                         │
├─────────────────────────────────────────────────────────────────────┤
│  Public Subnet (10.0.2.0/24)                                        │
│    - NAT Gateway                                                     │
├─────────────────────────────────────────────────────────────────────┤
│  DMZ Subnet (10.0.11.0/24)                                          │
│    - APIGEE Gateway (EC2/Container)                                 │
├─────────────────────────────────────────────────────────────────────┤
│  Private Subnet - App (10.0.21.0/24)                                │
│    - MCP Server (ECS Fargate)                                       │
├─────────────────────────────────────────────────────────────────────┤
│  Private Subnet - Data (10.0.31.0/24)                               │
│    - ElastiCache Redis (replica)                                     │
└─────────────────────────────────────────────────────────────────────┘
```

#### 3.2 Security Groups

```hcl
# security_groups.tf

# APIGEE Security Group
resource "aws_security_group" "apigee" {
  name        = "apigee-gateway-sg"
  description = "Security group for APIGEE API Gateway"
  vpc_id      = aws_vpc.main.id

  ingress {
    description = "HTTPS from Corporate Network"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/8"]  # Corporate CIDR
  }

  ingress {
    description = "HTTPS from VPN"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [var.vpn_cidr]
  }

  egress {
    description     = "To MCP Servers"
    from_port       = 8443
    to_port         = 8443
    protocol        = "tcp"
    security_groups = [aws_security_group.mcp_server.id]
  }

  egress {
    description = "To Ping IdP"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [var.ping_cidr]
  }

  tags = {
    Name = "apigee-sg"
  }
}

# MCP Server Security Group
resource "aws_security_group" "mcp_server" {
  name        = "mcp-server-sg"
  description = "Security group for MCP servers"
  vpc_id      = aws_vpc.main.id

  ingress {
    description     = "From APIGEE Gateway"
    from_port       = 8443
    to_port         = 8443
    protocol        = "tcp"
    security_groups = [aws_security_group.apigee.id]
  }

  ingress {
    description     = "From ALB"
    from_port       = 8443
    to_port         = 8443
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]
  }

  egress {
    description = "To S3 (via VPC Endpoint)"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    prefix_list_ids = [aws_vpc_endpoint.s3.prefix_list_id]
  }

  egress {
    description     = "To ElastiCache"
    from_port       = 6379
    to_port         = 6379
    protocol        = "tcp"
    security_groups = [aws_security_group.elasticache.id]
  }

  egress {
    description     = "To OpenSearch"
    from_port       = 443
    to_port         = 443
    protocol        = "tcp"
    security_groups = [aws_security_group.opensearch.id]
  }

  egress {
    description = "To AI Gateway (Portkey)"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [var.ai_gateway_cidr]
  }

  tags = {
    Name = "mcp-server-sg"
  }
}

# ElastiCache Security Group
resource "aws_security_group" "elasticache" {
  name        = "elasticache-sg"
  vpc_id      = aws_vpc.main.id

  ingress {
    description     = "From MCP Servers"
    from_port       = 6379
    to_port         = 6379
    protocol        = "tcp"
    security_groups = [aws_security_group.mcp_server.id]
  }

  tags = {
    Name = "elasticache-sg"
  }
}
```

#### 3.3 VPC Endpoints

```hcl
# vpc_endpoints.tf

# S3 Gateway Endpoint
resource "aws_vpc_endpoint" "s3" {
  vpc_id       = aws_vpc.main.id
  service_name = "com.amazonaws.us-east-1.s3"
  
  route_table_ids = [
    aws_route_table.private_az1.id,
    aws_route_table.private_az2.id
  ]

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = "*"
        Action = [
          "s3:GetObject",
          "s3:PutObject",
          "s3:ListBucket"
        ]
        Resource = [
          aws_s3_bucket.codebase.arn,
          "${aws_s3_bucket.codebase.arn}/*"
        ]
      }
    ]
  })

  tags = {
    Name = "s3-gateway-endpoint"
  }
}

# Secrets Manager Interface Endpoint
resource "aws_vpc_endpoint" "secrets_manager" {
  vpc_id              = aws_vpc.main.id
  service_name        = "com.amazonaws.us-east-1.secretsmanager"
  vpc_endpoint_type   = "Interface"
  
  subnet_ids = [
    aws_subnet.private_az1.id,
    aws_subnet.private_az2.id
  ]
  
  security_group_ids = [aws_security_group.vpc_endpoints.id]
  
  private_dns_enabled = true

  tags = {
    Name = "secrets-manager-endpoint"
  }
}

# CloudWatch Logs Interface Endpoint
resource "aws_vpc_endpoint" "logs" {
  vpc_id              = aws_vpc.main.id
  service_name        = "com.amazonaws.us-east-1.logs"
  vpc_endpoint_type   = "Interface"
  
  subnet_ids = [
    aws_subnet.private_az1.id,
    aws_subnet.private_az2.id
  ]
  
  security_group_ids = [aws_security_group.vpc_endpoints.id]
  
  private_dns_enabled = true

  tags = {
    Name = "cloudwatch-logs-endpoint"
  }
}
```

---

### 4. ECS Fargate Deployment

#### 4.1 Task Definition

```json
{
  "family": "mcp-server",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "1024",
  "memory": "2048",
  "executionRoleArn": "arn:aws:iam::ACCOUNT:role/ecsTaskExecutionRole",
  "taskRoleArn": "arn:aws:iam::ACCOUNT:role/mcpServerTaskRole",
  "containerDefinitions": [
    {
      "name": "mcp-server",
      "image": "ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/mcp-server:latest",
      "essential": true,
      "portMappings": [
        {
          "containerPort": 8443,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "AWS_REGION",
          "value": "us-east-1"
        },
        {
          "name": "ENVIRONMENT",
          "value": "production"
        },
        {
          "name": "LOG_LEVEL",
          "value": "INFO"
        }
      ],
      "secrets": [
        {
          "name": "PING_JWKS_URL",
          "valueFrom": "arn:aws:secretsmanager:us-east-1:ACCOUNT:secret:mcp/ping-jwks-url"
        },
        {
          "name": "AI_GATEWAY_API_KEY",
          "valueFrom": "arn:aws:secretsmanager:us-east-1:ACCOUNT:secret:mcp/ai-gateway-key"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/mcp-server",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "ecs"
        }
      },
      "healthCheck": {
        "command": ["CMD-SHELL", "curl -f https://localhost:8443/health || exit 1"],
        "interval": 30,
        "timeout": 5,
        "retries": 3,
        "startPeriod": 60
      }
    }
  ]
}
```

#### 4.2 ECS Service Configuration

```hcl
# ecs_service.tf

resource "aws_ecs_service" "mcp_server" {
  name            = "mcp-server"
  cluster         = aws_ecs_cluster.main.id
  task_definition = aws_ecs_task_definition.mcp_server.arn
  desired_count   = 3  # HA: 3 tasks across 2 AZs
  launch_type     = "FARGATE"

  network_configuration {
    subnets = [
      aws_subnet.private_az1.id,
      aws_subnet.private_az2.id
    ]
    security_groups = [aws_security_group.mcp_server.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.mcp_server.arn
    container_name   = "mcp-server"
    container_port   = 8443
  }

  deployment_configuration {
    maximum_percent         = 200
    minimum_healthy_percent = 100
  }

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  # Auto Scaling
  lifecycle {
    ignore_changes = [desired_count]
  }

  depends_on = [aws_lb_listener.mcp_server]

  tags = {
    Name = "mcp-server-service"
  }
}

# Auto Scaling
resource "aws_appautoscaling_target" "mcp_server" {
  max_capacity       = 10
  min_capacity       = 3
  resource_id        = "service/${aws_ecs_cluster.main.name}/${aws_ecs_service.mcp_server.name}"
  scalable_dimension = "ecs:service:DesiredCount"
  service_namespace  = "ecs"
}

resource "aws_appautoscaling_policy" "mcp_server_cpu" {
  name               = "mcp-server-cpu-scaling"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.mcp_server.resource_id
  scalable_dimension = aws_appautoscaling_target.mcp_server.scalable_dimension
  service_namespace  = aws_appautoscaling_target.mcp_server.service_namespace

  target_tracking_scaling_policy_configuration {
    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
    }
    target_value = 70.0
  }
}
```

---

### 5. Data Storage & Caching

#### 5.1 S3 Bucket Configuration

```hcl
# s3.tf

resource "aws_s3_bucket" "codebase" {
  bucket = "yourcompany-mcp-codebase-context"

  tags = {
    Name        = "MCP Codebase Context"
    Compliance  = "SOC2,HIPAA,PCI-DSS"
  }
}

# Encryption
resource "aws_s3_bucket_server_side_encryption_configuration" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.codebase.arn
    }
  }
}

# Versioning
resource "aws_s3_bucket_versioning" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  versioning_configuration {
    status = "Enabled"
  }
}

# Block Public Access
resource "aws_s3_bucket_public_access_block" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# Lifecycle Policy
resource "aws_s3_bucket_lifecycle_configuration" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  rule {
    id     = "archive-old-versions"
    status = "Enabled"

    noncurrent_version_transition {
      noncurrent_days = 90
      storage_class   = "GLACIER"
    }

    noncurrent_version_expiration {
      noncurrent_days = 365
    }
  }
}

# Bucket Policy
resource "aws_s3_bucket_policy" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "DenyUnencryptedObjectUploads"
        Effect = "Deny"
        Principal = "*"
        Action = "s3:PutObject"
        Resource = "${aws_s3_bucket.codebase.arn}/*"
        Condition = {
          StringNotEquals = {
            "s3:x-amz-server-side-encryption" = "aws:kms"
          }
        }
      },
      {
        Sid    = "DenyInsecureTransport"
        Effect = "Deny"
        Principal = "*"
        Action = "s3:*"
        Resource = [
          aws_s3_bucket.codebase.arn,
          "${aws_s3_bucket.codebase.arn}/*"
        ]
        Condition = {
          Bool = {
            "aws:SecureTransport" = "false"
          }
        }
      }
    ]
  })
}
```

#### 5.2 ElastiCache Redis Configuration

```hcl
# elasticache.tf

resource "aws_elasticache_replication_group" "mcp_cache" {
  replication_group_id       = "mcp-cache"
  replication_group_description = "MCP Server Cache Layer"
  
  engine               = "redis"
  engine_version       = "7.0"
  node_type           = "cache.r6g.large"
  number_cache_clusters = 2  # Primary + 1 replica
  
  port                       = 6379
  parameter_group_name       = aws_elasticache_parameter_group.mcp_cache.name
  subnet_group_name          = aws_elasticache_subnet_group.mcp_cache.name
  security_group_ids         = [aws_security_group.elasticache.id]
  
  at_rest_encryption_enabled = true
  transit_encryption_enabled = true
  auth_token_enabled         = true
  
  automatic_failover_enabled = true
  multi_az_enabled          = true
  
  snapshot_retention_limit = 5
  snapshot_window         = "03:00-05:00"
  maintenance_window      = "sun:05:00-sun:07:00"
  
  notification_topic_arn = aws_sns_topic.elasticache_notifications.arn
  
  log_delivery_configuration {
    destination      = aws_cloudwatch_log_group.elasticache.name
    destination_type = "cloudwatch-logs"
    log_format       = "json"
    log_type         = "slow-log"
  }

  tags = {
    Name = "mcp-cache"
  }
}

resource "aws_elasticache_parameter_group" "mcp_cache" {
  name   = "mcp-cache-params"
  family = "redis7"

  parameter {
    name  = "maxmemory-policy"
    value = "allkeys-lru"
  }

  parameter {
    name  = "timeout"
    value = "300"
  }
}
```

---

### 6. AI Gateway Integration (Portkey)

#### 6.1 MCP to AI Gateway Integration

```python
# ai_gateway/portkey_client.py
import httpx
import os
from typing import AsyncGenerator

class PortkeyClient:
    """Client for AI Gateway (Portkey) - Unified LLM Access"""
    
    def __init__(self):
        self.base_url = os.getenv("AI_GATEWAY_URL")
        self.api_key = os.getenv("AI_GATEWAY_API_KEY")  # From Secrets Manager
        
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "x-portkey-api-key": self.api_key,
                "Content-Type": "application/json"
            },
            timeout=30.0
        )
    
    async def create_completion(
        self,
        prompt: str,
        model: str = "claude-3-sonnet",
        max_tokens: int = 1024,
        user_context: dict = None
    ) -> dict:
        """Create completion via AI Gateway"""
        
        payload = {
            "model": model,
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "max_tokens": max_tokens,
            "metadata": {
                "user": user_context.get("email") if user_context else "system",
                "org_id": user_context.get("org_id") if user_context else "default"
            }
        }
        
        response = await self.client.post(
            "/v1/chat/completions",
            json=payload
        )
        response.raise_for_status()
        
        return response.json()
    
    async def create_embedding(
        self,
        text: str,
        model: str = "text-embedding-ada-002"
    ) -> list[float]:
        """Create embeddings via AI Gateway"""
        
        payload = {
            "model": model,
            "input": text
        }
        
        response = await self.client.post(
            "/v1/embeddings",
            json=payload
        )
        response.raise_for_status()
        
        result = response.json()
        return result["data"][0]["embedding"]
    
    async def stream_completion(
        self,
        prompt: str,
        model: str = "claude-3-sonnet"
    ) -> AsyncGenerator[str, None]:
        """Stream completion from AI Gateway"""
        
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "stream": True
        }
        
        async with self.client.stream(
            "POST",
            "/v1/chat/completions",
            json=payload
        ) as response:
            async for line in response.aiter_lines():
                if line.startswith("data: "):
                    data = line[6:]
                    if data != "[DONE]":
                        yield data

# Usage in MCP Server
portkey = PortkeyClient()

async def enhance_code_search_with_llm(query: str, results: list) -> dict:
    """Use LLM to enhance search results"""
    
    prompt = f"""
    Given the following code search query: {query}
    
    And these search results:
    {json.dumps(results, indent=2)}
    
    Please provide:
    1. A ranked list of most relevant results
    2. A brief explanation of why each result is relevant
    3. Suggested related searches
    """
    
    response = await portkey.create_completion(
        prompt=prompt,
        model="claude-3-sonnet",
        max_tokens=2048
    )
    
    return response["choices"][0]["message"]["content"]
```

---

### 7. Security & Compliance

#### 7.1 KMS Key Management

```hcl
# kms.tf

resource "aws_kms_key" "codebase" {
  description             = "KMS key for MCP codebase encryption"
  deletion_window_in_days = 30
  enable_key_rotation     = true

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "Enable IAM User Permissions"
        Effect = "Allow"
        Principal = {
          AWS = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:root"
        }
        Action   = "kms:*"
        Resource = "*"
      },
      {
        Sid    = "Allow S3 to use the key"
        Effect = "Allow"
        Principal = {
          Service = "s3.amazonaws.com"
        }
        Action = [
          "kms:Decrypt",
          "kms:GenerateDataKey"
        ]
        Resource = "*"
      },
      {
        Sid    = "Allow ECS tasks to decrypt"
        Effect = "Allow"
        Principal = {
          AWS = aws_iam_role.mcp_server_task.arn
        }
        Action = [
          "kms:Decrypt",
          "kms:DescribeKey"
        ]
        Resource = "*"
      }
    ]
  })

  tags = {
    Name = "mcp-codebase-kms-key"
  }
}

resource "aws_kms_alias" "codebase" {
  name          = "alias/codebase-kms-key"
  target_key_id = aws_kms_key.codebase.key_id
}
```

#### 7.2 IAM Roles & Policies

```hcl
# iam.tf

# ECS Task Execution Role
resource "aws_iam_role" "ecs_task_execution" {
  name = "mcpEcsTaskExecutionRole"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "ecs-tasks.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "ecs_task_execution" {
  role       = aws_iam_role.ecs_task_execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

# MCP Server Task Role
resource "aws_iam_role" "mcp_server_task" {
  name = "mcpServerTaskRole"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "ecs-tasks.amazonaws.com"
        }
      }
    ]
  })
}

# S3 Access Policy
resource "aws_iam_role_policy" "mcp_server_s3" {
  name = "mcpServerS3Access"
  role = aws_iam_role.mcp_server_task.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:ListBucket"
        ]
        Resource = [
          aws_s3_bucket.codebase.arn,
          "${aws_s3_bucket.codebase.arn}/*"
        ]
      }
    ]
  })
}

# Secrets Manager Access
resource "aws_iam_role_policy" "mcp_server_secrets" {
  name = "mcpServerSecretsAccess"
  role = aws_iam_role.mcp_server_task.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "secretsmanager:GetSecretValue"
        ]
        Resource = [
          "arn:aws:secretsmanager:us-east-1:*:secret:mcp/*"
        ]
      }
    ]
  })
}

# KMS Decrypt
resource "aws_iam_role_policy" "mcp_server_kms" {
  name = "mcpServerKMSAccess"
  role = aws_iam_role.mcp_server_task.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "kms:Decrypt",
          "kms:DescribeKey"
        ]
        Resource = aws_kms_key.codebase.arn
      }
    ]
  })
}
```

#### 7.3 CloudWatch Logging & Monitoring

```hcl
# cloudwatch.tf

# Log Groups
resource "aws_cloudwatch_log_group" "mcp_server" {
  name              = "/ecs/mcp-server"
  retention_in_days = 90  # SOC2 compliance: 90 days minimum
  kms_key_id        = aws_kms_key.logs.arn

  tags = {
    Name = "mcp-server-logs"
  }
}

resource "aws_cloudwatch_log_group" "apigee" {
  name              = "/apigee/mcp-gateway"
  retention_in_days = 90
  kms_key_id        = aws_kms_key.logs.arn
}

# Metric Filters
resource "aws_cloudwatch_log_metric_filter" "unauthorized_access" {
  name           = "UnauthorizedAccessAttempts"
  log_group_name = aws_cloudwatch_log_group.mcp_server.name
  pattern        = "[time, request_id, level=ERROR, msg=\"*Unauthorized*\"]"

  metric_transformation {
    name      = "UnauthorizedAccessCount"
    namespace = "MCP/Security"
    value     = "1"
  }
}

resource "aws_cloudwatch_log_metric_filter" "dlp_violations" {
  name           = "DLPViolations"
  log_group_name = aws_cloudwatch_log_group.apigee.name
  pattern        = "[time, request_id, level, msg=\"*DLP*violation*\"]"

  metric_transformation {
    name      = "DLPViolationCount"
    namespace = "MCP/Security"
    value     = "1"
  }
}

# Alarms
resource "aws_cloudwatch_metric_alarm" "high_error_rate" {
  alarm_name          = "mcp-server-high-error-rate"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = "2"
  metric_name         = "5XXError"
  namespace           = "AWS/ApplicationELB"
  period              = "300"
  statistic           = "Sum"
  threshold           = "10"
  alarm_description   = "This metric monitors MCP server error rate"
  alarm_actions       = [aws_sns_topic.alerts.arn]

  dimensions = {
    LoadBalancer = aws_lb.mcp_server.arn_suffix
  }
}

resource "aws_cloudwatch_metric_alarm" "unauthorized_access" {
  alarm_name          = "mcp-unauthorized-access-spike"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = "1"
  metric_name         = "UnauthorizedAccessCount"
  namespace           = "MCP/Security"
  period              = "300"
  statistic           = "Sum"
  threshold           = "5"
  alarm_description   = "Alert on multiple unauthorized access attempts"
  alarm_actions       = [aws_sns_topic.security_alerts.arn]
}

# Dashboard
resource "aws_cloudwatch_dashboard" "mcp" {
  dashboard_name = "MCP-Server-Dashboard"

  dashboard_body = jsonencode({
    widgets = [
      {
        type = "metric"
        properties = {
          metrics = [
            ["AWS/ApplicationELB", "TargetResponseTime", { stat = "Average" }],
            [".", "RequestCount", { stat = "Sum" }],
            [".", "HTTPCode_Target_2XX_Count", { stat = "Sum" }],
            [".", "HTTPCode_Target_4XX_Count", { stat = "Sum" }],
            [".", "HTTPCode_Target_5XX_Count", { stat = "Sum" }]
          ]
          period = 300
          stat   = "Average"
          region = "us-east-1"
          title  = "MCP Server Performance"
        }
      },
      {
        type = "metric"
        properties = {
          metrics = [
            ["MCP/Security", "UnauthorizedAccessCount", { stat = "Sum" }],
            [".", "DLPViolationCount", { stat = "Sum" }]
          ]
          period = 300
          stat   = "Sum"
          region = "us-east-1"
          title  = "Security Metrics"
        }
      }
    ]
  })
}
```

#### 7.4 DLP Implementation

```python
# security/dlp_scanner.py
import re
from typing import List, Dict
import hashlib

class DLPScanner:
    """Data Loss Prevention Scanner for MCP Responses"""
    
    PATTERNS = {
        'ssn': {
            'regex': r'\b\d{3}-\d{2}-\d{4}\b',
            'severity': 'HIGH',
            'action': 'REDACT'
        },
        'credit_card': {
            'regex': r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
            'severity': 'HIGH',
            'action': 'REDACT'
        },
        'api_key': {
            'regex': r'\b[A-Za-z0-9]{32,}\b',
            'severity': 'MEDIUM',
            'action': 'ALERT'
        },
        'aws_access_key': {
            'regex': r'\b(AKIA[0-9A-Z]{16})\b',
            'severity': 'CRITICAL',
            'action': 'BLOCK'
        },
        'private_key': {
            'regex': r'-----BEGIN (RSA |EC )?PRIVATE KEY-----',
            'severity': 'CRITICAL',
            'action': 'BLOCK'
        },
        'email_internal': {
            'regex': r'\b[A-Za-z0-9._%+-]+@yourcompany\.com\b',
            'severity': 'LOW',
            'action': 'LOG'
        }
    }
    
    def __init__(self):
        self.compiled_patterns = {
            name: re.compile(pattern['regex'])
            for name, pattern in self.PATTERNS.items()
        }
    
    def scan(self, content: str) -> Dict:
        """Scan content for sensitive data"""
        violations = []
        
        for name, pattern in self.compiled_patterns.items():
            matches = pattern.findall(content)
            if matches:
                violation = {
                    'type': name,
                    'severity': self.PATTERNS[name]['severity'],
                    'action': self.PATTERNS[name]['action'],
                    'count': len(matches),
                    'sample': self._hash_sensitive(matches[0])
                }
                violations.append(violation)
        
        return {
            'has_violations': len(violations) > 0,
            'violations': violations,
            'content': self._apply_actions(content, violations)
        }
    
    def _apply_actions(self, content: str, violations: List[Dict]) -> str:
        """Apply DLP actions (redact/block)"""
        for violation in violations:
            action = violation['action']
            pattern_name = violation['type']
            pattern = self.compiled_patterns[pattern_name]
            
            if action == 'BLOCK':
                raise DLPViolationError(
                    f"Blocked due to {violation['severity']} violation: {pattern_name}"
                )
            elif action == 'REDACT':
                content = pattern.sub('[REDACTED]', content)
        
        return content
    
    def _hash_sensitive(self, value: str) -> str:
        """Hash sensitive value for logging"""
        return hashlib.sha256(value.encode()).hexdigest()[:16]

class DLPViolationError(Exception):
    pass

# Usage in MCP Server
dlp_scanner = DLPScanner()

async def scan_response(response: str, user_context: dict) -> str:
    """Scan MCP response before returning to client"""
    
    result = dlp_scanner.scan(response)
    
    if result['has_violations']:
        # Log violation
        await AuditLogger.log({
            'event': 'dlp_violation',
            'user': user_context['email'],
            'violations': result['violations'],
            'timestamp': datetime.utcnow().isoformat()
        })
    
    return result['content']
```

---

### 8. High Availability & Disaster Recovery

#### 8.1 Multi-AZ Deployment

```
Availability Zone 1 (us-east-1a)
├── APIGEE Gateway (1 instance)
├── MCP Server (2 Fargate tasks)
├── ElastiCache Redis (Primary)
└── NAT Gateway

Availability Zone 2 (us-east-1b)
├── APIGEE Gateway (1 instance)
├── MCP Server (1 Fargate task)
├── ElastiCache Redis (Replica)
└── NAT Gateway

Failover Strategy:
- ALB health checks every 30s
- Unhealthy threshold: 2 consecutive failures
- Automatic task replacement within 60s
- Redis automatic failover: < 30s
- APIGEE: Active-Active with NLB
```

#### 8.2 Backup Strategy

```hcl
# backup.tf

# S3 Cross-Region Replication
resource "aws_s3_bucket_replication_configuration" "codebase" {
  role   = aws_iam_role.replication.arn
  bucket = aws_s3_bucket.codebase.id

  rule {
    id     = "replicate-to-dr"
    status = "Enabled"

    destination {
      bucket        = aws_s3_bucket.codebase_dr.arn
      storage_class = "STANDARD_IA"
      
      encryption_configuration {
        replica_kms_key_id = aws_kms_key.codebase_dr.arn
      }
    }
  }
}

# RDS Snapshots (if using RDS for metadata)
resource "aws_db_instance" "metadata" {
  # ... other config ...
  
  backup_retention_period = 30
  backup_window          = "03:00-04:00"
  
  # Cross-region snapshots
  copy_tags_to_snapshot = true
}

# Automated Snapshot Lifecycle
resource "aws_backup_plan" "mcp" {
  name = "mcp-backup-plan"

  rule {
    rule_name         = "daily_backup"
    target_vault_name = aws_backup_vault.mcp.name
    schedule          = "cron(0 2 * * ? *)"  # 2 AM daily

    lifecycle {
      delete_after = 90  # Retain for 90 days
    }
  }

  rule {
    rule_name         = "weekly_backup"
    target_vault_name = aws_backup_vault.mcp.name
    schedule          = "cron(0 3 ? * SUN *)"  # Sunday 3 AM

    lifecycle {
      cold_storage_after = 30
      delete_after      = 365
    }
  }
}
```

#### 8.3 DR Runbook

```markdown
# MCP Disaster Recovery Runbook

## RPO: 1 hour
## RTO: 4 hours

### Scenario 1: Complete AZ Failure

1. **Detection** (0-5 min)
   - CloudWatch alarms trigger
   - Automatic failover to healthy AZ
   
2. **Validation** (5-15 min)
   - Verify service health in remaining AZ
   - Check Redis failover status
   - Validate APIGEE routing
   
3. **Scale Up** (15-30 min)
   - Increase task count in healthy AZ
   ```bash
   aws ecs update-service \
     --cluster mcp-cluster \
     --service mcp-server \
     --desired-count 5
   ```

### Scenario 2: Complete Region Failure

1. **Detection** (0-10 min)
   - Route53 health checks fail
   - Manual verification required
   
2. **Activate DR Region** (10-60 min)
   ```bash
   # Switch to DR region
   export AWS_REGION=us-west-2
   
   # Deploy infrastructure from Terraform
   cd terraform/dr
   terraform apply -auto-approve
   
   # Restore from S3 replication
   # Restore ElastiCache from snapshot
   ```

3. **Update DNS** (60-90 min)
   ```bash
   # Update Route53
   aws route53 change-resource-record-sets \
     --hosted-zone-id Z1234567890ABC \
     --change-batch file://dr-dns-change.json
   ```

4. **Verify & Monitor** (90-120 min)
   - Run integration tests
   - Monitor CloudWatch dashboards
   - Notify stakeholders
```

---

### 9. Compliance & Audit

#### 9.1 Audit Logging

```python
# audit/audit_logger.py
import boto3
import json
from datetime import datetime
from typing import Dict, Any

class AuditLogger:
    """Comprehensive audit logging for compliance"""
    
    def __init__(self):
        self.s3 = boto3.client('s3')
        self.cloudwatch = boto3.client('logs')
        self.bucket = 'yourcompany-mcp-audit-logs'
        self.log_group = '/mcp/audit'
        
    async def log(self, event: Dict[str, Any]):
        """Log audit event to multiple destinations"""
        
        # Enrich event
        enriched_event = {
            'timestamp': datetime.utcnow().isoformat(),
            'service': 'mcp-server',
            'version': '1.0',
            **event
        }
        
        # CloudWatch Logs (real-time monitoring)
        await self._log_to_cloudwatch(enriched_event)
        
        # S3 (long-term retention, compliance)
        await self._log_to_s3(enriched_event)
        
        # DynamoDB (queryable audit trail)
        await self._log_to_dynamodb(enriched_event)
    
    async def _log_to_cloudwatch(self, event: Dict):
        """Log to CloudWatch for real-time monitoring"""
        self.cloudwatch.put_log_events(
            logGroupName=self.log_group,
            logStreamName=f"{event['user']}/{datetime.utcnow().strftime('%Y-%m-%d')}",
            logEvents=[{
                'timestamp': int(datetime.utcnow().timestamp() * 1000),
                'message': json.dumps(event)
            }]
        )
    
    async def _log_to_s3(self, event: Dict):
        """Log to S3 for compliance retention"""
        date = datetime.utcnow()
        key = f"audit/{date.year}/{date.month:02d}/{date.day:02d}/{event['user']}/{datetime.utcnow().isoformat()}.json"
        
        self.s3.put_object(
            Bucket=self.bucket,
            Key=key,
            Body=json.dumps(event),
            ServerSideEncryption='aws:kms',
            SSEKMSKeyId='alias/audit-logs-kms-key'
        )
    
    async def _log_to_dynamodb(self, event: Dict):
        """Log to DynamoDB for queryable audit trail"""
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('mcp-audit-trail')
        
        table.put_item(Item={
            'event_id': event.get('event_id', str(uuid.uuid4())),
            'timestamp': event['timestamp'],
            'user': event.get('user', 'unknown'),
            'action': event.get('action', 'unknown'),
            'resource': event.get('resource', ''),
            'result': event.get('result', 'success'),
            'metadata': json.dumps(event)
        })

# Audit Events to Track
AUDIT_EVENTS = {
    'authentication': ['login', 'logout', 'token_refresh'],
    'authorization': ['access_granted', 'access_denied'],
    'data_access': ['file_read', 'repo_access', 'search_query'],
    'configuration': ['policy_change', 'user_added', 'permission_updated'],
    'security': ['dlp_violation', 'rate_limit_exceeded', 'suspicious_activity']
}
```

#### 9.2 Compliance Controls Matrix

```markdown
# SOC2 / HIPAA / PCI-DSS Compliance Controls

## Access Control
| Control | Implementation | Evidence |
|---------|----------------|----------|
| User Authentication | Ping OAuth2/OIDC | CloudWatch logs |
| MFA Enforcement | Ping MFA policies | Ping audit logs |
| Least Privilege | ABAC policies | IAM policies, ABAC rules |
| Session Management | JWT with 1h expiry | Token logs |

## Encryption
| Control | Implementation | Evidence |
|---------|----------------|----------|
| Data at Rest | S3 KMS, EBS encryption | KMS key rotation logs |
| Data in Transit | TLS 1.3, mTLS | ALB SSL policies |
| Key Management | AWS KMS, auto-rotation | KMS audit logs |

## Logging & Monitoring
| Control | Implementation | Evidence |
|---------|----------------|----------|
| Audit Logging | CloudWatch, S3 | 90-day retention |
| Security Monitoring | CloudWatch Alarms | Alert history |
| Access Logs | ALB logs, VPC Flow Logs | S3 access logs |

## Data Protection
| Control | Implementation | Evidence |
|---------|----------------|----------|
| DLP | Pattern scanning | DLP violation logs |
| Data Classification | S3 tags | Tag compliance reports |
| Backup & Recovery | Automated snapshots | Backup logs |
| Data Residency | US-only regions | Resource tags |

## Network Security
| Control | Implementation | Evidence |
|---------|----------------|----------|
| Network Segmentation | VPC, subnets, SGs | VPC Flow Logs |
| Firewall | Security Groups, NACLs | SG audit logs |
| Intrusion Detection | GuardDuty | GuardDuty findings |
| DDoS Protection | AWS Shield, WAF | Shield events |

## Incident Response
| Control | Implementation | Evidence |
|---------|----------------|----------|
| Alerting | CloudWatch Alarms, SNS | Alert logs |
| Response Plan | DR Runbook | Incident reports |
| Forensics | CloudTrail, audit logs | Investigation logs |
```

---

### 10. Deployment Guide

#### 10.1 Prerequisites

```bash
# Required tools
- Terraform >= 1.5.0
- AWS CLI >= 2.13.0
- Docker >= 24.0.0
- Python >= 3.11

# AWS Account Setup
- Admin access to AWS account
- AWS Organizations with SCPs configured
- VPC with Direct Connect/VPN
- Ping Identity configured

# Secrets to configure
- Ping OIDC client credentials
- AI Gateway API key
- TLS certificates for mTLS
```

#### 10.2 Step-by-Step Deployment

```bash
# Step 1: Clone repository
git clone https://github.com/yourcompany/mcp-infrastructure.git
cd mcp-infrastructure

# Step 2: Configure Terraform variables
cat > terraform.tfvars <<EOF
aws_region          = "us-east-1"
environment         = "production"
vpc_cidr            = "10.0.0.0/16"
ping_oidc_issuer    = "https://ping.yourcompany.com"
ping_client_id      = "mcp-codebase-api"
ai_gateway_url      = "https://portkey.yourcompany.com"
codebase_bucket     = "yourcompany-mcp-codebase"
EOF

# Step 3: Initialize Terraform
terraform init

# Step 4: Plan deployment
terraform plan -out=tfplan

# Step 5: Apply infrastructure
terraform apply tfplan

# Step 6: Store secrets
aws secretsmanager create-secret \
  --name mcp/ping-client-secret \
  --secret-string "YOUR_PING_CLIENT_SECRET"

aws secretsmanager create-secret \
  --name mcp/ai-gateway-key \
  --secret-string "YOUR_AI_GATEWAY_KEY"

# Step 7: Build and push Docker image
cd ../mcp-server
docker build -t mcp-server:latest .

aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin \
  ACCOUNT.dkr.ecr.us-east-1.amazonaws.com

docker tag mcp-server:latest \
  ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/mcp-server:latest

docker push ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/mcp-server:latest

# Step 8: Deploy ECS service
aws ecs update-service \
  --cluster mcp-cluster \
  --service mcp-server \
  --force-new-deployment

# Step 9: Configure APIGEE
# (Manual step - import APIGEE proxy configuration)

# Step 10: Index initial codebase
python scripts/index_codebase.py \
  --repos repo1,repo2,repo3 \
  --bucket yourcompany-mcp-codebase

# Step 11: Validate deployment
curl -H "Authorization: Bearer $TOKEN" \
  https://api.yourcompany.com/mcp/v1/health

# Step 12: Configure IDE clients
# Update IDE MCP configuration with:
# - Server URL: https://api.yourcompany.com/mcp
# - OAuth2 settings from Ping
```

---

### 11. Operations & Maintenance

#### 11.1 Monitoring Checklist

```markdown
# Daily Monitoring
- [ ] Check CloudWatch dashboard
- [ ] Review error rate (should be < 1%)
- [ ] Verify no DLP violations
- [ ] Check unauthorized access attempts
- [ ] Review ECS task health

# Weekly Monitoring
- [ ] Analyze cost trends
- [ ] Review scaling patterns
- [ ] Check backup success rate
- [ ] Audit log analysis
- [ ] Security group audit

# Monthly Monitoring
- [ ] Compliance report generation
- [ ] DR drill execution
- [ ] Patch management review
- [ ] Access review (user permissions)
- [ ] Cost optimization review
```

#### 11.2 Scaling Guidelines

```python
# Auto-scaling triggers
CPU_THRESHOLD = 70  # Scale up if CPU > 70%
MEMORY_THRESHOLD = 80  # Scale up if memory > 80%
REQUEST_COUNT_THRESHOLD = 1000  # Scale up if requests > 1000/min

# Manual scaling
# For planned events (e.g., onboarding new team)
aws ecs update-service \
  --cluster mcp-cluster \
  --service mcp-server \
  --desired-count 10

# For cache layer
# Increase Redis node size if memory > 80%
aws elasticache modify-replication-group \
  --replication-group-id mcp-cache \
  --cache-node-type cache.r6g.xlarge \
  --apply-immediately
```

---

## Cost Estimation

```
Monthly Cost Breakdown (US East 1):

Compute:
- ECS Fargate (3 tasks, 1 vCPU, 2GB): ~$88/month
- APIGEE (2 instances, m5.large): ~$144/month

Storage:
- S3 (100GB codebase): ~$2.30/month
- S3 (audit logs, 50GB/month): ~$1.15/month
- ElastiCache Redis (cache.r6g.large): ~$187/month

Networking:
- ALB: ~$22/month
- NAT Gateway (2 AZs): ~$64/month
- Data Transfer: ~$45/month (estimated)

Security:
- KMS: ~$2/month
- Secrets Manager: ~$0.80/month
- WAF (if used): ~$5/month + rules

Monitoring:
- CloudWatch Logs (50GB): ~$25/month
- CloudWatch Metrics: ~$10/month

AI Gateway (Portkey):
- API calls: Variable based on usage

Total Estimated: ~$596/month (excluding AI Gateway usage)
```

---

## Appendix

### A. MCP Client Configuration (IDE)

```json
// VS Code settings.json
{
  "mcp.servers": {
    "codebase-context": {
      "url": "https://api.yourcompany.com/mcp",
      "auth": {
        "type": "oauth2",
        "provider": "ping",
        "clientId": "mcp-vscode-client",
        "scopes": ["mcp:read", "mcp:query"],
        "authorizationUrl": "https://ping.yourcompany.com/oauth2/authorize",
        "tokenUrl": "https://ping.yourcompany.com/oauth2/token"
      },
      "tools": ["search_codebase", "get_file_context", "get_function_definition"]
    }
  }
}
```

### B. ABAC Policy Examples

```json
// Allow engineering team full access to their repos
{
  "version": "1.0",
  "policies": [
    {
      "id": "policy-eng-full-access",
      "effect": "allow",
      "principal": {
        "groups": ["engineering"]
      },
      "action": ["read", "query", "search"],
      "resource": "repo:*",
      "condition": {
        "StringEquals": {
          "repo:team": "${user.org_id}"
        }
      }
    },
    {
      "id": "policy-contractor-readonly",
      "effect": "allow",
      "principal": {
        "groups": ["contractors"]
      },
      "action": ["read"],
      "resource": "repo:public-*"
    },
    {
      "id": "policy-deny-sensitive",
      "effect": "deny",
      "principal": {
        "groups": ["*"]
      },
      "action": ["*"],
      "resource": "repo:*-sensitive"
    }
  ]
}
```

### C. Testing Strategy

```python
# Integration tests
import pytest
import httpx

@pytest.fixture
async def authenticated_client():
    # Get OAuth2 token
    token = await get_test_token()
    return httpx.AsyncClient(
        base_url="https://api.yourcompany.com/mcp",
        headers={"Authorization": f"Bearer {token}"}
    )

@pytest.mark.asyncio
async def test_search_codebase(authenticated_client):
    response = await authenticated_client.post("/v1/messages", json={
        "tool": "search_codebase",
        "arguments": {
            "query": "authentication",
            "repo": "my-service"
        }
    })
    assert response.status_code == 200
    data = response.json()
    assert "results" in data

@pytest.mark.asyncio
async def test_unauthorized_repo_access(authenticated_client):
    response = await authenticated_client.post("/v1/messages", json={
        "tool": "get_file_context",
        "arguments": {
            "repo": "restricted-repo",
            "file_path": "secrets.py"
        }
    })
    assert response.status_code == 403

# Load testing
# Use k6 or Locust
# Target: 1000 requests/min with p99 latency < 500ms
```

---

## Summary

This architecture provides:

✅ **Security**: Multi-layer defense (Ping → APIGEE → MCP), mTLS, ABAC, DLP  
✅ **Compliance**: SOC2, HIPAA, PCI-DSS controls, audit logging, encryption  
✅ **Scalability**: Auto-scaling ECS, ElastiCache, multi-AZ deployment  
✅ **User Context**: Full OAuth2 flow preserving user identity  
✅ **High Availability**: Multi-AZ, automated failover, 99.9% SLA  
✅ **Observability**: CloudWatch dashboards, alarms, comprehensive logging  
✅ **Cost-Effective**: Serverless compute, right-sized resources  

**Next Steps:**
1. Review with security team
2. Configure Ping OAuth2 client
3. Set up APIGEE proxy
4. Deploy Terraform infrastructure
5. Index initial codebase
6. Pilot with small team
7. Roll out to organization
