# MCP Operations Quick Reference Card

## 🚀 Common Operations

### Deployment

```bash
# Initial deployment
cd terraform && terraform apply

# Update MCP server
docker build -t mcp-server:latest .
docker push $ECR_REPO:latest
aws ecs update-service --cluster mcp-cluster --service mcp-server --force-new-deployment

# Rollback
aws ecs update-service --cluster mcp-cluster --service mcp-server \
  --task-definition <PREVIOUS_VERSION>
```

### Monitoring

```bash
# View service status
aws ecs describe-services --cluster mcp-cluster --services mcp-server

# Live logs
aws logs tail /ecs/mcp-server --follow

# Check task health
aws elbv2 describe-target-health --target-group-arn <TG_ARN>

# CloudWatch dashboard
open https://console.aws.amazon.com/cloudwatch/home#dashboards:name=MCP-Production
```

### Scaling

```bash
# Manual scale
aws ecs update-service --cluster mcp-cluster --service mcp-server --desired-count 5

# View current scale
aws ecs describe-services --cluster mcp-cluster --services mcp-server \
  --query 'services[0].desiredCount'

# Check auto-scaling status
aws application-autoscaling describe-scalable-targets \
  --service-namespace ecs --resource-id service/mcp-cluster/mcp-server
```

### Secrets Management

```bash
# Update secret
aws secretsmanager update-secret --secret-id mcp/ping-client-secret \
  --secret-string "NEW_SECRET"

# Rotate secret
aws secretsmanager rotate-secret --secret-id mcp/ai-gateway-key

# View all MCP secrets
aws secretsmanager list-secrets --filters Key=name,Values=mcp/
```

---

## 🔍 Troubleshooting

### Issue: High Error Rate

**Quick Checks:**
```bash
# 1. Check task health
aws ecs describe-services --cluster mcp-cluster --services mcp-server

# 2. View recent errors
aws logs filter-pattern /ecs/mcp-server --filter-pattern "ERROR" --start-time 1h

# 3. Check ALB health
aws elbv2 describe-target-health --target-group-arn <TG_ARN>

# 4. Check Redis connection
aws elasticache describe-replication-groups --replication-group-id mcp-cache
```

**Common Causes:**
- Redis connection timeout → Check security groups
- S3 access denied → Check IAM role
- Memory/CPU saturation → Scale up

### Issue: Authentication Failures

**Quick Checks:**
```bash
# 1. Verify JWT
# Use jwt.io to decode token and check claims

# 2. Check Ping JWKS
curl https://ping.yourcompany.com/.well-known/jwks.json

# 3. APIGEE logs
# Check APIGEE UI for JWT validation errors

# 4. Check user context
aws logs filter-pattern /ecs/mcp-server --filter-pattern "Unauthorized"
```

**Common Causes:**
- Expired token → User needs to re-authenticate
- Wrong audience → Check APIGEE policy
- Missing claims → Check Ping configuration

### Issue: Slow Response Times

**Quick Checks:**
```bash
# 1. Check cache hit ratio
aws cloudwatch get-metric-statistics --namespace MCP/Performance \
  --metric-name CacheHitRatio --statistics Average --start-time 1h --end-time now

# 2. Check ElastiCache metrics
aws cloudwatch get-metric-statistics --namespace AWS/ElastiCache \
  --metric-name CPUUtilization --dimensions Name=CacheClusterId,Value=mcp-cache

# 3. Check ECS task CPU/Memory
aws cloudwatch get-metric-statistics --namespace AWS/ECS \
  --metric-name CPUUtilization --dimensions Name=ServiceName,Value=mcp-server

# 4. Check S3 latency
aws cloudwatch get-metric-statistics --namespace AWS/S3 \
  --metric-name FirstByteLatency --dimensions Name=BucketName,Value=yourcompany-mcp-codebase
```

**Common Causes:**
- Cold cache → Warm up cache
- S3 throttling → Increase request rate
- Undersized tasks → Scale up

### Issue: DLP False Positives

**Quick Checks:**
```bash
# 1. Review DLP violations
aws logs filter-pattern /apigee/mcp-gateway --filter-pattern "DLP"

# 2. Check patterns
cat mcp-server/security/dlp_scanner.py | grep PATTERNS -A 20

# 3. View blocked content hash
aws logs tail /ecs/mcp-server --filter-pattern "DLP_VIOLATION"
```

**Solutions:**
- Update regex patterns in `dlp_scanner.py`
- Add exclusions for test data
- Adjust severity levels

---

## 📊 Key Metrics

### Health Indicators

| Metric | Target | Alert Threshold |
|--------|--------|-----------------|
| Availability | >99.9% | <99% |
| p95 Latency | <500ms | >1000ms |
| Error Rate | <1% | >5% |
| Cache Hit Ratio | >80% | <60% |
| CPU Utilization | <70% | >85% |
| Memory Utilization | <80% | >90% |

### Security Metrics

| Metric | Target | Alert Threshold |
|--------|--------|-----------------|
| Unauthorized Access | 0 | >5/hour |
| DLP Violations | <5/month | >10/day |
| Failed Logins | <1% | >5% |
| JWT Validation Failures | <0.1% | >1% |

### Cost Metrics

| Resource | Daily Cost | Monthly Budget |
|----------|------------|----------------|
| ECS Fargate | ~$3 | ~$90 |
| ElastiCache | ~$6 | ~$190 |
| NAT Gateway | ~$2 | ~$65 |
| S3 | ~$0.10 | ~$5 |
| Total | ~$11 | ~$450 |

---

## 🔔 Alert Response

### P1: Service Down

**Immediate Actions:**
1. Check ECS service status
2. Check ALB target health
3. Check recent deployments
4. Engage on-call SRE

**Escalation:** 15 minutes → L2, 30 minutes → L3

### P2: High Error Rate (>5%)

**Immediate Actions:**
1. Check CloudWatch logs for errors
2. Verify Redis connectivity
3. Check S3 access
4. Consider rollback

**Escalation:** 30 minutes → L2

### P3: High Latency (>1s p95)

**Immediate Actions:**
1. Check cache hit ratio
2. Review ECS metrics
3. Check S3 throttling
4. Consider scaling up

**Escalation:** 1 hour → L2

### P4: DLP Violations (>10/day)

**Immediate Actions:**
1. Review violation patterns
2. Check for data leak
3. Investigate user activity
4. Notify security team

**Escalation:** Immediate → Security team

---

## 🛠️ Maintenance Tasks

### Daily
- [ ] Review CloudWatch dashboard
- [ ] Check error rate (<1%)
- [ ] Verify no DLP violations
- [ ] Check cost trends

### Weekly
- [ ] Review scaling patterns
- [ ] Analyze slow queries
- [ ] Check backup success
- [ ] Audit access logs

### Monthly
- [ ] Review ABAC policies
- [ ] Update dependencies
- [ ] Compliance report
- [ ] Cost optimization review
- [ ] DR drill

### Quarterly
- [ ] Security assessment
- [ ] Performance review
- [ ] Capacity planning
- [ ] Major version updates

---

## 📞 Contact Information

### Escalation Path
1. **L1**: Platform Team - platform-team@yourcompany.com
2. **L2**: Senior SRE - Slack: #mcp-ops
3. **L3**: Engineering Lead - PagerDuty

### Specialists
- **Security**: security@yourcompany.com
- **Compliance**: compliance@yourcompany.com
- **Networking**: network-ops@yourcompany.com
- **Ping Identity**: identity-team@yourcompany.com

---

## 🔗 Quick Links

### Dashboards
- [CloudWatch](https://console.aws.amazon.com/cloudwatch/home#dashboards:name=MCP-Production)
- [APIGEE](https://apigee.yourcompany.com)
- [Ping Admin](https://ping.yourcompany.com/admin)

### Documentation
- [Confluence](https://wiki.yourcompany.com/mcp)
- [Runbooks](https://github.com/yourcompany/mcp-infrastructure/docs/runbooks)
- [Slack Channel](https://yourcompany.slack.com/archives/mcp-support)

### Tools
- [Terraform Cloud](https://app.terraform.io/app/yourcompany/workspaces/mcp-prod)
- [ECR](https://console.aws.amazon.com/ecr/repositories/mcp-server)
- [ECS](https://console.aws.amazon.com/ecs/home#/clusters/mcp-cluster)

---

## 💡 Pro Tips

1. **Use AWS SSM Session Manager** for secure access to tasks (no SSH needed)
   ```bash
   aws ecs execute-command --cluster mcp-cluster --task <TASK_ID> \
     --container mcp-server --interactive --command "/bin/bash"
   ```

2. **Filter logs by user** for troubleshooting
   ```bash
   aws logs filter-pattern /ecs/mcp-server \
     --filter-pattern "user.email=john.doe@yourcompany.com"
   ```

3. **Export CloudWatch logs** for analysis
   ```bash
   aws logs create-export-task --log-group-name /ecs/mcp-server \
     --from 1699996400000 --to 1700000000000 \
     --destination s3://yourcompany-logs/mcp/
   ```

4. **Test ABAC policies** before deploying
   ```python
   python -m pytest tests/test_abac.py -v -k "test_repo_access"
   ```

5. **Warm up cache** before high-traffic events
   ```bash
   python scripts/warm_cache.py --repos all
   ```

---

## 🎯 Performance Tuning

### If latency is high:
1. Increase ElastiCache node size
2. Enable Redis cluster mode
3. Add more ECS tasks
4. Optimize S3 access patterns

### If costs are high:
1. Review S3 lifecycle policies
2. Optimize CloudWatch Logs retention
3. Use Fargate Spot for dev/test
4. Right-size ECS tasks

### If error rate is high:
1. Check dependencies (Redis, S3, Secrets Manager)
2. Review recent code changes
3. Check for throttling
4. Verify IAM permissions

---

**Last Updated:** 2025-11-16  
**Version:** 1.0  
**Maintained By:** Platform Engineering Team
