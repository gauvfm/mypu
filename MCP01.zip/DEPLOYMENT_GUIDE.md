# MCP Enterprise Deployment Guide

## Pre-Deployment Checklist

### 1. AWS Account Preparation
- [ ] AWS Account with administrative access
- [ ] AWS CLI v2.13+ installed and configured
- [ ] Terraform v1.5+ installed
- [ ] Docker v24+ installed
- [ ] Python 3.11+ installed

### 2. Network Prerequisites
- [ ] Direct Connect or VPN configured for remote users
- [ ] Corporate network CIDR documented
- [ ] VPN CIDR documented
- [ ] DNS zone for MCP services available

### 3. Identity & Access
- [ ] Ping Identity OAuth2/OIDC configured
- [ ] Ping client ID and secret obtained
- [ ] Service accounts created in AWS Secrets Manager
- [ ] TLS certificates for mTLS obtained

### 4. Third-Party Services
- [ ] APIGEE API Gateway access
- [ ] AI Gateway (Portkey) configured
- [ ] AI Gateway API key obtained

---

## Phase 1: Infrastructure Setup (Day 1)

### Step 1: Clone Repository and Configure

```bash
# Clone the repository
git clone https://github.com/yourcompany/mcp-infrastructure.git
cd mcp-infrastructure

# Configure AWS credentials
export AWS_PROFILE=yourcompany-prod
export AWS_REGION=us-east-1

# Verify AWS access
aws sts get-caller-identity
```

### Step 2: Configure Terraform Variables

Create `terraform/terraform.tfvars`:

```hcl
# terraform/terraform.tfvars
aws_region          = "us-east-1"
environment         = "production"
vpc_cidr            = "10.0.0.0/16"
ping_oidc_issuer    = "https://ping.yourcompany.com"
ping_client_id      = "mcp-codebase-api"
ai_gateway_url      = "https://portkey.yourcompany.com"
codebase_bucket     = "yourcompany-mcp-codebase"
corporate_cidr      = "10.0.0.0/8"
vpn_cidr            = "172.16.0.0/12"
```

### Step 3: Initialize and Deploy Infrastructure

```bash
cd terraform

# Initialize Terraform
terraform init

# Validate configuration
terraform validate

# Plan deployment
terraform plan -out=tfplan

# Review the plan carefully
# Expected resources: ~80 resources

# Apply infrastructure
terraform apply tfplan

# Save outputs
terraform output > ../outputs.txt
```

**Expected Duration:** 20-30 minutes

### Step 4: Store Secrets in AWS Secrets Manager

```bash
# Redis auth token (from ElastiCache output)
REDIS_AUTH=$(aws elasticache describe-replication-groups \
  --replication-group-id mcp-cache \
  --query 'ReplicationGroups[0].AuthTokenEnabled' \
  --output text)

aws secretsmanager create-secret \
  --name mcp/redis-auth-token \
  --secret-string "$REDIS_AUTH" \
  --region us-east-1

# Ping client secret
read -s -p "Enter Ping Client Secret: " PING_SECRET
echo

aws secretsmanager create-secret \
  --name mcp/ping-client-secret \
  --secret-string "$PING_SECRET" \
  --region us-east-1

# AI Gateway API key
read -s -p "Enter AI Gateway API Key: " AI_KEY
echo

aws secretsmanager create-secret \
  --name mcp/ai-gateway-key \
  --secret-string "$AI_KEY" \
  --region us-east-1

# Verify secrets
aws secretsmanager list-secrets \
  --filters Key=name,Values=mcp/ \
  --region us-east-1
```

---

## Phase 2: Application Deployment (Day 1-2)

### Step 1: Build MCP Server Docker Image

```bash
cd ../mcp-server

# Review Dockerfile
cat Dockerfile

# Build image
docker build -t mcp-server:latest .

# Test locally (optional)
docker run -p 8443:8443 \
  -e AWS_REGION=us-east-1 \
  -e LOG_LEVEL=DEBUG \
  mcp-server:latest
```

### Step 2: Push to ECR

```bash
# Get ECR repository URL from Terraform output
ECR_REPO=$(terraform -chdir=../terraform output -raw ecr_repository_url)

# Login to ECR
aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin $ECR_REPO

# Tag image
docker tag mcp-server:latest ${ECR_REPO}:latest
docker tag mcp-server:latest ${ECR_REPO}:v1.0.0

# Push image
docker push ${ECR_REPO}:latest
docker push ${ECR_REPO}:v1.0.0

# Verify
aws ecr describe-images \
  --repository-name mcp-server \
  --region us-east-1
```

### Step 3: Deploy ECS Service

```bash
# The ECS service is already created by Terraform
# Force new deployment with latest image
aws ecs update-service \
  --cluster mcp-cluster \
  --service mcp-server \
  --force-new-deployment \
  --region us-east-1

# Monitor deployment
aws ecs describe-services \
  --cluster mcp-cluster \
  --services mcp-server \
  --region us-east-1

# Check task status
aws ecs list-tasks \
  --cluster mcp-cluster \
  --service-name mcp-server \
  --region us-east-1

# View logs
aws logs tail /ecs/mcp-server --follow --region us-east-1
```

**Expected Duration:** 15-20 minutes for deployment

### Step 4: Verify Health

```bash
# Get ALB DNS name
ALB_DNS=$(terraform -chdir=../terraform output -raw alb_dns_name)

# Health check (from within VPC)
curl -k https://${ALB_DNS}/health

# Expected response:
# {"status":"healthy","service":"mcp-codebase-server"}
```

---

## Phase 3: APIGEE Configuration (Day 2)

### Step 1: Create API Proxy

Create a new API Proxy in APIGEE:

**Proxy Details:**
- Name: `mcp-codebase-api`
- Base Path: `/mcp`
- Target URL: `https://<ALB_DNS>`

### Step 2: Configure Policies

**Policy Flow:**

```
Request Flow:
1. SpikeArrest (Rate Limiting)
2. VerifyJWT (Ping validation)
3. AssignMessage (Extract user context)
4. ServiceCallout (Optional: Logging)
5. TargetConnection (mTLS to MCP Server)

Response Flow:
1. JavaScript (DLP Scanning)
2. MessageLogging (Audit)
3. AssignMessage (Headers cleanup)
```

**Policy: VerifyJWT**

```xml
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<VerifyJWT name="Verify-Ping-JWT">
    <Algorithm>RS256</Algorithm>
    <Source>request.header.authorization</Source>
    <IgnoreUnresolvedVariables>false</IgnoreUnresolvedVariables>
    <PublicKey>
        <JWKS uri="https://ping.yourcompany.com/.well-known/jwks.json"/>
    </PublicKey>
    <Subject>user@yourcompany.com</Subject>
    <Issuer>https://ping.yourcompany.com</Issuer>
    <Audience>mcp-codebase-api</Audience>
</VerifyJWT>
```

**Policy: ExtractVariables**

```xml
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<ExtractVariables name="Extract-User-Context">
    <Source>request.header.authorization</Source>
    <JSONPayload>
        <Variable name="user.email">
            <JSONPath>$.email</JSONPath>
        </Variable>
        <Variable name="user.groups">
            <JSONPath>$.groups</JSONPath>
        </Variable>
        <Variable name="user.org_id">
            <JSONPath>$.org_id</JSONPath>
        </Variable>
    </JSONPayload>
</ExtractVariables>
```

**Policy: SpikeArrest**

```xml
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<SpikeArrest name="Spike-Arrest">
    <Identifier ref="user.email"/>
    <Rate>1000pm</Rate>
</SpikeArrest>
```

### Step 3: Deploy API Proxy

```bash
# Package API proxy
cd apigee-config
zip -r mcp-api-proxy.zip apiproxy/

# Deploy using APIGEE CLI or UI
# Through UI: API Proxies → Upload → Deploy to 'prod'
```

---

## Phase 4: Codebase Indexing (Day 2-3)

### Step 1: Prepare Indexing Script

```bash
cd ../scripts

# Install dependencies
pip install boto3 gitpython opensearch-py --break-system-packages

# Configure
cat > indexer_config.json <<EOF
{
  "repositories": [
    {
      "name": "backend-service",
      "url": "https://git-codecommit.us-east-1.amazonaws.com/v1/repos/backend-service"
    },
    {
      "name": "frontend-app",
      "url": "https://git-codecommit.us-east-1.amazonaws.com/v1/repos/frontend-app"
    }
  ],
  "s3_bucket": "yourcompany-mcp-codebase",
  "opensearch_endpoint": "vpc-mcp-search-xxx.us-east-1.es.amazonaws.com"
}
EOF
```

### Step 2: Run Initial Indexing

```bash
# Run indexer
python index_codebase.py \
  --config indexer_config.json \
  --mode full

# Monitor progress
tail -f indexer.log

# Verify in S3
aws s3 ls s3://yourcompany-mcp-codebase/ --recursive
```

**Expected Duration:** 1-4 hours depending on codebase size

### Step 3: Set Up Scheduled Indexing

```bash
# Create EventBridge rule for daily indexing
aws events put-rule \
  --name mcp-daily-index \
  --schedule-expression "cron(0 2 * * ? *)" \
  --state ENABLED

# Create Lambda function for indexing (or use ECS Task)
# Associate with EventBridge rule
```

---

## Phase 5: Testing & Validation (Day 3-4)

### Step 1: Integration Testing

```bash
cd ../tests

# Install test dependencies
pip install pytest httpx pytest-asyncio --break-system-packages

# Configure test environment
export MCP_API_URL="https://api.yourcompany.com/mcp"
export TEST_USER_EMAIL="test.user@yourcompany.com"

# Run integration tests
pytest test_integration.py -v

# Expected output:
# test_health_check PASSED
# test_search_codebase PASSED
# test_get_file_context PASSED
# test_unauthorized_access PASSED
```

### Step 2: Load Testing

```bash
# Install k6
curl https://github.com/grafana/k6/releases/download/v0.47.0/k6-v0.47.0-linux-amd64.tar.gz -L | tar xvz
sudo mv k6-v0.47.0-linux-amd64/k6 /usr/local/bin/

# Run load test
k6 run load_test.js

# Target metrics:
# - Throughput: 1000 req/min
# - p95 latency: < 500ms
# - Error rate: < 1%
```

### Step 3: Security Validation

```bash
# Check TLS configuration
nmap --script ssl-enum-ciphers -p 443 api.yourcompany.com

# Verify JWT validation
curl -H "Authorization: Bearer INVALID_TOKEN" \
  https://api.yourcompany.com/mcp/v1/messages

# Expected: 401 Unauthorized

# Test DLP
# (Manual test with sensitive data patterns)

# Verify audit logs
aws logs tail /ecs/mcp-server --since 1h --region us-east-1
```

---

## Phase 6: IDE Client Configuration (Day 4)

### Step 1: Configure VS Code

Create `.vscode/settings.json` in project:

```json
{
  "mcp.servers": {
    "codebase-context": {
      "url": "https://api.yourcompany.com/mcp",
      "auth": {
        "type": "oauth2",
        "provider": "ping",
        "clientId": "mcp-vscode-client",
        "scopes": ["mcp:read", "mcp:query"],
        "authorizationUrl": "https://ping.yourcompany.com/oauth2/authorize",
        "tokenUrl": "https://ping.yourcompany.com/oauth2/token"
      },
      "tools": [
        "search_codebase",
        "get_file_context",
        "get_function_definition"
      ]
    }
  }
}
```

### Step 2: Test IDE Integration

1. Open VS Code
2. Trigger MCP tool (via GitHub Copilot or Claude extension)
3. Authenticate with Ping
4. Test search: "Find authentication middleware"
5. Verify results returned

### Step 3: Rollout to Team

```bash
# Create distribution package
mkdir mcp-client-config
cp .vscode/settings.json mcp-client-config/
cp docs/user-guide.md mcp-client-config/

# Share via Confluence/Wiki
# Or distribute via MDM for automated installation
```

---

## Phase 7: Monitoring & Alerting (Day 5)

### Step 1: Configure CloudWatch Dashboards

```bash
# Create dashboard from JSON
aws cloudwatch put-dashboard \
  --dashboard-name MCP-Production \
  --dashboard-body file://monitoring/cloudwatch-dashboard.json \
  --region us-east-1
```

### Step 2: Set Up Alarms

```bash
# High error rate alarm
aws cloudwatch put-metric-alarm \
  --alarm-name mcp-high-error-rate \
  --alarm-description "MCP Server high 5XX error rate" \
  --metric-name HTTPCode_Target_5XX_Count \
  --namespace AWS/ApplicationELB \
  --statistic Sum \
  --period 300 \
  --threshold 10 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 2 \
  --alarm-actions arn:aws:sns:us-east-1:ACCOUNT:mcp-alerts

# Unauthorized access alarm
aws cloudwatch put-metric-alarm \
  --alarm-name mcp-unauthorized-access \
  --metric-name UnauthorizedAccessCount \
  --namespace MCP/Security \
  --statistic Sum \
  --period 300 \
  --threshold 5 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 1 \
  --alarm-actions arn:aws:sns:us-east-1:ACCOUNT:security-alerts
```

### Step 3: Configure SNS Topics

```bash
# Create SNS topic
aws sns create-topic --name mcp-alerts --region us-east-1

# Subscribe email
aws sns subscribe \
  --topic-arn arn:aws:sns:us-east-1:ACCOUNT:mcp-alerts \
  --protocol email \
  --notification-endpoint platform-team@yourcompany.com

# Confirm subscription (check email)
```

---

## Phase 8: Documentation & Handoff (Day 5)

### Deliverables

1. **Architecture Documentation** ✓
   - System architecture diagram
   - Data flow diagrams
   - Security controls matrix

2. **Operational Runbooks** ✓
   - Deployment procedures
   - Troubleshooting guide
   - DR procedures

3. **User Documentation**
   - IDE setup guide
   - MCP usage examples
   - FAQ

4. **Compliance Documentation**
   - SOC2 controls mapping
   - HIPAA compliance checklist
   - Audit log retention policy

---

## Post-Deployment Tasks

### Week 1

- [ ] Monitor error rates and performance
- [ ] Gather user feedback
- [ ] Adjust auto-scaling thresholds
- [ ] Fine-tune ABAC policies

### Week 2-4

- [ ] Conduct DR drill
- [ ] Review and optimize costs
- [ ] Expand to additional teams
- [ ] Index additional repositories

### Monthly

- [ ] Generate compliance reports
- [ ] Review access logs
- [ ] Update ABAC policies
- [ ] Patch and update dependencies

---

## Troubleshooting Guide

### Issue: ECS Tasks Failing to Start

**Symptoms:**
```
STOPPED (CannotPullContainerError)
```

**Resolution:**
```bash
# Check ECR permissions
aws ecr get-login-password --region us-east-1

# Verify task execution role has ECR access
aws iam get-role-policy \
  --role-name mcpEcsTaskExecutionRole \
  --policy-name mcp-ecs-execution-custom

# Check image exists
aws ecr describe-images \
  --repository-name mcp-server \
  --region us-east-1
```

### Issue: High 5XX Error Rate

**Symptoms:**
```
ALB returning 502/503 errors
```

**Resolution:**
```bash
# Check task health
aws ecs describe-services \
  --cluster mcp-cluster \
  --services mcp-server

# Check target group health
aws elbv2 describe-target-health \
  --target-group-arn <TG_ARN>

# Review application logs
aws logs tail /ecs/mcp-server --follow

# Common causes:
# - Redis connection timeout
# - S3 access denied
# - Memory/CPU saturation
```

### Issue: Authentication Failures

**Symptoms:**
```
401 Unauthorized from APIGEE
```

**Resolution:**
```bash
# Verify JWT is valid
# Use jwt.io to decode token

# Check Ping JWKS endpoint
curl https://ping.yourcompany.com/.well-known/jwks.json

# Verify APIGEE policy configuration
# Check VerifyJWT policy has correct issuer/audience

# Review APIGEE logs for specific error
```

### Issue: DLP False Positives

**Symptoms:**
```
Legitimate code being blocked by DLP
```

**Resolution:**
```python
# Review DLP patterns
# Adjust regex in dlp_scanner.py

# Add exclusions for common patterns
# e.g., test API keys, sample data

# Redeploy with updated patterns
```

---

## Rollback Procedures

### Emergency Rollback

```bash
# Revert to previous task definition
PREVIOUS_TASK_DEF=$(aws ecs describe-services \
  --cluster mcp-cluster \
  --services mcp-server \
  --query 'services[0].deployments[1].taskDefinition' \
  --output text)

aws ecs update-service \
  --cluster mcp-cluster \
  --service mcp-server \
  --task-definition $PREVIOUS_TASK_DEF

# Verify rollback
aws ecs describe-services \
  --cluster mcp-cluster \
  --services mcp-server
```

### Infrastructure Rollback

```bash
# Destroy specific resources
terraform destroy -target=aws_ecs_service.mcp_server

# Or complete rollback
terraform destroy
```

---

## Success Criteria

✅ **Technical:**
- [ ] All health checks passing
- [ ] p95 latency < 500ms
- [ ] Error rate < 1%
- [ ] Auto-scaling working correctly

✅ **Security:**
- [ ] All auth flows validated
- [ ] DLP policies tested
- [ ] Audit logs flowing to CloudWatch
- [ ] No public access to resources

✅ **Compliance:**
- [ ] SOC2 controls documented
- [ ] HIPAA checklist complete
- [ ] Data encryption verified (at rest & transit)
- [ ] 90-day log retention configured

✅ **Operational:**
- [ ] Monitoring dashboards created
- [ ] Alerts configured and tested
- [ ] Runbooks documented
- [ ] Team trained on operations

---

## Support Contacts

**Platform Team:** platform-team@yourcompany.com  
**Security Team:** security@yourcompany.com  
**On-Call:** PagerDuty rotation  

**Escalation Path:**
1. Platform Team (L1)
2. Senior SRE (L2)
3. Engineering Leadership (L3)
