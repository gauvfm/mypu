# Cybersecurity Architect's Guide to MCP Deployment
## Guardrails, Controls, and Security Implementation Checklist

**Document Purpose:** This guide provides cybersecurity architects with a comprehensive checklist of security guardrails, controls, and implementation guidance for deploying Model Context Protocol (MCP) in an enterprise environment.

**Target Audience:** Cybersecurity Architects, Security Engineers, Security Operations

---

## Table of Contents

1. [Executive Overview for Security Architects](#1-executive-overview)
2. [Critical Security Guardrails](#2-critical-security-guardrails)
3. [Identity & Access Management](#3-identity--access-management)
4. [Network Security](#4-network-security)
5. [Data Protection](#5-data-protection)
6. [Application Security](#6-application-security)
7. [Monitoring & Detection](#7-monitoring--detection)
8. [Incident Response](#8-incident-response)
9. [Compliance Controls](#9-compliance-controls)
10. [Security Testing](#10-security-testing)
11. [Deployment Checklist](#11-deployment-checklist)

---

## 1. Executive Overview for Security Architects

### 1.1 What is MCP and Why Does It Matter for Security?

**Model Context Protocol (MCP)** enables AI-powered IDEs (GitHub Copilot, VS Code with Claude) to access enterprise codebase context. From a security perspective, this creates:

**🎯 Key Security Concerns:**
- Source code is now accessible via API (not just git clone)
- AI agents can query code patterns at scale
- User access must be enforced at API level, not just repository level
- New attack surface: API endpoints exposing sensitive code
- Data exfiltration risk through automated queries

**🔐 Your Mission:**
Implement security controls that:
1. Authenticate every user (MFA required)
2. Authorize every request (ABAC policies)
3. Protect data in transit and at rest (TLS 1.3 + KMS)
4. Detect and prevent data exfiltration (DLP + rate limiting)
5. Log everything for compliance and forensics

### 1.2 Security Architecture Overview

```
Defense-in-Depth Strategy (5 Layers):

Layer 1: IDENTITY
├─ Ping Identity (OAuth2 + MFA)
├─ JWT tokens (1-hour lifetime)
└─ Refresh token rotation

Layer 2: GATEWAY
├─ APIGEE API Gateway
├─ JWT validation
├─ Rate limiting
├─ DLP scanning
└─ WAF protection

Layer 3: APPLICATION
├─ MCP Server (ECS Fargate)
├─ ABAC authorization
├─ Scope validation
└─ Input validation

Layer 4: DATA
├─ S3 (KMS encryption)
├─ Redis (encrypted)
├─ Private subnets
└─ VPC endpoints

Layer 5: MONITORING
├─ CloudWatch (real-time)
├─ GuardDuty (anomaly detection)
├─ Audit logs (compliance)
└─ SIEM integration
```

### 1.3 Your Key Focus Areas

As a cybersecurity architect, focus on these 8 areas:

| Focus Area | Why It Matters | Risk Level |
|------------|----------------|------------|
| **Authentication** | Prevents unauthorized access to code | CRITICAL |
| **Authorization** | Enforces who can see what repos | CRITICAL |
| **Encryption** | Protects code in transit and at rest | CRITICAL |
| **DLP** | Prevents accidental data leaks | HIGH |
| **Rate Limiting** | Prevents bulk exfiltration | HIGH |
| **Audit Logging** | Compliance and forensics | CRITICAL |
| **Network Segmentation** | Limits lateral movement | HIGH |
| **Monitoring** | Detects attacks in progress | HIGH |

---

## 2. Critical Security Guardrails

### 2.1 The "Must Have" Guardrails (Non-Negotiable)

These controls MUST be in place before production deployment. No exceptions.

#### ✅ Guardrail 1: Multi-Factor Authentication (MFA)

**What:** Every user must authenticate with MFA via Ping Identity.

**Why:** Prevents account compromise from stolen passwords.

**How to Implement:**

1. **Ping Configuration:**
```json
{
  "authentication_policy": {
    "require_mfa": true,
    "allowed_mfa_methods": ["authenticator", "sms", "hardware_token"],
    "mfa_bypass_allowed": false,
    "session_lifetime": 43200,  // 12 hours max
    "idle_timeout": 14400        // 4 hours
  }
}
```

2. **Verification:**
```bash
# Test MFA enforcement
curl -X POST https://ping.yourcompany.com/oauth2/authorize \
  -d "client_id=mcp-ide-client" \
  -d "response_type=code" \
  -d "redirect_uri=http://localhost:8080/callback"

# Expected: User prompted for MFA
# JWT should contain: "acr": "mfa" claim
```

3. **Monitoring:**
```python
# Alert on MFA bypass attempts
if jwt_claims.get("acr") != "mfa":
    alert("MFA_BYPASS_ATTEMPT", user=jwt_claims["email"])
```

**Acceptance Criteria:**
- [ ] MFA cannot be disabled by users
- [ ] All authentication attempts logged
- [ ] JWT contains MFA indicator (`acr` claim)
- [ ] Failed MFA attempts trigger alert after 3 tries

---

#### ✅ Guardrail 2: OAuth2 Authorization Code + PKCE

**What:** IDEs must use OAuth2 with PKCE (no password grant, no implicit flow).

**Why:** Protects against authorization code interception attacks.

**How to Implement:**

1. **Ping Client Setup:**
```json
{
  "client_id": "mcp-ide-client",
  "client_name": "MCP IDE Client",
  "application_type": "native",
  "grant_types": ["authorization_code", "refresh_token"],
  "response_types": ["code"],
  "redirect_uris": [
    "http://localhost:8080/callback",
    "http://localhost:8081/callback",
    "vscode://anthropic.mcp/callback"
  ],
  "require_pkce": true,
  "pkce_challenge_method": "S256",
  "token_endpoint_auth_method": "none"
}
```

2. **Validation Policy (APIGEE):**
```xml
<!-- Verify PKCE was used -->
<AssignMessage name="Verify-PKCE">
  <AssignVariable>
    <Name>pkce_used</Name>
    <Ref>request.header.x-pkce-used</Ref>
  </AssignVariable>
</AssignMessage>

<RaiseFault name="Missing-PKCE">
  <Condition>pkce_used != "true"</Condition>
  <FaultResponse>
    <Set>
      <StatusCode>400</StatusCode>
      <ReasonPhrase>PKCE Required</ReasonPhrase>
    </Set>
  </FaultResponse>
</RaiseFault>
```

**Acceptance Criteria:**
- [ ] PKCE mandatory for all OAuth2 flows
- [ ] Authorization code expires in 60 seconds
- [ ] Implicit flow and password grant disabled
- [ ] Token endpoint requires code_verifier

---

#### ✅ Guardrail 3: ABAC Authorization

**What:** Attribute-Based Access Control (ABAC) for fine-grained permissions.

**Why:** Users should only access repos they're authorized for.

**How to Implement:**

1. **Define ABAC Policies:**
```python
# /mcp-server/config/abac_policies.json
{
  "policies": [
    {
      "id": "engineering-read-access",
      "effect": "allow",
      "principal": {
        "groups": ["Engineering", "Team-Platform"]
      },
      "action": ["read", "query", "search"],
      "resource": "repo:*",
      "condition": {
        "repo_in_user_access": true
      }
    },
    {
      "id": "contractor-limited",
      "effect": "allow",
      "principal": {
        "groups": ["Contractors"]
      },
      "action": ["read"],
      "resource": "repo:public-*",
      "condition": {
        "time_of_day": "business_hours"
      }
    },
    {
      "id": "deny-sensitive",
      "effect": "deny",
      "principal": {
        "groups": ["*"]
      },
      "action": ["*"],
      "resource": "repo:*-sensitive"
    }
  ]
}
```

2. **Implement ABAC Engine:**
```python
class ABACEngine:
    def authorize(self, user_context: dict, resource: str, action: str) -> bool:
        """Evaluate all policies, deny by default"""
        
        # Get applicable policies
        policies = self._get_policies(user_context, resource, action)
        
        # Evaluate deny policies first (explicit deny wins)
        for policy in policies:
            if policy["effect"] == "deny":
                if self._evaluate_policy(policy, user_context, resource, action):
                    self._log_authorization(user_context, resource, action, "DENY", policy["id"])
                    return False
        
        # Evaluate allow policies
        for policy in policies:
            if policy["effect"] == "allow":
                if self._evaluate_policy(policy, user_context, resource, action):
                    self._log_authorization(user_context, resource, action, "ALLOW", policy["id"])
                    return True
        
        # Default deny
        self._log_authorization(user_context, resource, action, "DENY", "default")
        return False
```

3. **Test ABAC Policies:**
```python
# pytest tests/test_abac.py
def test_engineering_can_access_owned_repos():
    user = {
        "email": "john@company.com",
        "groups": ["Engineering"],
        "repo_access": ["backend-service", "api-gateway"]
    }
    
    assert abac.authorize(user, "repo:backend-service", "read") == True
    assert abac.authorize(user, "repo:frontend-app", "read") == False

def test_contractor_limited_access():
    user = {
        "email": "contractor@company.com",
        "groups": ["Contractors"],
        "repo_access": ["public-docs"]
    }
    
    assert abac.authorize(user, "repo:public-docs", "read") == True
    assert abac.authorize(user, "repo:backend-service", "read") == False
```

**Acceptance Criteria:**
- [ ] ABAC policies enforce least privilege
- [ ] Default deny (explicit allow required)
- [ ] All authorization decisions logged
- [ ] Policies tested with unit tests (>90% coverage)

---

#### ✅ Guardrail 4: TLS 1.3 Only (No Fallback)

**What:** All network traffic encrypted with TLS 1.3 minimum.

**Why:** Protects against MITM attacks and protocol downgrade attacks.

**How to Implement:**

1. **ALB Configuration:**
```hcl
resource "aws_lb_listener" "mcp_server" {
  load_balancer_arn = aws_lb.mcp_server.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"  # TLS 1.3 only
  certificate_arn   = aws_acm_certificate.mcp_server.arn

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.mcp_server.arn
  }
}
```

2. **Verify TLS Configuration:**
```bash
# Test TLS version enforcement
nmap --script ssl-enum-ciphers -p 443 api.yourcompany.com

# Expected output:
# TLS 1.3 supported: YES
# TLS 1.2 supported: NO
# TLS 1.1 supported: NO
# TLS 1.0 supported: NO

# Test cipher suites
testssl.sh --protocols --ciphers api.yourcompany.com

# Expected: Only strong ciphers (AES-GCM, ChaCha20)
```

3. **mTLS for APIGEE → MCP:**
```xml
<!-- APIGEE TargetEndpoint -->
<TargetEndpoint name="MCP-Server">
  <HTTPTargetConnection>
    <SSLInfo>
      <Enabled>true</Enabled>
      <ClientAuthEnabled>true</ClientAuthEnabled>
      <KeyStore>apigee-client-keystore</KeyStore>
      <KeyAlias>apigee-client-cert</KeyAlias>
      <TrustStore>mcp-server-truststore</TrustStore>
      <Ciphers>
        <Cipher>TLS_AES_256_GCM_SHA384</Cipher>
        <Cipher>TLS_AES_128_GCM_SHA256</Cipher>
      </Ciphers>
      <Protocols>
        <Protocol>TLSv1.3</Protocol>
      </Protocols>
    </SSLInfo>
    <URL>https://mcp-alb-internal.yourcompany.com</URL>
  </HTTPTargetConnection>
</TargetEndpoint>
```

**Acceptance Criteria:**
- [ ] TLS 1.3 enforced (no TLS 1.2 fallback)
- [ ] mTLS for APIGEE ↔ MCP communication
- [ ] Certificate validation enforced
- [ ] Certificate expiration monitoring enabled

---

#### ✅ Guardrail 5: Encryption at Rest (KMS)

**What:** All data encrypted at rest using AWS KMS with automatic key rotation.

**Why:** Protects data if storage is compromised.

**How to Implement:**

1. **KMS Key Configuration:**
```hcl
resource "aws_kms_key" "codebase" {
  description             = "KMS key for MCP codebase encryption"
  deletion_window_in_days = 30
  enable_key_rotation     = true  # Automatic annual rotation

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "Enable IAM User Permissions"
        Effect = "Allow"
        Principal = {
          AWS = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:root"
        }
        Action   = "kms:*"
        Resource = "*"
      },
      {
        Sid    = "Allow ECS tasks to decrypt"
        Effect = "Allow"
        Principal = {
          AWS = aws_iam_role.mcp_server_task.arn
        }
        Action = [
          "kms:Decrypt",
          "kms:DescribeKey",
          "kms:GenerateDataKey"
        ]
        Resource = "*"
      }
    ]
  })

  tags = {
    Name           = "mcp-codebase-kms"
    DataClass      = "CONFIDENTIAL"
    Compliance     = "SOC2,HIPAA,PCI-DSS"
    AutoRotation   = "true"
  }
}
```

2. **S3 Encryption:**
```hcl
resource "aws_s3_bucket_server_side_encryption_configuration" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.codebase.arn
    }
    bucket_key_enabled = true  # Reduces KMS API calls
  }
}

# Deny unencrypted uploads
resource "aws_s3_bucket_policy" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "DenyUnencryptedObjectUploads"
        Effect = "Deny"
        Principal = "*"
        Action = "s3:PutObject"
        Resource = "${aws_s3_bucket.codebase.arn}/*"
        Condition = {
          StringNotEquals = {
            "s3:x-amz-server-side-encryption" = "aws:kms"
          }
        }
      }
    ]
  })
}
```

3. **ElastiCache Encryption:**
```hcl
resource "aws_elasticache_replication_group" "mcp_cache" {
  replication_group_id = "mcp-cache"
  
  at_rest_encryption_enabled = true
  kms_key_id                 = aws_kms_key.codebase.arn
  
  transit_encryption_enabled = true
  auth_token_enabled        = true  # Require password
  
  # ... other config
}
```

**Acceptance Criteria:**
- [ ] All S3 buckets encrypted with KMS
- [ ] All EBS volumes encrypted
- [ ] ElastiCache encrypted at rest and in transit
- [ ] CloudWatch Logs encrypted
- [ ] KMS key rotation enabled
- [ ] Unencrypted uploads blocked

---

#### ✅ Guardrail 6: Data Loss Prevention (DLP)

**What:** Scan all API responses for sensitive data (SSN, API keys, secrets).

**Why:** Prevents accidental exposure of credentials or PII.

**How to Implement:**

1. **DLP Scanner Implementation:**
```python
# /mcp-server/security/dlp_scanner.py
import re
from typing import Dict, List

class DLPScanner:
    PATTERNS = {
        'ssn': {
            'regex': r'\b\d{3}-\d{2}-\d{4}\b',
            'severity': 'CRITICAL',
            'action': 'REDACT'
        },
        'credit_card': {
            'regex': r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
            'severity': 'CRITICAL',
            'action': 'REDACT'
        },
        'aws_access_key': {
            'regex': r'\b(AKIA[0-9A-Z]{16})\b',
            'severity': 'CRITICAL',
            'action': 'BLOCK'
        },
        'private_key': {
            'regex': r'-----BEGIN (RSA |EC )?PRIVATE KEY-----',
            'severity': 'CRITICAL',
            'action': 'BLOCK'
        },
        'jwt_token': {
            'regex': r'eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',
            'severity': 'HIGH',
            'action': 'REDACT'
        },
        'api_key_generic': {
            'regex': r'\b[a-zA-Z0-9]{32,}\b',
            'severity': 'MEDIUM',
            'action': 'ALERT'
        },
        'password_keyword': {
            'regex': r'password[\s]*=[\s]*["\']([^"\']+)["\']',
            'severity': 'HIGH',
            'action': 'REDACT'
        }
    }
    
    def scan(self, content: str, user_context: dict) -> Dict:
        violations = []
        redacted_content = content
        
        for pattern_name, pattern_config in self.PATTERNS.items():
            matches = re.finditer(pattern_config['regex'], content)
            
            for match in matches:
                violation = {
                    'type': pattern_name,
                    'severity': pattern_config['severity'],
                    'action': pattern_config['action'],
                    'position': match.span(),
                    'hash': hashlib.sha256(match.group().encode()).hexdigest()[:16]
                }
                violations.append(violation)
                
                # Apply action
                if pattern_config['action'] == 'BLOCK':
                    raise DLPViolationError(
                        f"BLOCKED: {pattern_name} detected",
                        violations=violations
                    )
                elif pattern_config['action'] == 'REDACT':
                    redacted_content = redacted_content.replace(
                        match.group(),
                        '[REDACTED]'
                    )
        
        # Log all violations
        if violations:
            self._log_violation(violations, user_context)
        
        return {
            'violations': violations,
            'content': redacted_content,
            'blocked': any(v['action'] == 'BLOCK' for v in violations)
        }
    
    def _log_violation(self, violations: List[Dict], user_context: dict):
        for violation in violations:
            logger.warning(
                "DLP_VIOLATION",
                extra={
                    'user': user_context.get('email'),
                    'type': violation['type'],
                    'severity': violation['severity'],
                    'action': violation['action'],
                    'hash': violation['hash']
                }
            )

# Usage in MCP server
dlp_scanner = DLPScanner()

@app.post("/mcp/v1/messages")
async def mcp_endpoint(request: dict, user_context: dict = Depends(verify_token)):
    # Execute MCP tool
    response = await mcp_server.handle_request(request, user_context)
    
    # DLP scan before returning
    dlp_result = dlp_scanner.scan(json.dumps(response), user_context)
    
    if dlp_result['blocked']:
        raise HTTPException(
            status_code=451,
            detail="Response blocked due to sensitive data detection"
        )
    
    # Return redacted content
    return json.loads(dlp_result['content'])
```

2. **APIGEE DLP Policy:**
```xml
<!-- Response DLP Scanning -->
<Javascript name="DLP-Scan-Response">
  <ResourceURL>jsc://dlp-scanner.js</ResourceURL>
</Javascript>

<!-- dlp-scanner.js -->
<![CDATA[
var response = context.getVariable("response.content");
var patterns = {
    ssn: /\b\d{3}-\d{2}-\d{4}\b/g,
    creditCard: /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g,
    awsKey: /\b(AKIA[0-9A-Z]{16})\b/g
};

var violations = [];
for (var pattern in patterns) {
    var matches = response.match(patterns[pattern]);
    if (matches) {
        violations.push({
            type: pattern,
            count: matches.length
        });
        // Redact
        response = response.replace(patterns[pattern], '[REDACTED]');
    }
}

if (violations.length > 0) {
    // Log violation
    context.setVariable("dlp.violations", JSON.stringify(violations));
    context.setVariable("dlp.detected", true);
    
    // Set redacted response
    context.setVariable("response.content", response);
}
]]>
```

3. **CloudWatch Alert:**
```python
# Alert on DLP violations
if dlp_result['violations']:
    cloudwatch.put_metric_data(
        Namespace='MCP/Security',
        MetricData=[{
            'MetricName': 'DLPViolations',
            'Value': len(dlp_result['violations']),
            'Unit': 'Count',
            'Dimensions': [
                {'Name': 'User', 'Value': user_context['email']},
                {'Name': 'Severity', 'Value': dlp_result['violations'][0]['severity']}
            ]
        }]
    )
```

**Acceptance Criteria:**
- [ ] DLP patterns cover SSN, credit cards, API keys, private keys
- [ ] Critical patterns BLOCK the response
- [ ] High patterns REDACT the content
- [ ] All violations logged to CloudWatch
- [ ] False positive rate < 5%

---

#### ✅ Guardrail 7: Rate Limiting

**What:** Limit API requests per user to prevent bulk data exfiltration.

**Why:** Prevents malicious users from scraping entire codebase.

**How to Implement:**

1. **APIGEE Rate Limiting:**
```xml
<!-- Per-User Rate Limit -->
<Quota name="User-Rate-Limit">
  <Identifier ref="user.email"/>
  <Allow count="1000"/>
  <Interval>1</Interval>
  <TimeUnit>hour</TimeUnit>
  <Distributed>true</Distributed>
</Quota>

<!-- Per-IP Rate Limit (additional protection) -->
<Quota name="IP-Rate-Limit">
  <Identifier ref="client.ip"/>
  <Allow count="5000"/>
  <Interval>1</Interval>
  <TimeUnit>hour</TimeUnit>
</Quota>

<!-- Burst Protection -->
<SpikeArrest name="Spike-Arrest">
  <Identifier ref="user.email"/>
  <Rate>100pm</Rate>  <!-- 100 per minute max -->
</SpikeArrest>

<!-- Handle rate limit exceeded -->
<RaiseFault name="Rate-Limit-Exceeded">
  <Condition>ratelimit.Quota.failed = true</Condition>
  <FaultResponse>
    <Set>
      <StatusCode>429</StatusCode>
      <ReasonPhrase>Too Many Requests</ReasonPhrase>
      <Payload contentType="application/json">
        {
          "error": "rate_limit_exceeded",
          "message": "You have exceeded your request quota",
          "retry_after": "{ratelimit.Quota.expiry.time}"
        }
      </Payload>
    </Set>
  </FaultResponse>
</RaiseFault>
```

2. **Application-Level Rate Limiting:**
```python
from redis import Redis
from datetime import datetime, timedelta

class RateLimiter:
    def __init__(self, redis_client: Redis):
        self.redis = redis_client
    
    def check_rate_limit(self, user_email: str, action: str) -> bool:
        """
        Sliding window rate limiter
        
        Limits:
        - search_codebase: 500/hour
        - get_file_context: 1000/hour
        - bulk_operations: 100/hour
        """
        limits = {
            'search_codebase': 500,
            'get_file_context': 1000,
            'bulk_operations': 100
        }
        
        key = f"ratelimit:{user_email}:{action}"
        limit = limits.get(action, 1000)
        window = 3600  # 1 hour
        
        # Sliding window algorithm
        now = datetime.utcnow().timestamp()
        window_start = now - window
        
        # Remove old entries
        self.redis.zremrangebyscore(key, 0, window_start)
        
        # Count requests in current window
        request_count = self.redis.zcard(key)
        
        if request_count >= limit:
            # Rate limit exceeded
            ttl = self.redis.ttl(key)
            raise RateLimitExceeded(
                f"Rate limit exceeded for {action}",
                retry_after=ttl
            )
        
        # Add current request
        self.redis.zadd(key, {now: now})
        self.redis.expire(key, window)
        
        return True

# Usage
rate_limiter = RateLimiter(redis_client)

@app.post("/mcp/v1/tools/search_codebase")
async def search_codebase(request: dict, user: dict = Depends(verify_token)):
    try:
        rate_limiter.check_rate_limit(user['email'], 'search_codebase')
    except RateLimitExceeded as e:
        raise HTTPException(
            status_code=429,
            detail=str(e),
            headers={"Retry-After": str(e.retry_after)}
        )
    
    # Process request
    return await execute_search(request, user)
```

3. **Anomaly Detection:**
```python
# Detect unusual request patterns
class AnomalyDetector:
    def detect_unusual_volume(self, user_email: str) -> bool:
        """Alert if user exceeds 3x their average"""
        
        # Get user's average requests per hour (last 30 days)
        avg_requests = self._get_user_average(user_email, days=30)
        
        # Get current hour's requests
        current_requests = self._get_current_requests(user_email)
        
        if current_requests > (avg_requests * 3):
            alert(
                "UNUSUAL_REQUEST_VOLUME",
                user=user_email,
                current=current_requests,
                average=avg_requests
            )
            return True
        
        return False
```

**Acceptance Criteria:**
- [ ] Per-user limit: 1000 requests/hour
- [ ] Per-IP limit: 5000 requests/hour
- [ ] Burst protection: 100 requests/minute max
- [ ] 429 response with Retry-After header
- [ ] Unusual volumes trigger alerts

---

#### ✅ Guardrail 8: Comprehensive Audit Logging

**What:** Log all security-relevant events with full context.

**Why:** Compliance, forensics, and incident response require complete audit trails.

**How to Implement:**

1. **Audit Logger Implementation:**
```python
# /mcp-server/security/audit_logger.py
import boto3
import json
from datetime import datetime
from typing import Dict, Any

class AuditLogger:
    def __init__(self):
        self.cloudwatch = boto3.client('logs')
        self.s3 = boto3.client('s3')
        self.dynamodb = boto3.resource('dynamodb')
        
        self.log_group = '/mcp/audit'
        self.s3_bucket = 'yourcompany-mcp-audit-logs'
        self.table = self.dynamodb.Table('mcp-audit-trail')
    
    async def log(self, event_type: str, user_context: dict, details: dict):
        """
        Log audit event to multiple destinations:
        1. CloudWatch Logs (real-time monitoring)
        2. S3 (long-term compliance retention)
        3. DynamoDB (queryable audit trail)
        """
        
        # Create audit event
        event = {
            'event_id': str(uuid.uuid4()),
            'timestamp': datetime.utcnow().isoformat(),
            'event_type': event_type,
            'user': {
                'email': user_context.get('email'),
                'groups': user_context.get('groups', []),
                'org_id': user_context.get('org_id'),
                'ip_address': details.get('client_ip'),
                'user_agent': details.get('user_agent')
            },
            'action': details.get('action'),
            'resource': details.get('resource'),
            'result': details.get('result', 'success'),
            'error_message': details.get('error_message'),
            'request_id': details.get('request_id'),
            'duration_ms': details.get('duration_ms'),
            'metadata': details.get('metadata', {})
        }
        
        # Log to CloudWatch
        await self._log_to_cloudwatch(event)
        
        # Log to S3 (compliance)
        await self._log_to_s3(event)
        
        # Log to DynamoDB (queryable)
        await self._log_to_dynamodb(event)
    
    async def _log_to_cloudwatch(self, event: dict):
        """Real-time logging for monitoring"""
        log_stream = f"{event['user']['email']}/{datetime.utcnow().strftime('%Y-%m-%d')}"
        
        try:
            self.cloudwatch.put_log_events(
                logGroupName=self.log_group,
                logStreamName=log_stream,
                logEvents=[{
                    'timestamp': int(datetime.utcnow().timestamp() * 1000),
                    'message': json.dumps(event)
                }]
            )
        except self.cloudwatch.exceptions.ResourceNotFoundException:
            # Create log stream if doesn't exist
            self.cloudwatch.create_log_stream(
                logGroupName=self.log_group,
                logStreamName=log_stream
            )
            # Retry
            await self._log_to_cloudwatch(event)
    
    async def _log_to_s3(self, event: dict):
        """Long-term storage for compliance (7 years)"""
        date = datetime.utcnow()
        key = f"audit/{date.year}/{date.month:02d}/{date.day:02d}/{event['user']['email']}/{event['event_id']}.json"
        
        self.s3.put_object(
            Bucket=self.s3_bucket,
            Key=key,
            Body=json.dumps(event, indent=2),
            ServerSideEncryption='aws:kms',
            SSEKMSKeyId='alias/audit-logs-kms-key',
            ContentType='application/json',
            Metadata={
                'event-type': event['event_type'],
                'user-email': event['user']['email']
            }
        )
    
    async def _log_to_dynamodb(self, event: dict):
        """Queryable audit trail"""
        self.table.put_item(Item={
            'event_id': event['event_id'],
            'timestamp': event['timestamp'],
            'user_email': event['user']['email'],
            'event_type': event['event_type'],
            'action': event['action'],
            'resource': event['resource'],
            'result': event['result'],
            'full_event': json.dumps(event)
        })

# Usage throughout application
audit_logger = AuditLogger()

# Authentication events
await audit_logger.log('authentication', user_context, {
    'action': 'login',
    'result': 'success',
    'client_ip': request.client.host,
    'user_agent': request.headers.get('user-agent')
})

# Authorization events
await audit_logger.log('authorization', user_context, {
    'action': 'access_repo',
    'resource': f'repo:{repo_name}',
    'result': 'allowed' if authorized else 'denied',
    'policy_id': policy_id
})

# Data access events
await audit_logger.log('data_access', user_context, {
    'action': 'search_codebase',
    'resource': f'repo:{repo_name}',
    'result': 'success',
    'results_count': len(results),
    'duration_ms': duration
})

# Security events
await audit_logger.log('security_event', user_context, {
    'action': 'dlp_violation',
    'resource': 'response_content',
    'result': 'blocked',
    'violation_type': 'aws_api_key',
    'severity': 'critical'
})
```

2. **CloudWatch Metric Filters:**
```hcl
# Alert on security events
resource "aws_cloudwatch_log_metric_filter" "unauthorized_access" {
  name           = "UnauthorizedAccessAttempts"
  log_group_name = "/mcp/audit"
  pattern        = "[time, request_id, event_type=authorization, result=denied]"

  metric_transformation {
    name      = "UnauthorizedAccessCount"
    namespace = "MCP/Security"
    value     = "1"
  }
}

resource "aws_cloudwatch_metric_alarm" "unauthorized_access" {
  alarm_name          = "mcp-unauthorized-access-spike"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = "1"
  metric_name         = "UnauthorizedAccessCount"
  namespace           = "MCP/Security"
  period              = "300"
  statistic           = "Sum"
  threshold           = "5"
  alarm_description   = "Multiple unauthorized access attempts"
  alarm_actions       = [aws_sns_topic.security_alerts.arn]
}
```

**Acceptance Criteria:**
- [ ] All authentication events logged
- [ ] All authorization decisions logged
- [ ] All data access events logged
- [ ] All DLP violations logged
- [ ] Logs include: timestamp, user, action, resource, result
- [ ] CloudWatch retention: 90 days
- [ ] S3 retention: 7 years
- [ ] Logs protected from tampering (S3 Object Lock)

---

## 3. Identity & Access Management

### 3.1 AD Group to OAuth Scope Mapping

**Configuration in Ping Identity:**

```javascript
// Ping Policy Script
var adGroups = user.getAttribute("memberOf");
var scopes = ["openid", "profile", "email"];  // Base scopes
var customClaims = {};

// Map AD groups to MCP scopes
if (adGroups.contains("CN=Engineering,OU=Groups,DC=corp")) {
    scopes.push("mcp:read");
    scopes.push("mcp:query");
    scopes.push("mcp:search");
}

if (adGroups.contains("CN=Team-Platform,OU=Groups,DC=corp")) {
    scopes.push("mcp:write");
    scopes.push("mcp:admin");
    customClaims.org_id = "platform";
    customClaims.team = "platform";
}

if (adGroups.contains("CN=MCP-Admin,OU=Groups,DC=corp")) {
    scopes.push("mcp:admin");
    scopes.push("mcp:policy:write");
}

// Add repo access from AD extensionAttribute
var repoAccess = user.getAttribute("extensionAttribute1");
if (repoAccess) {
    customClaims.repo_access = repoAccess.split(",");
}

// Set scopes and claims
token.setScopes(scopes);
token.setClaim("groups", adGroups);
token.setClaim("org_id", customClaims.org_id);
token.setClaim("team", customClaims.team);
token.setClaim("repo_access", customClaims.repo_access);
```

### 3.2 JWT Claims to Verify

**Mandatory JWT claims for security:**

```python
REQUIRED_JWT_CLAIMS = {
    'iss': 'https://ping.yourcompany.com',  # Issuer
    'aud': 'mcp-codebase-api',               # Audience
    'sub': str,                               # Subject (user ID)
    'email': str,                             # User email
    'exp': int,                               # Expiration
    'iat': int,                               # Issued at
    'groups': list,                           # AD groups
    'scope': str,                             # OAuth scopes
    'acr': 'mfa'                             # MFA indicator
}

def validate_jwt_claims(jwt_payload: dict) -> bool:
    """Validate all required claims are present"""
    
    for claim, expected_type in REQUIRED_JWT_CLAIMS.items():
        if claim not in jwt_payload:
            raise ValueError(f"Missing required claim: {claim}")
        
        if expected_type != str and not isinstance(jwt_payload[claim], expected_type):
            raise ValueError(f"Invalid type for claim {claim}")
    
    # Validate issuer
    if jwt_payload['iss'] != 'https://ping.yourcompany.com':
        raise ValueError("Invalid issuer")
    
    # Validate audience
    if jwt_payload['aud'] != 'mcp-codebase-api':
        raise ValueError("Invalid audience")
    
    # Validate MFA
    if jwt_payload.get('acr') != 'mfa':
        raise ValueError("MFA required but not present")
    
    # Validate expiration
    if jwt_payload['exp'] < datetime.utcnow().timestamp():
        raise ValueError("Token expired")
    
    return True
```

---

## 4. Network Security

### 4.1 Security Group Configuration

```hcl
# MCP Server Security Group (ECS Fargate)
resource "aws_security_group" "mcp_server" {
  name        = "mcp-server-sg"
  description = "Security group for MCP servers"
  vpc_id      = aws_vpc.main.id

  # Ingress: Only from ALB
  ingress {
    description     = "HTTPS from ALB only"
    from_port       = 8443
    to_port         = 8443
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]
  }

  # Egress: Deny all by default, allow specific
  
  # Allow S3 via VPC endpoint
  egress {
    description     = "To S3 VPC Endpoint"
    from_port       = 443
    to_port         = 443
    protocol        = "tcp"
    prefix_list_ids = [aws_vpc_endpoint.s3.prefix_list_id]
  }

  # Allow Redis
  egress {
    description     = "To ElastiCache Redis"
    from_port       = 6379
    to_port         = 6379
    protocol        = "tcp"
    security_groups = [aws_security_group.elasticache.id]
  }

  # Allow Secrets Manager
  egress {
    description     = "To Secrets Manager VPC Endpoint"
    from_port       = 443
    to_port         = 443
    protocol        = "tcp"
    security_groups = [aws_security_group.vpc_endpoints.id]
  }

  # Allow CloudWatch Logs
  egress {
    description     = "To CloudWatch Logs VPC Endpoint"
    from_port       = 443
    to_port         = 443
    protocol        = "tcp"
    security_groups = [aws_security_group.vpc_endpoints.id]
  }

  # Allow AI Gateway (Portkey) - HTTPS only
  egress {
    description = "To AI Gateway"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [var.ai_gateway_cidr]
  }

  tags = {
    Name = "mcp-server-sg"
  }
}
```

### 4.2 Network ACLs (Additional Layer)

```hcl
resource "aws_network_acl" "private_app" {
  vpc_id     = aws_vpc.main.id
  subnet_ids = [
    aws_subnet.private_app_az1.id,
    aws_subnet.private_app_az2.id
  ]

  # Inbound: Allow from DMZ (APIGEE) only
  ingress {
    protocol   = "tcp"
    rule_no    = 100
    action     = "allow"
    cidr_block = "10.0.10.0/23"  # DMZ subnets
    from_port  = 8443
    to_port    = 8443
  }

  # Deny all other inbound
  ingress {
    protocol   = "-1"
    rule_no    = 999
    action     = "deny"
    cidr_block = "0.0.0.0/0"
    from_port  = 0
    to_port    = 0
  }

  # Outbound: Allow specific destinations
  egress {
    protocol   = "tcp"
    rule_no    = 100
    action     = "allow"
    cidr_block = "10.0.30.0/23"  # Data subnets
    from_port  = 443
    to_port    = 443
  }

  egress {
    protocol   = "tcp"
    rule_no    = 110
    action     = "allow"
    cidr_block = "10.0.30.0/23"  # Data subnets
    from_port  = 6379
    to_port    = 6379
  }

  tags = {
    Name = "mcp-private-app-nacl"
  }
}
```

### 4.3 VPC Flow Logs Analysis

```python
# Analyze VPC Flow Logs for suspicious activity
class FlowLogAnalyzer:
    def detect_anomalies(self, flow_logs: List[dict]) -> List[dict]:
        anomalies = []
        
        for log in flow_logs:
            # Detect port scanning
            if self._is_port_scan(log):
                anomalies.append({
                    'type': 'port_scan',
                    'source_ip': log['srcaddr'],
                    'severity': 'HIGH'
                })
            
            # Detect data exfiltration (high volume outbound)
            if self._is_high_volume_outbound(log):
                anomalies.append({
                    'type': 'data_exfiltration',
                    'source_ip': log['srcaddr'],
                    'bytes': log['bytes'],
                    'severity': 'CRITICAL'
                })
            
            # Detect unauthorized access attempts
            if log['action'] == 'REJECT':
                anomalies.append({
                    'type': 'unauthorized_access',
                    'source_ip': log['srcaddr'],
                    'dest_port': log['dstport'],
                    'severity': 'MEDIUM'
                })
        
        return anomalies
```

---

## 5. Data Protection

### 5.1 S3 Bucket Security Hardening

```hcl
# Complete S3 security configuration
resource "aws_s3_bucket" "codebase" {
  bucket = "yourcompany-mcp-codebase"

  tags = {
    Name           = "MCP Codebase"
    Classification = "CONFIDENTIAL"
    Compliance     = "SOC2,HIPAA,PCI-DSS"
  }
}

# Block all public access
resource "aws_s3_bucket_public_access_block" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# Encryption
resource "aws_s3_bucket_server_side_encryption_configuration" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.codebase.arn
    }
    bucket_key_enabled = true
  }
}

# Versioning (for data recovery)
resource "aws_s3_bucket_versioning" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  versioning_configuration {
    status = "Enabled"
  }
}

# Object Lock (WORM - Write Once Read Many)
resource "aws_s3_bucket_object_lock_configuration" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  rule {
    default_retention {
      mode  = "GOVERNANCE"
      years = 1
    }
  }
}

# Lifecycle policy
resource "aws_s3_bucket_lifecycle_configuration" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  rule {
    id     = "archive-old-versions"
    status = "Enabled"

    noncurrent_version_transition {
      noncurrent_days = 90
      storage_class   = "GLACIER"
    }

    noncurrent_version_expiration {
      noncurrent_days = 365
    }
  }

  rule {
    id     = "delete-incomplete-multipart"
    status = "Enabled"

    abort_incomplete_multipart_upload {
      days_after_initiation = 7
    }
  }
}

# Bucket policy (defense in depth)
resource "aws_s3_bucket_policy" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "DenyUnencryptedObjectUploads"
        Effect = "Deny"
        Principal = "*"
        Action = "s3:PutObject"
        Resource = "${aws_s3_bucket.codebase.arn}/*"
        Condition = {
          StringNotEquals = {
            "s3:x-amz-server-side-encryption" = "aws:kms"
          }
        }
      },
      {
        Sid    = "DenyInsecureTransport"
        Effect = "Deny"
        Principal = "*"
        Action = "s3:*"
        Resource = [
          aws_s3_bucket.codebase.arn,
          "${aws_s3_bucket.codebase.arn}/*"
        ]
        Condition = {
          Bool = {
            "aws:SecureTransport" = "false"
          }
        }
      },
      {
        Sid    = "AllowMCPServerAccess"
        Effect = "Allow"
        Principal = {
          AWS = aws_iam_role.mcp_server_task.arn
        }
        Action = [
          "s3:GetObject",
          "s3:ListBucket"
        ]
        Resource = [
          aws_s3_bucket.codebase.arn,
          "${aws_s3_bucket.codebase.arn}/*"
        ]
      }
    ]
  })
}

# Logging
resource "aws_s3_bucket_logging" "codebase" {
  bucket = aws_s3_bucket.codebase.id

  target_bucket = aws_s3_bucket.logs.id
  target_prefix = "s3-access-logs/codebase/"
}
```

---

## 6. Application Security

### 6.1 Container Security

```dockerfile
# Secure Dockerfile for MCP Server
FROM python:3.11-slim

# Use non-root user
RUN groupadd -r mcp && useradd -r -g mcp mcp

# Install security updates
RUN apt-get update && \
    apt-get upgrade -y && \
    apt-get install -y --no-install-recommends \
        ca-certificates \
        && \
    rm -rf /var/lib/apt/lists/*

# Set working directory
WORKDIR /app

# Copy and install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY --chown=mcp:mcp . .

# Remove unnecessary files
RUN find . -name "*.pyc" -delete && \
    find . -name "__pycache__" -delete

# Switch to non-root user
USER mcp

# Read-only root filesystem (mount writable volumes as needed)
# Set security options in ECS task definition

# Health check
HEALTHCHECK --interval=30s --timeout=5s --start-period=5s --retries=3 \
    CMD python -c "import requests; requests.get('http://localhost:8443/health')"

EXPOSE 8443

CMD ["python", "-m", "uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8443"]
```

### 6.2 Dependency Scanning

```yaml
# .github/workflows/security-scan.yml
name: Security Scan

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]
  schedule:
    - cron: '0 0 * * *'  # Daily

jobs:
  dependency-scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Run Snyk
        uses: snyk/actions/python@master
        env:
          SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
        with:
          command: test
          args: --severity-threshold=high --fail-on=all
      
      - name: Run Safety
        run: |
          pip install safety
          safety check --json > safety-report.json
      
      - name: Upload results
        uses: github/codeql-action/upload-sarif@v2
        with:
          sarif_file: safety-report.json

  sast-scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Run Semgrep
        uses: returntocorp/semgrep-action@v1
        with:
          config: >-
            p/security-audit
            p/secrets
            p/owasp-top-ten
      
      - name: Run Bandit
        run: |
          pip install bandit
          bandit -r . -f json -o bandit-report.json
      
      - name: Fail on critical findings
        run: |
          CRITICAL=$(jq '.results | map(select(.issue_severity == "HIGH" or .issue_severity == "CRITICAL")) | length' bandit-report.json)
          if [ $CRITICAL -gt 0 ]; then
            echo "Found $CRITICAL critical/high severity findings"
            exit 1
          fi
```

---

## 7. Monitoring & Detection

### 7.1 CloudWatch Dashboard

```json
{
  "widgets": [
    {
      "type": "metric",
      "properties": {
        "metrics": [
          ["MCP/Security", "UnauthorizedAccessCount", {"stat": "Sum"}],
          [".", "DLPViolations", {"stat": "Sum"}],
          [".", "RateLimitExceeded", {"stat": "Sum"}],
          ["AWS/ApplicationELB", "HTTPCode_Target_5XX_Count", {"stat": "Sum"}]
        ],
        "period": 300,
        "stat": "Sum",
        "region": "us-east-1",
        "title": "Security Metrics",
        "yAxis": {
          "left": {
            "min": 0
          }
        }
      }
    },
    {
      "type": "log",
      "properties": {
        "query": "SOURCE '/mcp/audit'\n| fields @timestamp, event_type, user.email, action, result\n| filter result = 'denied'\n| sort @timestamp desc\n| limit 20",
        "region": "us-east-1",
        "title": "Recent Authorization Failures"
      }
    }
  ]
}
```

### 7.2 GuardDuty Integration

```hcl
resource "aws_guardduty_detector" "main" {
  enable = true

  datasources {
    s3_logs {
      enable = true
    }
    kubernetes {
      audit_logs {
        enable = false  # Not using EKS
      }
    }
    malware_protection {
      scan_ec2_instance_with_findings {
        ebs_volumes {
          enable = true
        }
      }
    }
  }
}

# Alert on GuardDuty findings
resource "aws_cloudwatch_event_rule" "guardduty_findings" {
  name        = "guardduty-findings"
  description = "Alert on GuardDuty findings"

  event_pattern = jsonencode({
    source      = ["aws.guardduty"]
    detail-type = ["GuardDuty Finding"]
    detail = {
      severity = [4, 4.0, 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9, 5, 5.0, 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8, 5.9, 6, 6.0, 6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 6.7, 6.8, 6.9, 7, 7.0, 7.1, 7.2, 7.3, 7.4, 7.5, 7.6, 7.7, 7.8, 7.9, 8, 8.0, 8.1, 8.2, 8.3, 8.4, 8.5, 8.6, 8.7, 8.8, 8.9]  # Medium to High
    }
  })
}

resource "aws_cloudwatch_event_target" "guardduty_sns" {
  rule      = aws_cloudwatch_event_rule.guardduty_findings.name
  target_id = "SendToSNS"
  arn       = aws_sns_topic.security_alerts.arn
}
```

---

## 8. Incident Response

### 8.1 Incident Response Playbook

**P1 Incident: Unauthorized Code Access Detected**

**Trigger:** Alert on multiple authorization failures + successful access

**Response Steps:**

1. **Immediate (0-5 minutes):**
```bash
# Revoke user's tokens
aws cognito-idp admin-user-global-sign-out \
  --user-pool-id us-east-1_xxxxx \
  --username compromised.user@company.com

# Disable user in AD
Disable-ADAccount -Identity "compromised.user"

# Block IP at WAF
aws wafv2 update-ip-set \
  --name blocked-ips \
  --id xxxxx \
  --addresses 1.2.3.4/32
```

2. **Investigation (5-30 minutes):**
```bash
# Pull all logs for user
aws logs filter-log-events \
  --log-group-name /mcp/audit \
  --filter-pattern '{ $.user.email = "compromised.user@company.com" }' \
  --start-time $(date -d '1 hour ago' +%s)000 \
  --end-time $(date +%s)000 \
  > incident-logs.json

# Check what repos were accessed
jq '.events[] | select(.event_type == "data_access") | .resource' incident-logs.json | sort | uniq

# Check GuardDuty findings
aws guardduty list-findings \
  --detector-id xxxxx \
  --finding-criteria '{"Criterion":{"resource.instanceDetails.networkInterfaces.privateIpAddress":{"Eq":["10.0.20.5"]}}}'
```

3. **Containment (30-60 minutes):**
- Rotate all API keys for affected repos
- Force password reset for user
- Review and update ABAC policies
- Notify affected team leads

4. **Remediation (1-24 hours):**
- Conduct forensic analysis
- Determine root cause
- Implement additional controls
- Update incident response playbook

5. **Post-Incident (24-48 hours):**
- Write post-mortem
- Update SIEM rules
- Security awareness training
- Implement preventive measures

---

## 9. Compliance Controls

### 9.1 SOC2 Control Mapping

| Control | Requirement | Implementation | Evidence |
|---------|-------------|----------------|----------|
| **CC6.1** | Logical access restricted to authorized users | Ping MFA + ABAC | Authentication logs, ABAC policies |
| **CC6.2** | Prior to issuing credentials, entity registers and authorizes new users | Onboarding process + AD provisioning | User creation logs, approval tickets |
| **CC6.3** | Entity authorizes, modifies, or removes access | ABAC policy management | Access review logs, policy changes |
| **CC6.6** | Entity implements logical access controls to protect against threats | WAF, DLP, rate limiting | Security logs, blocked requests |
| **CC6.7** | Entity restricts transmission/movement/removal of info | DLP scanning, encryption | DLP violation logs, encryption configs |
| **CC7.2** | Entity monitors system components | CloudWatch, GuardDuty | Monitoring dashboards, alerts |
| **CC8.1** | Entity authorizes, designs, develops, tests, approves, and implements changes | Change management process | Git commits, approvals, tests |

---

## 10. Security Testing

### 10.1 Pre-Deployment Security Tests

```bash
#!/bin/bash
# pre-deployment-security-tests.sh

echo "🔒 Running Security Tests..."

# 1. SAST
echo "1. Static Analysis..."
semgrep --config=auto --error .
if [ $? -ne 0 ]; then
    echo "❌ SAST failed"
    exit 1
fi

# 2. Dependency Scan
echo "2. Dependency Scan..."
snyk test --severity-threshold=high
if [ $? -ne 0 ]; then
    echo "❌ Dependency scan failed"
    exit 1
fi

# 3. Container Scan
echo "3. Container Scan..."
docker scan mcp-server:latest --severity high
if [ $? -ne 0 ]; then
    echo "❌ Container scan failed"
    exit 1
fi

# 4. Infrastructure Scan
echo "4. Infrastructure Scan..."
checkov -d terraform/ --framework terraform
if [ $? -ne 0 ]; then
    echo "❌ Infrastructure scan failed"
    exit 1
fi

# 5. Secrets Scan
echo "5. Secrets Scan..."
trufflehog git file://. --only-verified
if [ $? -ne 0 ]; then
    echo "❌ Secrets detected"
    exit 1
fi

# 6. Security Unit Tests
echo "6. Security Unit Tests..."
pytest tests/security/ -v
if [ $? -ne 0 ]; then
    echo "❌ Security tests failed"
    exit 1
fi

echo "✅ All security tests passed"
```

---

## 11. Deployment Checklist

### 11.1 Cybersecurity Architect's Pre-Production Checklist

**Print this and check off each item before approving production deployment:**

#### Identity & Access Management
- [ ] MFA enforced in Ping (no bypass)
- [ ] OAuth2 + PKCE mandatory
- [ ] JWT validation at APIGEE
- [ ] JWT validation at MCP server (defense in depth)
- [ ] Access token lifetime ≤ 1 hour
- [ ] Refresh token rotation enabled
- [ ] ABAC policies implemented and tested
- [ ] Least privilege enforced (default deny)
- [ ] All authorization decisions logged

#### Network Security
- [ ] Network segmentation (Public/DMZ/Private-App/Private-Data)
- [ ] Security groups configured (deny by default)
- [ ] Network ACLs configured
- [ ] IP allowlisting enabled on APIGEE
- [ ] VPC Flow Logs enabled
- [ ] VPC Endpoints for AWS services
- [ ] No direct internet access from private subnets
- [ ] WAF enabled with OWASP rules

#### Data Protection
- [ ] TLS 1.3 enforced (no TLS 1.2 fallback)
- [ ] mTLS between APIGEE and MCP
- [ ] All S3 buckets encrypted (KMS)
- [ ] All EBS volumes encrypted
- [ ] ElastiCache encrypted (at rest + in transit)
- [ ] CloudWatch Logs encrypted
- [ ] KMS key rotation enabled
- [ ] Unencrypted uploads blocked (S3 bucket policy)
- [ ] Secrets in AWS Secrets Manager (not in code)

#### DLP & Rate Limiting
- [ ] DLP patterns configured (SSN, credit cards, API keys)
- [ ] DLP scanning at APIGEE layer
- [ ] Critical patterns BLOCK responses
- [ ] Per-user rate limiting (1000/hour)
- [ ] Per-IP rate limiting (5000/hour)
- [ ] Burst protection (100/minute)
- [ ] Rate limit violations logged
- [ ] Anomaly detection for unusual volumes

#### Audit & Logging
- [ ] Audit logging to CloudWatch
- [ ] Audit logging to S3 (long-term)
- [ ] All authentication events logged
- [ ] All authorization events logged
- [ ] All data access events logged
- [ ] All DLP violations logged
- [ ] CloudWatch retention: 90 days
- [ ] S3 retention: 7 years
- [ ] Logs protected from tampering (Object Lock)
- [ ] Log analysis automated

#### Monitoring & Detection
- [ ] CloudWatch dashboard created
- [ ] Security metrics configured
- [ ] Alerts for unauthorized access
- [ ] Alerts for DLP violations
- [ ] Alerts for rate limit exceeded
- [ ] GuardDuty enabled
- [ ] SIEM integration configured
- [ ] On-call rotation defined
- [ ] Incident response plan documented

#### Application Security
- [ ] Input validation implemented
- [ ] Output encoding implemented
- [ ] SQL/NoSQL injection prevention
- [ ] No hardcoded secrets
- [ ] Container running as non-root
- [ ] Read-only root filesystem
- [ ] Security headers configured
- [ ] Error messages don't leak info

#### Testing
- [ ] SAST scan passed (no critical/high)
- [ ] Dependency scan passed
- [ ] Container scan passed
- [ ] Infrastructure scan passed
- [ ] Penetration test completed (if required)
- [ ] Security unit tests passed (>80% coverage)
- [ ] ABAC policy tests passed
- [ ] Integration tests passed

#### Compliance
- [ ] SOC2 controls mapped and tested
- [ ] HIPAA requirements addressed
- [ ] PCI-DSS requirements addressed
- [ ] Evidence package prepared
- [ ] Security Requirements Document approved
- [ ] Change management ticket approved
- [ ] Risk assessment completed

#### Operational Readiness
- [ ] Runbooks documented
- [ ] Backup/restore tested
- [ ] DR plan documented
- [ ] Access review process defined
- [ ] Patch management process defined
- [ ] Vulnerability management process defined
- [ ] Security training completed

---

**Signature:**

_________________________  
Cybersecurity Architect  
Date: _____________

**Approval Status:**
- [ ] APPROVED - Proceed to production
- [ ] APPROVED WITH CONDITIONS - Deploy with follow-up items
- [ ] NOT APPROVED - Address findings and re-submit

---

## Summary

As a cybersecurity architect deploying MCP, focus on these **8 critical guardrails**:

1. ✅ **MFA** - Multi-factor authentication via Ping Identity
2. ✅ **OAuth2 + PKCE** - Secure token issuance for IDE clients
3. ✅ **ABAC** - Fine-grained authorization with user attributes
4. ✅ **TLS 1.3** - Encryption in transit (no fallback)
5. ✅ **KMS Encryption** - All data encrypted at rest
6. ✅ **DLP** - Scan responses for sensitive data
7. ✅ **Rate Limiting** - Prevent bulk exfiltration
8. ✅ **Audit Logging** - Comprehensive logging for compliance

**These controls are NON-NEGOTIABLE for production deployment.**

---

**Questions? Contact:**
- **Security Architecture:** security-architecture@yourcompany.com
- **Compliance:** compliance@yourcompany.com
- **On-Call:** PagerDuty rotation

**Document Version:** 1.0  
**Last Updated:** November 16, 2025
