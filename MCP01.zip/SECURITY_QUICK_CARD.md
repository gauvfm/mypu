# MCP Security Guardrails - Quick Reference Card
## For Cybersecurity Architects

**Print this page and keep it during security reviews**

---

## 🎯 The 8 Critical Guardrails (Non-Negotiable)

| # | Guardrail | What | Why | How to Verify |
|---|-----------|------|-----|---------------|
| 1 | **MFA** | Multi-factor auth via Ping | Prevents account compromise | JWT contains `acr: mfa` claim |
| 2 | **OAuth2+PKCE** | Authorization Code + PKCE only | Protects token issuance | No implicit/password grant allowed |
| 3 | **ABAC** | Attribute-based access control | Fine-grained permissions | Default deny, policies tested |
| 4 | **TLS 1.3** | Encryption in transit | Prevents MITM | `nmap --script ssl-enum-ciphers` |
| 5 | **KMS** | Encryption at rest | Protects stored data | All S3/EBS encrypted, key rotation on |
| 6 | **DLP** | Sensitive data scanning | Prevents data leaks | SSN/API keys blocked or redacted |
| 7 | **Rate Limit** | 1000 req/hour per user | Prevents exfiltration | 429 response on exceeded |
| 8 | **Audit Logs** | All events logged | Compliance & forensics | 90d CloudWatch, 7y S3 |

---

## 🔐 Authentication Flow to Validate

```
1. User → Ping (OAuth2) → MFA Challenge → Success
2. Ping → JWT (RS256, 1hr lifetime) with:
   - iss: ping.yourcompany.com ✓
   - aud: mcp-codebase-api ✓
   - acr: mfa ✓
   - groups: [AD groups] ✓
   - repo_access: [allowed repos] ✓
3. IDE → APIGEE (with JWT) → Validates signature ✓
4. APIGEE → MCP (mTLS) → Validates JWT again ✓
5. MCP → ABAC check → Allow/Deny ✓
6. Response → DLP scan → Redact/Block if needed ✓
```

---

## ⚠️ Top 5 Threats & Mitigations

| Threat | Risk | Mitigation |
|--------|------|------------|
| **Unauthorized Code Access** | CRITICAL | MFA + ABAC + Audit logs |
| **Token Theft/Replay** | MEDIUM | TLS 1.3 + 1hr token lifetime |
| **Data Exfiltration** | CRITICAL | Rate limiting + DLP + Anomaly detection |
| **Privilege Escalation** | HIGH | ABAC default deny + Policy testing |
| **Injection Attacks** | MEDIUM | Input validation + WAF |

---

## ✅ Pre-Production Checklist (Quick Version)

**Identity:**
- [ ] MFA enforced (Ping)
- [ ] OAuth2+PKCE only
- [ ] JWT validated 2x (APIGEE + MCP)
- [ ] ABAC policies tested

**Network:**
- [ ] TLS 1.3 only (no fallback)
- [ ] mTLS (APIGEE ↔ MCP)
- [ ] Security groups configured
- [ ] VPC Flow Logs enabled

**Data:**
- [ ] S3 encrypted (KMS)
- [ ] EBS encrypted
- [ ] Redis encrypted
- [ ] Key rotation enabled

**Detection:**
- [ ] DLP operational
- [ ] Rate limiting active
- [ ] Audit logs flowing
- [ ] Alerts configured

---

## 🚨 Red Flags (Block Deployment If Found)

| Finding | Action |
|---------|--------|
| No MFA on Ping | **BLOCK** |
| TLS 1.2 allowed | **BLOCK** |
| Unencrypted S3 bucket | **BLOCK** |
| No DLP scanning | **BLOCK** |
| Default allow ABAC | **BLOCK** |
| No audit logging | **BLOCK** |
| Secrets in code | **BLOCK** |
| Container runs as root | **BLOCK** |

---

## 📊 Key Security Metrics to Monitor

| Metric | Target | Alert Threshold |
|--------|--------|-----------------|
| Unauthorized access attempts | 0 | > 5/hour |
| DLP violations | < 5/month | > 10/day |
| Rate limit exceeded | < 1% | > 5% |
| Error rate | < 1% | > 5% |
| p95 latency | < 500ms | > 1000ms |

---

## 🔍 Security Testing Required

| Test | Tool | Pass Criteria |
|------|------|---------------|
| SAST | Semgrep, Bandit | No critical/high |
| DAST | OWASP ZAP | No critical |
| Dependency | Snyk | No critical CVEs |
| Container | ECR scan | No critical |
| Infrastructure | Checkov | All checks pass |

---

## 📞 Quick Commands for Validation

```bash
# Verify MFA
curl https://ping.yourcompany.com/.well-known/openid-configuration | jq .acr_values_supported

# Test TLS
nmap --script ssl-enum-ciphers -p 443 api.yourcompany.com

# Check encryption
aws s3api get-bucket-encryption --bucket yourcompany-mcp-codebase

# View audit logs
aws logs tail /mcp/audit --follow --filter-pattern "result=denied"

# Check GuardDuty
aws guardduty list-findings --detector-id <ID> --finding-criteria '{"Criterion":{"severity":{"Gte":4}}}'
```

---

## 📝 Approval Criteria

**APPROVE if:**
- ✅ All 8 guardrails implemented
- ✅ All critical findings remediated
- ✅ Security tests passed
- ✅ Evidence package complete

**APPROVE WITH CONDITIONS if:**
- ⚠️ Minor findings with 30-day remediation plan
- ⚠️ Medium findings with mitigation in place

**REJECT if:**
- ❌ Any critical guardrail missing
- ❌ Critical security findings unaddressed
- ❌ Insufficient evidence

---

## 📚 Document References

- Full Architecture: `enterprise-mcp-architecture.md` (71 KB)
- Security Requirements: `SECURITY_REQUIREMENTS.md` (51 KB)
- Detailed Guardrails: `CYBERSECURITY_ARCHITECT_GUIDE.md` (53 KB)
- Deployment Guide: `DEPLOYMENT_GUIDE.md` (16 KB)
- HTML Version: `security-requirements.html` (46 KB)

---

## 🎯 Your Role as Cybersecurity Architect

**Focus on:**
1. Validate the 8 critical guardrails are implemented correctly
2. Review threat model and ensure mitigations are adequate
3. Verify encryption is enforced (no exceptions)
4. Confirm audit logging captures all security events
5. Test ABAC policies with realistic scenarios
6. Ensure monitoring and alerting are operational

**Don't:**
- Approve without testing critical controls
- Accept "will implement later" for critical items
- Skip the pre-production checklist
- Ignore red flags

**Remember:**
- You're protecting the company's source code (crown jewels)
- MCP creates a new API attack surface
- Default deny is your friend
- Logs are your evidence trail
- Defense in depth saves the day

---

**Decision:**
- [ ] ✅ **APPROVED** - All requirements met
- [ ] ⚠️ **CONDITIONAL** - Deploy with follow-ups
- [ ] ❌ **REJECTED** - Address findings first

**Signature:** _________________ **Date:** _______

---

**Questions?**
- Security Architecture: security-architecture@yourcompany.com
- Urgent: Slack #security-help or PagerDuty

**Document Version:** 1.0 | **Date:** November 16, 2025
