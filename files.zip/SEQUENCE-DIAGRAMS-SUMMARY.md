# Sequence Diagrams - Complete Collection

## Your Architecture

```
IDE → GitHub Copilot → IDE → Kong MCP GW → SSO/APIGEE → 
Kong MCP GW (Authorization Code to JWT Exchange) → SSO/APIGEE → MCP Server
```

## Available Sequence Diagrams

### 1. 🎯 **COMPLETE SEQUENCE DIAGRAM** (Most Detailed)
**File:** [COMPLETE-SEQUENCE-DIAGRAM.mermaid](./COMPLETE-SEQUENCE-DIAGRAM.mermaid)

**Shows:**
- All 33 steps from user action to final display
- 4 phases: Setup, Token Exchange, Request, Response
- Detailed OAuth flow with PKCE
- Authorization code to JWT exchange at SSO/APIGEE
- JWT validation process
- Complete request/response flow
- All components with their roles

**Use this when:** You need to understand every single step in detail

**Key sections:**
- Phase 1: Initial Setup & Authentication (Steps 1-12)
- Phase 2: Token Exchange - Authorization Code → JWT (Steps 13-16)
- Phase 3: Authenticated MCP Request with JWT (Steps 17-27)
- Phase 4: Response Flow (Steps 28-33)

---

### 2. 📊 **SIMPLIFIED SEQUENCE** (Quick Overview)
**File:** [simplified-sequence.mermaid](./simplified-sequence.mermaid)

**Shows:**
- High-level flow in 4 main steps
- Condensed view of the entire process
- Focus on the main components

**Use this when:** You need a quick overview or presentation slide

**Covers:**
1. Initial connection (401)
2. Browser opens (user logs in)
3. Exchange code for JWT
4. Use JWT for requests

---

### 3. 🔑 **CODE TO JWT EXCHANGE** (Authorization Flow Focus)
**File:** [code-to-jwt-sequence.mermaid](./code-to-jwt-sequence.mermaid)

**Shows:**
- **Focused on authorization code → JWT exchange**
- Detailed PKCE validation steps
- JWT generation process at SSO/APIGEE
- JWT structure (header, payload, signature)
- Token validation process

**Use this when:** You specifically want to understand how the authorization code is exchanged for JWT

**Key details:**
- What happens during POST /token
- PKCE validation steps
- JWT creation with all claims
- Token storage in IDE

---

### 4. 🏗️ **ARCHITECTURE PATH SEQUENCE** (Component Flow)
**File:** [architecture-path-sequence.mermaid](./architecture-path-sequence.mermaid)

**Shows:**
- Clear component labels with URLs/ports
- Numbered steps (1-30)
- Your specific architecture path
- Component responsibilities

**Use this when:** You need to see which component handles what

**Components shown:**
- Kong MCP GW (Entry Point) - kong.example.com
- SSO/APIGEE - sso.company.com
- Kong MCP GW (OAuth Layer) - Internal
- MCP Server - Port 8080, Internal
- Backend APIs

---

## Comparison Table

| Diagram | Detail Level | Steps | Focus | Best For |
|---------|--------------|-------|-------|----------|
| **Complete** | ⭐⭐⭐⭐⭐ | 33 | Everything | Deep understanding |
| **Simplified** | ⭐⭐ | 4 | Overview | Presentations |
| **Code→JWT** | ⭐⭐⭐⭐ | 3 phases | Token exchange | Security review |
| **Architecture Path** | ⭐⭐⭐ | 30 | Component flow | System design |

## Key Flows Visualized

### Authentication Flow (First Time)
```
User → IDE → Browser → SSO/APIGEE → IDE
                           ↓
                   Authorization Code
                           ↓
                          JWT
```
**Shown in:** Complete, Code→JWT

### Token Exchange Detail
```
IDE sends:
- authorization_code
- code_verifier (PKCE)

SSO/APIGEE validates & returns:
- access_token (JWT)
- refresh_token
```
**Shown in:** Complete, Code→JWT, Architecture Path

### Request Flow (Subsequent)
```
IDE → Kong Entry → APIGEE → Kong OAuth → MCP → Backend
      + JWT        + JWT      Validate    No JWT
                               Remove JWT
                               Add headers
```
**Shown in:** All diagrams

## Important Points Visualized

### 1. Browser Opening
- **When:** First time, no token exists
- **What user sees:** Company login page
- **Result:** Authorization code
- **Diagrams:** Complete, Simplified, Architecture Path

### 2. Authorization Code → JWT Exchange
- **Where:** SSO/APIGEE /token endpoint
- **Input:** Authorization code + code_verifier
- **Output:** JWT access token
- **Diagrams:** Complete, Code→JWT, Architecture Path

### 3. JWT Validation
- **Who validates:** Kong MCP GW (OAuth Layer)
- **How:** Introspection with SSO/APIGEE
- **What's checked:** Signature, expiry, audience, scope
- **Diagrams:** Complete, Code→JWT

### 4. JWT Removal
- **Where:** Kong MCP GW (OAuth Layer)
- **Why:** Security - MCP server doesn't need JWT
- **What instead:** User context via headers (X-User-Id, etc.)
- **Diagrams:** Complete, Simplified, Architecture Path

### 5. Token in Transit
```
Component          | Has JWT? | Why?
-------------------|----------|----------------------------------
IDE                | ✅ Yes   | Sends in Authorization header
Kong Entry         | ✅ Yes   | Passes through
APIGEE             | ✅ Yes   | Validates & routes
Kong OAuth Layer   | ✅ Yes   | Validates then removes
MCP Server         | ❌ NO    | Receives user headers instead
```
**Diagrams:** Complete, Architecture Path

## How to Use These Diagrams

### For Developers:
- Start with **Simplified** for context
- Review **Complete** for implementation
- Reference **Code→JWT** for OAuth specifics

### For Architects:
- Use **Architecture Path** for system design
- Use **Complete** for security review
- Use **Simplified** for stakeholder presentations

### For Security Review:
- Focus on **Code→JWT** for authentication flow
- Review **Complete** for token handling
- Check JWT removal in **Architecture Path**

### For Documentation:
- **Simplified**: Executive summary
- **Architecture Path**: Integration guide
- **Complete**: Developer handbook
- **Code→JWT**: Security documentation

## Viewing the Diagrams

These are Mermaid diagrams. To view them:

1. **GitHub/GitLab:** Render automatically
2. **VS Code:** Install Mermaid extension
3. **Online:** https://mermaid.live/
4. **Documentation:** Most doc platforms support Mermaid

## Component Reference

| Component | URL | Port | Access | Handles |
|-----------|-----|------|--------|---------|
| **IDE** | Local | N/A | Local | User interface, token storage |
| **Kong Entry** | kong.example.com | 443 | External | Entry point, routing |
| **SSO/APIGEE** | sso.company.com | 443 | External | Auth, token issuance, validation |
| **Kong OAuth** | kong-mcp-gateway | 8000 | Internal | JWT validation, removal |
| **MCP Server** | mcp-server | 8080 | Internal | Tool execution |
| **Backend** | backend-api | 3000+ | Internal | Data storage, business logic |

## Summary

All diagrams show the same flow from different perspectives:

1. **Complete Sequence**: Every detail, all 33 steps
2. **Simplified**: High-level, 4 main phases
3. **Code→JWT**: Focus on authorization code exchange
4. **Architecture Path**: Component-centric view with labels

Choose the diagram that best fits your current need:
- Understanding? → Complete
- Presenting? → Simplified
- Security? → Code→JWT
- Planning? → Architecture Path
